const e=`<section class="lp-reassure pr-inverse" aria-label="Our strongest claim">
  <div class="pr-container lp-reassure__inner reveal">
    <span class="lp-reassure__icon">
      <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
    </span>
    <p class="lp-reassure__text">Government contracts are long-term. As long as you remain compliant with your contract terms, your sales on the federal market are almost guaranteed — and keeping clients compliant is exactly what we've done since&nbsp;2006.</p>
  </div>
</section>
`,n=`<section class="lp-why pr-section">
  <div class="pr-container">
    <div class="lp-why__grid">
      <div class="lp-why__copy reveal">
        <h2 class="lp-why__title">Why right now is a good time to get on the&nbsp;Schedule</h2>
        <p>GSA has spent the last two years cleaning house: contracts that don't sell are being retired, and vendors that don't keep up with compliance are leaving the program. For companies entering with their proposal, pricing, and compliance done properly, that means a clearer field and less noise to compete against.</p>
        <p>The rules do keep moving — MAS Refresh #30 alone rewrote requirements across the program. Tracking those changes is our day job, not yours. You'll find our plain-English breakdowns of every major update on <a href="https://pricereporter.com/blog/" target="_blank" rel="noopener">our blog</a>.</p>
      </div>

      <figure class="lp-why__viz reveal" aria-hidden="true">
        <div class="lp-why__viz-chrome">
          <span class="lp-why__viz-dot"></span><span class="lp-why__viz-dot"></span><span class="lp-why__viz-dot"></span>
          <span class="lp-why__viz-title">Multiple Award Schedule</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--out">
          <span class="lp-why__viz-name">Vendor A-1180</span>
          <span class="lp-why__viz-note">below sales minimum</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--ok">
          <span class="lp-why__viz-name">Vendor B-0417</span>
          <span class="lp-why__viz-chip">compliant</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--out">
          <span class="lp-why__viz-name">Vendor C-2209</span>
          <span class="lp-why__viz-note">non-compliant</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--out lp-why__viz-row--fade">
          <span class="lp-why__viz-name">Vendor D-0533</span>
          <span class="lp-why__viz-note">expired</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--ok">
          <span class="lp-why__viz-name">Vendor E-1902</span>
          <span class="lp-why__viz-chip">compliant</span>
        </div>
      </figure>
    </div>
  </div>
</section>
`,a=`<section class="lp-final pr-inverse pr-section" id="final-cta-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Your share of $52 billion starts with a 2-minute form</h2>
      <p class="pr-sectionhead__sub">Tell us who you are and what you sell. A GSA specialist will call you back within one business day with a straight answer: whether you qualify, what the process looks like for your business, and what it costs. If GSA isn't your market, we'll tell you that too — for free.</p>
    </div>

    <form class="lp-form lp-final__form reveal" data-lead-form novalidate>
      <div class="lp-form__fields lp-final__fields">
        <div class="lp-final__row">
          <label class="pr-input pr-input--on-dark" aria-label="Your name">
            <input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Company">
            <input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Work email">
            <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="Work email" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Phone">
            <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="Phone" />
          </label>
        </div>
        <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full lp-final__submit">Get My Free Eligibility Assessment</button>
        <p class="lp-final__contacts">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2a9 9 0 0 1 9 9"></path><path d="M13 6a5 5 0 0 1 5 5"></path><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
          Or call us directly: <a href="tel:2015676646">201-567-6646</a>&nbsp;·&nbsp;<a href="mailto:salesteam@pricereporter.com">salesteam@pricereporter.com</a>
        </p>
      </div>
      <div class="lp-form__success" hidden>
        <span class="lp-form__success-icon">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
        </span>
        <h3>Request received</h3>
        <p>A GSA specialist will review your details and respond within one business day.</p>
      </div>
    </form>
  </div>
</section>
`,s=`<div class="lp-exit" id="exit-popup-root" hidden>
  <div class="lp-exit__scrim" data-exit-dismiss></div>
  <div class="lp-exit__modal" role="dialog" aria-modal="true" aria-labelledby="exit-popup-title">
    <button type="button" class="lp-exit__close" data-exit-dismiss aria-label="Close">
      <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
    </button>
    <h3 class="lp-exit__title" id="exit-popup-title">Not ready yet?</h3>
    <p class="lp-exit__body">Fair enough. At least find out if you qualify — it's free, and the answer is yours to keep.</p>
    <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-exit-cta>Check My Eligibility</button>
    <button type="button" class="lp-exit__dismiss" data-exit-dismiss>Maybe later</button>
  </div>
</div>
`;export{s as E,a as F,e as R,n as T};
