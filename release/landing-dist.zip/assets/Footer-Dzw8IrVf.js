const e=`<header class="lp-header" id="site-header" aria-label="Site header">
  <div class="pr-container lp-header__inner">
    <a class="lp-header__logo" href="#top" aria-label="Price Reporter — back to top">
      <img src="/assets/logo-horizontal-color.png" alt="Price Reporter" height="30" />
    </a>
    <span class="lp-header__spacer"></span>
    <a class="lp-header__phone" href="tel:2015676646">
      <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
      201-567-6646
    </a>
    <button type="button" class="pr-btn pr-btn--accent" data-scroll-form>Free Assessment</button>
  </div>
</header>
`,a=`<footer class="lp-footer">
  <div class="pr-container lp-footer__inner">
    <span class="lp-footer__brand">
      <img src="/assets/mark-mono.png" alt="" width="26" height="26" aria-hidden="true" />
      <span class="lp-footer__word"><b>PRICE</b>REPORTER</span>
    </span>
    <p class="lp-footer__trust">Price Reporter · Doing business with GSA since 2006 · Hundreds of contracts awarded · 1,000,000+ federal orders processed</p>
    <span class="lp-footer__meta">
      <a href="tel:2015676646">201-567-6646</a>
      <a href="mailto:salesteam@pricereporter.com">salesteam@pricereporter.com</a>
    </span>
  </div>
</footer>
`;export{a as F,e as H};
