const s=`<section class="lp-trust pr-inverse" aria-label="Track record">
  <div class="pr-container">
    <div class="lp-trust__grid stagger">
      <div class="lp-trust__item">
        <span class="lp-trust__big">Since 2006</span>
        <span class="lp-trust__label">securing &amp; managing GSA contracts</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">Hundreds</span>
        <span class="lp-trust__label">of GSA Schedule contracts awarded</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">1,000,000+</span>
        <span class="lp-trust__label">federal orders processed</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">Full cycle</span>
        <span class="lp-trust__label">from first assessment to five-year renewal</span>
      </div>
    </div>
  </div>
</section>
`,n=`<section class="lp-how pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">What working with us actually looks like</h2>
    </div>
    <ol class="lp-how__timeline stagger">
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">1</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21 21-4.34-4.34"></path><circle cx="11" cy="11" r="8"></circle></svg>
        </span>
        <h3 class="lp-how__title">Free eligibility assessment</h3>
        <p class="lp-how__text">Before you spend a dollar, we look at your company, products, and pricing and tell you straight whether GSA is the right move. If you're not a fit, we'll say so.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">2</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"></path><path d="M14 2v5a1 1 0 0 0 1 1h5"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>
        </span>
        <h3 class="lp-how__title">We build your proposal</h3>
        <p class="lp-how__text">Company credentials, competitor assessment, product catalog, financials, pricing strategy. You send us documents; we turn them into an offer GSA can say yes to.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">3</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"></path></svg>
        </span>
        <h3 class="lp-how__title">We negotiate with GSA</h3>
        <p class="lp-how__text">Clarifications, resubmissions, price agreement, final revisions — our team handles the back-and-forth with your contracting officer. You keep running your business.</p>
      </li>
      <li class="lp-how__step lp-how__step--featured">
        <div class="lp-how__marker">
          <span class="lp-how__num">4</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 7h6v6"></path><path d="m22 7-8.5 8.5-5-5L2 17"></path></svg>
        </span>
        <h3 class="lp-how__title">Award is the starting line</h3>
        <p class="lp-how__text">Your catalog goes live on GSA Advantage. From there we manage modifications, renewals, TAA compliance, IFF and TDR reporting, and keep your prices positioned against competitors — so the contract earns instead of sitting there.</p>
      </li>
    </ol>
    <div class="lp-how__cta reveal">
      <button type="button" class="pr-btn pr-btn--accent pr-btn--lg" data-scroll-form>Start With the Free Assessment</button>
    </div>
  </div>
</section>
`,a=`<section class="lp-quiz pr-inverse pr-section" id="quiz-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Not sure you qualify? Find out in 60 seconds.</h2>
      <p class="pr-sectionhead__sub">Answer four quick questions and we'll tell you whether your company is a realistic GSA candidate — and what would need to change if it isn't yet.</p>
    </div>

    <div class="lp-quiz__card reveal" data-quiz>
      <div class="lp-quiz__top">
        <div class="lp-quiz__progress" data-quiz-progress-wrap>
          <span class="lp-quiz__progress-label" data-quiz-progress-label>Question 1 of 4</span>
          <span class="lp-quiz__bar"><span class="lp-quiz__bar-fill" data-quiz-progress-fill style="width: 25%"></span></span>
        </div>
        <span class="lp-quiz__timer">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>
          60 seconds
        </span>
      </div>

      <div class="lp-quiz__step" data-quiz-step="0">
        <h3 class="lp-quiz__q">How long has your company been in business?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Under 2 years">Under 2 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="2–5 years">2–5 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="5+ years">5+ years</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="1" hidden>
        <h3 class="lp-quiz__q">What do you sell?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Products">Products</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Services">Services</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Both">Both</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="2" hidden>
        <h3 class="lp-quiz__q">Are your products made in the U.S. or TAA-compliant countries?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Yes">Yes</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="No">No</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Not sure">Not sure</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="3" hidden>
        <h3 class="lp-quiz__q">Have you sold to any government buyer before?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Yes">Yes</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="No">No</button>
        </div>
      </div>

      <form class="lp-quiz__step lp-quiz__contact" data-quiz-step="4" data-quiz-contact hidden novalidate>
        <h3 class="lp-quiz__q">Where should we send your result?</h3>
        <label class="pr-field">
          <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" /></span>
        </label>
        <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Get My Result</button>
      </form>

      <div class="lp-quiz__step lp-quiz__result" data-quiz-step="result" hidden>
        <span class="lp-form__success-icon">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
        </span>
        <p class="lp-quiz__result-text">Thanks — a GSA specialist will review your answers and get back to you within one business day with an honest read on your eligibility. No sales script, no pressure.</p>
      </div>

      <button type="button" class="lp-quiz__back" data-quiz-back hidden>
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"></path></svg>
        Back
      </button>
    </div>
  </div>
</section>
`,e=`<section class="lp-services pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">One team for the whole federal cycle</h2>
    </div>
    <div class="lp-services__grid stagger">
      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-doc">
            <span class="lp-svc-doc__tag">GSA MAS proposal</span>
            <span class="lp-svc-doc__line" style="width: 86%"></span>
            <span class="lp-svc-doc__line" style="width: 68%"></span>
            <span class="lp-svc-doc__line" style="width: 92%"></span>
            <span class="lp-svc-doc__line" style="width: 55%"></span>
            <span class="lp-svc-doc__stamp">Awarded</span>
          </div>
        </div>
        <h3 class="lp-services__title">Get Your GSA Contract</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">From eligibility check to award: proposal preparation, competitor assessment, federal market intelligence, and negotiation with GSA. You bring the business; we bring the process.</p>
        <button type="button" class="lp-services__link" data-scroll-form>
          How we win contracts
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
        </button>
      </article>

      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-list">
            <div class="lp-svc-list__row">
              <span>Modification #2041</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Approved</span>
            </div>
            <div class="lp-svc-list__row">
              <span>Option renewal</span>
              <span class="lp-svc-chip lp-svc-chip--proc">2027</span>
            </div>
            <div class="lp-svc-list__row">
              <span>TAA compliance check</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Passed</span>
            </div>
          </div>
        </div>
        <h3 class="lp-services__title">Manage &amp; Grow Your Contract</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Already on Schedule? We keep it compliant and competitive: contract modifications, new SINs, five-year option renewals, TAA compliance, IFF/TDR reporting, and pricing tuned against your competitors.</p>
        <button type="button" class="lp-services__link" data-scroll-form>
          Contract management
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
        </button>
      </article>

      <article class="lp-services__card lp-services__card--oms">
        <div class="lp-svc-mock" aria-hidden="true">
        <div class="lp-oms">
          <div class="lp-oms__chrome">
            <span class="lp-oms__dot"></span><span class="lp-oms__dot"></span><span class="lp-oms__dot"></span>
            <span class="lp-oms__chrome-title">Order Management System</span>
          </div>
          <div class="lp-oms__row lp-oms__row--head">
            <span>Order</span><span>Agency</span><span>Status</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471820</span><span>GSA Advantage</span><span class="lp-oms__chip lp-oms__chip--ok">Shipped</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471819</span><span>DLA</span><span class="lp-oms__chip lp-oms__chip--proc">Processing</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471818</span><span>FedMall</span><span class="lp-oms__chip lp-oms__chip--ok">Invoiced</span>
          </div>
        </div>
        </div>
        <h3 class="lp-services__title">Orders, Catalogs &amp; Marketplaces</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Our Order Management System has processed over 1,000,000 federal orders. Catalog uploads to GSA Advantage via EDI, plus DOD, DLA, FedMall, and BPA support — with QuickBooks and Amazon integrations.</p>
        <div class="lp-services__integrations">
          <span class="pr-tag">QuickBooks</span>
          <span class="pr-tag">Amazon</span>
          <span class="pr-tag">EDI</span>
        </div>
        <button type="button" class="lp-services__link" data-scroll-form>
          See the system
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
        </button>
      </article>
    </div>
  </div>
</section>
`,t=`<section class="lp-why pr-section">
  <div class="pr-container">
    <div class="lp-why__grid">
      <div class="lp-why__copy reveal">
        <h2 class="lp-why__title">The Schedule is being cleaned up. That's bad news for guesswork — and good news for&nbsp;you.</h2>
        <p>GSA is in the middle of the biggest housekeeping the Multiple Award Schedule has seen in years: contracts that miss sales thresholds are being allowed to expire, non-compliant vendors are being removed, and the rules themselves keep shifting — MAS Refresh #30 alone rewrote requirements across the program.</p>
        <p>For companies that wing it, that's a minefield. For companies with their proposal, pricing, and compliance handled properly, it means something else: fewer competitors on the Schedule and more room to win.</p>
        <p>We track every MAS refresh and regulation change so you don't have to. It's literally our day job — you can see our breakdowns of the latest changes on <a href="https://pricereporter.com/blog/" target="_blank" rel="noopener">our blog</a>.</p>
      </div>

      <figure class="lp-why__viz reveal" aria-hidden="true">
        <div class="lp-why__viz-chrome">
          <span class="lp-why__viz-dot"></span><span class="lp-why__viz-dot"></span><span class="lp-why__viz-dot"></span>
          <span class="lp-why__viz-title">Multiple Award Schedule</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--out">
          <span class="lp-why__viz-name">Vendor A-1180</span>
          <span class="lp-why__viz-note">below sales minimum</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--ok">
          <span class="lp-why__viz-name">Vendor B-0417</span>
          <span class="lp-why__viz-chip">compliant</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--out">
          <span class="lp-why__viz-name">Vendor C-2209</span>
          <span class="lp-why__viz-note">non-compliant</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--out lp-why__viz-row--fade">
          <span class="lp-why__viz-name">Vendor D-0533</span>
          <span class="lp-why__viz-note">expired</span>
        </div>
        <div class="lp-why__viz-row lp-why__viz-row--ok">
          <span class="lp-why__viz-name">Vendor E-1902</span>
          <span class="lp-why__viz-chip">compliant</span>
        </div>
      </figure>
    </div>

    <aside class="lp-why__callout reveal">
      <span class="lp-why__callout-icon">
        <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
      </span>
      <p>Government contracts are long-term. As long as you remain compliant with the terms of your contract, your sales on the federal market are almost guaranteed — and keeping you compliant is exactly what we do.</p>
    </aside>
  </div>
</section>
`,l=`<section class="lp-final pr-inverse pr-section" id="final-cta-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Find out if GSA is your next sales channel — for free</h2>
      <p class="pr-sectionhead__sub">One short form. A specialist reviews your business and calls you back within one business day with a straight answer: whether you're a fit, what the process would look like for you, and what it would cost. If GSA isn't right for your company, we'll tell you that too.</p>
    </div>

    <form class="lp-form lp-final__form reveal" data-lead-form novalidate>
      <div class="lp-form__fields lp-final__fields">
        <div class="lp-final__row">
          <label class="pr-input pr-input--on-dark" aria-label="Your name">
            <input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Company">
            <input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Work email">
            <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="Work email" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Phone">
            <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="Phone" />
          </label>
        </div>
        <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full lp-final__submit">Get My Free Eligibility Assessment</button>
        <p class="lp-final__contacts">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2a9 9 0 0 1 9 9"></path><path d="M13 6a5 5 0 0 1 5 5"></path><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
          Or call us directly: <a href="tel:2015676646">201-567-6646</a>&nbsp;·&nbsp;<a href="mailto:salesteam@pricereporter.com">salesteam@pricereporter.com</a>
        </p>
      </div>
      <div class="lp-form__success" hidden>
        <span class="lp-form__success-icon">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
        </span>
        <h3>Request received</h3>
        <p>A GSA specialist will review your details and respond within one business day.</p>
      </div>
    </form>
  </div>
</section>
`,i=`<div class="lp-exit" id="exit-popup-root" hidden>
  <div class="lp-exit__scrim" data-exit-dismiss></div>
  <div class="lp-exit__modal" role="dialog" aria-modal="true" aria-labelledby="exit-popup-title">
    <button type="button" class="lp-exit__close" data-exit-dismiss aria-label="Close">
      <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
    </button>
    <h3 class="lp-exit__title" id="exit-popup-title">Leaving with questions?</h3>
    <p class="lp-exit__body">Get a straight answer first. Request the free eligibility assessment — a GSA specialist replies within one business day.</p>
    <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-exit-cta>Check My Eligibility</button>
    <button type="button" class="lp-exit__dismiss" data-exit-dismiss>No thanks, I'll figure it out myself</button>
  </div>
</div>
`;export{i as E,l as F,n as H,a as Q,e as S,s as T,t as W};
