import{S as a,F as r,H as o,i as t,a as l,b as i,c as p,d as c,e as d,f as h}from"./animations-Dz6X2--W.js";/* empty css             */import{E as u,F as v,W as _,S as m,Q as w,H as g,T as f}from"./ExitPopup-DiWYhf-x.js";import{F as b}from"./Faq-B36MIU_r.js";const k=`<section class="lp-hero" id="top">
  <span class="lp-hero__photo" aria-hidden="true"></span>
  <div class="pr-container lp-hero__container">
    <div class="lp-hero__topbar">
      <img src="/assets/logo-horizontal-color.png" alt="Price Reporter" height="34" />
      <a class="lp-hero__topphone" href="tel:2015676646">
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
        201-567-6646
      </a>
    </div>
    <div class="lp-hero__grid">
      <div class="lp-hero__copy">
        <p class="lp-hero__eyebrow">GSA Schedule Consultants&nbsp;·&nbsp;Working with GSA since 2006</p>
        <h1 class="lp-hero__title">Get Your GSA Schedule Contract. Then Actually Sell With&nbsp;It.</h1>
        <span class="lp-hero__rule" aria-hidden="true"></span>
        <p class="lp-hero__sub">We've secured hundreds of GSA contracts and processed over 1,000,000 federal orders for our clients. Our team prepares your proposal, negotiates with GSA on your behalf, and stays on after award — because a contract that doesn't produce orders is just expensive paperwork.</p>
        <div class="lp-hero__mobile-cta">
          <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-scroll-form>Get My Free Eligibility Assessment</button>
          <p class="lp-hero__micro">No obligation. A GSA specialist responds within one business day.</p>
        </div>
        <p class="lp-hero__call">Prefer to talk it through? Call <a href="tel:2015676646">201-567-6646</a>.</p>
      </div>
      <div class="lp-hero__formwrap" id="lead-form-anchor">
        <form class="lp-form" data-lead-form novalidate>
          <div class="lp-form__fields">
            <div class="lp-form__head">
              <h3 class="lp-form__title">Get My Free Eligibility Assessment</h3>
              <p class="lp-form__sub">No obligation. A GSA specialist responds within one business day.</p>
            </div>
            <label class="pr-field">
              <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
              <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
            </label>
            <label class="pr-field">
              <span class="pr-field__label">Company <span class="pr-field__req">*</span></span>
              <span class="pr-input"><input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company name" /></span>
            </label>
            <label class="pr-field">
              <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
              <span class="pr-input">
                <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
                <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" />
              </span>
            </label>
            <label class="pr-field">
              <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
              <span class="pr-input">
                <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
                <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" />
              </span>
            </label>
            <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Check My Eligibility — Free</button>
            <p class="lp-form__fine">
              <svg class="ic ic--xs" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
              Your details are used only to prepare your assessment. No lists, no resale.
            </p>
          </div>
          <div class="lp-form__success" hidden>
            <span class="lp-form__success-icon">
              <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
            </span>
            <h3>Request received</h3>
            <p>A GSA specialist will review your details and respond within one business day.</p>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
`,y=`<section class="lp-problem pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Federal buyers spent $52 billion through the GSA Schedule last year. The paperwork is where most companies give&nbsp;up.</h2>
    </div>

    <figure class="lp-problem__art reveal" aria-hidden="true">
      <div class="lp-problem__browser">
        <div class="lp-problem__browser-bar">
          <span class="lp-problem__dot"></span><span class="lp-problem__dot"></span><span class="lp-problem__dot"></span>
          <span class="lp-problem__url">sam.gov / entity-registration</span>
        </div>
        <div class="lp-problem__browser-body">
          <span class="lp-problem__browser-step">Step 3 of 12 — Entity Registration</span>
          <span class="lp-problem__line" style="width: 88%"></span>
          <span class="lp-problem__line" style="width: 64%"></span>
          <span class="lp-problem__field-row">
            <span class="lp-problem__field"></span>
            <span class="lp-problem__field"></span>
          </span>
          <span class="lp-problem__line" style="width: 76%"></span>
          <span class="lp-problem__field-row">
            <span class="lp-problem__field"></span>
            <span class="lp-problem__field lp-problem__field--error"></span>
          </span>
          <span class="lp-problem__line" style="width: 52%"></span>
        </div>
      </div>
      <div class="lp-problem__paper lp-problem__paper--back">
        <span class="lp-problem__paper-tag">eOffer · Proposal package</span>
        <span class="lp-problem__line" style="width: 78%"></span>
        <span class="lp-problem__line" style="width: 92%"></span>
        <span class="lp-problem__line" style="width: 64%"></span>
        <span class="lp-problem__line" style="width: 85%"></span>
        <span class="lp-problem__pages">p. 1 of 47</span>
      </div>
      <div class="lp-problem__paper lp-problem__paper--front">
        <span class="lp-problem__stamp">Clarification requested</span>
        <span class="lp-problem__paper-tag">Pricing disclosures</span>
        <span class="lp-problem__line" style="width: 84%"></span>
        <span class="lp-problem__line" style="width: 96%"></span>
        <span class="lp-problem__line" style="width: 72%"></span>
        <span class="lp-problem__line" style="width: 88%"></span>
      </div>
      <div class="lp-problem__envelope">
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
        GSA clarification letter — respond within 5 business days
      </div>
    </figure>

    <div class="lp-problem__body reveal">
      <p>You've probably already looked at it. SAM.gov registration. eOffer. Pricing disclosures. A proposal package that runs dozens of pages before GSA even starts asking questions — and they will ask questions. Clarification letters, resubmissions, price negotiations with a contracting officer who reviews offers like yours all day.</p>
      <p>Do it yourself and you're signing up for months of back-and-forth in a system you'll use exactly once. Hand it to a one-man consultant and you risk something worse: a "paper mill" that files a template proposal, collects the fee, and disappears the day your contract is awarded — right when the real work starts.</p>
      <p>And the bar keeps rising. Since 2025, GSA has been actively cancelling Schedule contracts that don't meet sales minimums and tightening compliance reviews. Getting awarded is no longer the finish line. Keeping the contract alive and selling is.</p>
    </div>

    <div class="lp-compare reveal">
      <div class="lp-compare__col">
        <h3 class="lp-compare__head">Do it yourself</h3>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
          <span>Your evenings and weekends, for months</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
          <span>One shot to learn a one-time process</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
          <span>Nobody to call when GSA writes back</span>
        </div>
      </div>
      <div class="lp-compare__col">
        <h3 class="lp-compare__head">Typical consultant</h3>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path></svg>
          <span>Files the proposal, then gone</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path></svg>
          <span>No skin in your post-award game</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path></svg>
          <span>Hourly fees for every follow-up</span>
        </div>
      </div>
      <div class="lp-compare__col lp-compare__col--featured">
        <h3 class="lp-compare__head">
          <img src="/assets/mark-color.png" alt="" width="20" height="20" aria-hidden="true" />
          Price Reporter
        </h3>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
          <span>Prepares, negotiates, and stays on after award</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
          <span>Modifications, renewals, compliance, catalogs, orders</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
          <span>Clarifications and revisions handled by our team</span>
        </div>
      </div>
    </div>
  </div>
</section>
`,x=`<section class="lp-proof pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">What clients say after the award — not just after the sale</h2>
      <div class="lp-proof__chips">
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
          4.9 customer rating
        </span>
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
          BBB accredited, A+ rating
        </span>
      </div>
    </div>

    <div class="lp-proof__layout">
      <figure class="lp-proof__featured reveal">
        <svg class="lp-proof__mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
        <blockquote class="lp-proof__quote" data-readmore>
          <p>"For a number of years, they had been giving us a price algorithm where each of our items was priced a penny below the next competitor. A very unique position that gave us thousands of government orders. And for all the service given, their cost was far less than any other consulting firm we had contacted or worked with over the years. Thank you for supporting a veteran-owned small business."</p>
        </blockquote>
        <button type="button" class="lp-proof__readmore" data-readmore-btn hidden>Read more</button>
        <figcaption class="lp-proof__attr">
          <span class="pr-badge pr-badge--soft pr-badge--accent">Veteran-owned small business</span>
        </figcaption>
      </figure>

      <div class="lp-proof__rest reveal" data-carousel>
        <div class="lp-proof__track" data-carousel-track>
          <figure class="lp-proof__card">
            <svg class="lp-proof__card-mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
            <blockquote>
              <p>"The Price Reporter team has been efficient at managing our GSA contract catalogs for the past 5 years. They keep our catalogs well maintained and compliant, saving our resources and letting us focus on making sales."</p>
            </blockquote>
          </figure>
          <figure class="lp-proof__card">
            <svg class="lp-proof__card-mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
            <blockquote>
              <p>"We are a second-generation family-owned company and were uncertain what would be required. I fully recommend Price Reporter to any company looking for assistance with their government business endeavors. They were, and have continued to be, extremely helpful."</p>
            </blockquote>
          </figure>
        </div>
        <div class="lp-proof__dots" data-carousel-dots hidden></div>
      </div>
    </div>
  </div>
</section>
`,A=`<section class="lp-stats pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Why companies go through this at all</h2>
    </div>
    <div class="lp-stats__grid stagger">
      <div class="lp-stats__card">
        <span class="lp-stats__value">$2.3M</span>
        <span class="lp-stats__label">won in business each year by the average GSA Schedule holder through the program</span>
      </div>
      <div class="lp-stats__card">
        <span class="lp-stats__value">5&nbsp;→&nbsp;20 yrs</span>
        <span class="lp-stats__label">one contract, extendable term after term — a sales channel you build once and keep</span>
      </div>
      <div class="lp-stats__card">
        <span class="lp-stats__value">U.S. Gov</span>
        <span class="lp-stats__label">your buyer. They purchase everything, and they pay</span>
      </div>
    </div>
    <aside class="lp-stats__myth reveal">
      <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="8" y2="12"></line><line x1="12" x2="12.01" y1="16" y2="16"></line></svg>
      <em>And no — you don't have to be the cheapest. GSA looks for pricing that's fair and reasonable for the market, not the lowest number on the page.</em>
    </aside>
  </div>
</section>
`,S=`<section class="lp-team pr-section">
  <div class="pr-container-narrow">
    <div class="lp-team__inner reveal">
      <img class="lp-team__watermark" src="/assets/mark-mono.png" alt="" aria-hidden="true" />
      <img class="lp-team__mark" src="/assets/mark-color.png" alt="" width="44" height="44" aria-hidden="true" />
      <h2 class="lp-team__title">A team, not a middleman</h2>
      <span class="lp-team__rule" aria-hidden="true"></span>
      <p class="lp-team__body">Price Reporter has been doing business with GSA since 2006. Not as a side offering, not as one consultant with a template — a dedicated team of GSA experts whose entire work is winning contracts, managing them, and moving orders through the system. When GSA sends a clarification letter at 4&nbsp;PM on a Friday, it lands on our desk, not yours.</p>
    </div>
  </div>
</section>
`,C={header:o,hero:k,"trust-bar":f,problem:y,"how-it-works":g,quiz:w,services:m,"social-proof":x,"why-2026":_,stats:A,team:S,faq:b,"final-cta":v,footer:r,"sticky-bar":a,"exit-popup":u};Object.entries(C).forEach(([s,n])=>{const e=document.getElementById(s);e&&(e.innerHTML=n)});t();l();i();p();c();d();h();
