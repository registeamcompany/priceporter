import{S as a,F as t,H as i,i as r,a as o,b as l,c,d as p,e as d,f as u}from"./animations-Dz6X2--W.js";import{E as h,F as _,T as v,R as w}from"./ExitPopupB-CQszzB2k.js";/* empty css           */const m=`<section class="v2-hero v2-hero--photo" id="top">
  <span class="v2-hero__bg" aria-hidden="true"></span>
  <div class="pr-container v2-hero__container">
    <div class="v2-hero__topbar">
      <span class="v2-hero__brand">
        <img src="/assets/mark-color.png" alt="" width="30" height="30" aria-hidden="true" />
        <span class="v2-hero__wordmark"><b>PRICE</b>REPORTER</span>
      </span>
      <a class="v2-hero__topphone" href="tel:2015676646">
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
        201-567-6646
      </a>
    </div>
    <div class="v2-hero__grid">
      <div class="v2-hero__copy">
        <p class="v2-hero__eyebrow">GSA Schedule Consultants&nbsp;·&nbsp;Since 2006</p>
        <h1 class="v2-hero__title">Get Your GSA Contract. We Handle Everything&nbsp;Else.</h1>
        <span class="v2-hero__rule" aria-hidden="true"></span>
        <p class="v2-hero__sub">Federal buyers spend $52 billion a year through the GSA Schedule. Since 2006, our team has won hundreds of these contracts — we register you, build the proposal, negotiate with GSA, and run the contract after award. You keep doing business. We get you on the Schedule.</p>
        <p class="v2-hero__proof">"Both our contracts were accepted without rejection — the fastest we've ever been through the process with GSA."<span class="v2-hero__proof-who">— a repeat client, on their 3rd GSA contract</span></p>
        <div class="v2-hero__mobile-cta">
          <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-scroll-form>Get My Free Eligibility Assessment</button>
          <p class="v2-hero__micro">Takes 2 minutes. A GSA specialist replies within one business day.</p>
        </div>
        <p class="v2-hero__call">Or just call: <a href="tel:2015676646">201-567-6646</a></p>
      </div>
      <div class="v2-hero__visual">
        <div class="v2-hero__formwrap" id="lead-form-anchor">
          <form class="lp-form" data-lead-form novalidate>
            <div class="lp-form__fields">
              <div class="lp-form__head">
                <h3 class="lp-form__title">Find out if your company qualifies</h3>
                <p class="lp-form__sub">Takes 2 minutes. A GSA specialist replies within one business day.</p>
              </div>
              <label class="pr-field">
                <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
                <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Company <span class="pr-field__req">*</span></span>
                <span class="pr-input"><input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company name" /></span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
                <span class="pr-input">
                  <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
                  <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" />
                </span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
                <span class="pr-input">
                  <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
                  <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" />
                </span>
              </label>
              <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Check My Eligibility — Free</button>
              <p class="lp-form__fine">
                <svg class="ic ic--xs" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                Your details are used only to prepare your assessment. No lists, no resale.
              </p>
            </div>
            <div class="lp-form__success" hidden>
              <span class="lp-form__success-icon">
                <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
              </span>
              <h3>Request received</h3>
              <p>A GSA specialist will review your details and respond within one business day.</p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
`,g=`<section class="lp-trust pr-inverse" aria-label="Our numbers tell the story">
  <div class="pr-container">
    <p class="lp-trust__caps">Our numbers tell the story</p>
    <div class="lp-trust__grid stagger">
      <div class="lp-trust__item">
        <span class="lp-trust__big">20+</span>
        <span class="lp-trust__label">years working with GSA</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">400+</span>
        <span class="lp-trust__label">GSA contracts awarded</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">1000+</span>
        <span class="lp-trust__label">companies served</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">2.5M+</span>
        <span class="lp-trust__label">GSA orders processed</span>
      </div>
    </div>
    <p class="lp-trust__sub">1500+ contracts under management&nbsp;·&nbsp;20K+ modifications completed</p>
  </div>
</section>
`,b=`<section class="v2-stats pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">The most reliable customer your company will ever have</h2>
    </div>
    <div class="lp-prize__body lp-rail reveal">
      <p>The U.S. federal government buys everything — IT, office and industrial supplies, medical equipment, engineering, business services — across 62 categories of commercial products and services. A GSA Schedule works like a license to sell to every federal agency through one channel: GSA Advantage, government bids and RFQs, direct agency sales.</p>
    </div>
    <div class="v2-stats__panel reveal">
      <div class="v2-stats__cols">
        <div class="v2-stats__col">
          <span class="v2-stats__num">$2.3M</span>
          <span class="v2-stats__label">what the average Schedule holder wins in business every year</span>
        </div>
        <div class="v2-stats__col">
          <span class="v2-stats__num">5&nbsp;→&nbsp;20 yrs</span>
          <span class="v2-stats__label">one contract term, extendable for two decades of federal sales</span>
        </div>
        <div class="v2-stats__col">
          <span class="v2-stats__num">$52B</span>
          <span class="v2-stats__label">spent through the Schedule by federal buyers last year</span>
        </div>
      </div>
      <p class="v2-stats__myth">
        <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="8" y2="12"></line><line x1="12" x2="12.01" y1="16" y2="16"></line></svg>
        <em>And no — you don't have to be the cheapest to win. GSA looks for pricing that's fair and reasonable, not the lowest number in the room.</em>
      </p>
    </div>
    <p class="lp-prize__cta reveal">
      <button type="button" class="lp-prize__link" data-scroll-form>
        See if you qualify
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
      </button>
    </p>
  </div>
</section>
`,f=`<section class="lp-how pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Five steps to your contract. Your part is mostly step one.</h2>
    </div>
    <ol class="lp-how__timeline lp-how__timeline--five stagger">
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">1</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"></path></svg>
        </span>
        <h3 class="lp-how__title">Free evaluation</h3>
        <p class="lp-how__text">One conversation with a GSA expert: we check your company against GSA requirements and, using our market intelligence tools, measure real federal demand for what you sell. Straight answer either way.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">2</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"></path><path d="M14 2v5a1 1 0 0 0 1 1h5"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>
        </span>
        <h3 class="lp-how__title">We build your proposal</h3>
        <p class="lp-how__text">We register you with SAM.gov, help secure your Past Performance Assessment, and assemble the full package — catalog, financials, marketing materials — then submit it for government review. You supply documents. We do the paperwork.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">3</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.119 2.205a2 2 0 0 1 1.762 0l7.84 3.846A.5.5 0 0 1 20.5 7h-17a.5.5 0 0 1-.22-.949z"></path><path d="M10 18v-7"></path><path d="M14 18v-7"></path><path d="M18 18v-7"></path><path d="M3 22h18"></path><path d="M6 18v-7"></path></svg>
        </span>
        <h3 class="lp-how__title">We negotiate with GSA for you</h3>
        <p class="lp-how__text">GSA always negotiates before an award — prices, discounts, terms. Our experts lead that process so you end up with terms you can actually make money on, not just any terms.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">4</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
        </span>
        <h3 class="lp-how__title">Award: your catalog goes live</h3>
        <p class="lp-how__text">We publish your full catalog on GSA Advantage — descriptions, specs, pricing, images — so federal buyers can start purchasing immediately.</p>
      </li>
      <li class="lp-how__step lp-how__step--featured">
        <div class="lp-how__marker">
          <span class="lp-how__num">5</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 7h6v6"></path><path d="m22 7-8.5 8.5-5-5L2 17"></path></svg>
        </span>
        <h3 class="lp-how__title">We stay on and grow it</h3>
        <p class="lp-how__text">Competitor research, pricing optimization, adding the products GSA buys most, compliance, modifications, renewals. The award is where our longest work begins.</p>
      </li>
    </ol>
    <div class="lp-how__cta reveal">
      <button type="button" class="pr-btn pr-btn--accent pr-btn--lg" data-scroll-form>Start With the Free Evaluation</button>
    </div>
  </div>
</section>
`,y=`<section class="lp-proof pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Clients who came back for their next contract</h2>
      <div class="lp-proof__chips">
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
          4.9 customer rating
        </span>
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
          BBB accredited, A+ rating
        </span>
      </div>
    </div>

    <div class="v2-cases stagger">
      <article class="v2-case v2-case--featured">
        <div class="v2-case__top">
          <span class="v2-case__logo">Лого клієнта</span>
          <span class="pr-badge pr-badge--soft pr-badge--accent">Repeat client</span>
        </div>
        <div class="v2-case__metrics">
          <div class="v2-case__metric">
            <span class="v2-case__num">3rd</span>
            <span class="v2-case__metric-label">GSA contract — their 2nd done with our team</span>
          </div>
          <div class="v2-case__metric">
            <span class="v2-case__num">0</span>
            <span class="v2-case__metric-label">rejections — both contracts accepted, minimal negotiations</span>
          </div>
        </div>
        <blockquote class="v2-case__quote">
          <p>"Price Reporter recently helped us with our 3rd GSA contract, the 2nd they did with us. It was the fastest we've ever been through the process with GSA. Each step was easy because the ground work was done before we were asked to do anything. Our pricing verification phase went smooth and quickly, and both our contracts were accepted without rejection, with minimal negotiations with contracting."</p>
        </blockquote>
      </article>

      <article class="v2-case">
        <div class="v2-case__top">
          <span class="v2-case__logo">Лого клієнта</span>
          <span class="pr-badge pr-badge--soft pr-badge--brand">Veteran-owned small business</span>
        </div>
        <div class="v2-case__metrics">
          <div class="v2-case__metric">
            <span class="v2-case__num">1¢</span>
            <span class="v2-case__metric-label">below the next competitor — thousands of government orders</span>
          </div>
        </div>
        <blockquote class="v2-case__quote">
          <p>"For a number of years, they had been giving us a price algorithm where each of our items was priced a penny below the next competitor. A very unique position that gave us thousands of government orders. And for all the service given, their cost was far less than any other consulting firm we had worked with."</p>
        </blockquote>
      </article>

      <article class="v2-case">
        <div class="v2-case__top">
          <span class="v2-case__logo">Лого клієнта</span>
        </div>
        <div class="v2-case__metrics">
          <div class="v2-case__metric">
            <span class="v2-case__num">5 yrs</span>
            <span class="v2-case__metric-label">of GSA catalogs kept maintained and compliant</span>
          </div>
        </div>
        <blockquote class="v2-case__quote">
          <p>"The Price Reporter team has been efficient at managing our GSA contract catalogs for the past 5 years. They keep our catalogs well maintained and compliant, saving our resources and letting us focus on making sales."</p>
        </blockquote>
      </article>
    </div>
    <p class="v2-cases__note">Кейси — приклад структури для макета. Реальні цифри, цитати й лого клієнтів — після погодження.</p>
  </div>
</section>
`,k=`<section class="lp-services pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Consultants file paperwork. We run the whole machine.</h2>
      <p class="pr-sectionhead__sub">Most GSA consultants do one thing: submit your proposal. Our work starts there and continues for as long as you hold the contract — because winning the award and making money from it are two different jobs.</p>
    </div>
    <div class="lp-services__grid stagger">
      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-doc">
            <span class="lp-svc-doc__tag">GSA MAS proposal</span>
            <span class="lp-svc-doc__line" style="width: 86%"></span>
            <span class="lp-svc-doc__line" style="width: 68%"></span>
            <span class="lp-svc-doc__line" style="width: 92%"></span>
            <span class="lp-svc-doc__line" style="width: 55%"></span>
            <span class="lp-svc-doc__stamp">Awarded</span>
          </div>
        </div>
        <h3 class="lp-services__title">Win it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Company evaluation, market demand analysis, proposal preparation, SAM.gov registration, Past Performance support, and negotiation with GSA — clarifications and revisions included, not billed as extras.</p>
      </article>

      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-list">
            <div class="lp-svc-list__row">
              <span>Modification #2041</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Approved</span>
            </div>
            <div class="lp-svc-list__row">
              <span>Option renewal</span>
              <span class="lp-svc-chip lp-svc-chip--proc">2027</span>
            </div>
            <div class="lp-svc-list__row">
              <span>TAA compliance check</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Passed</span>
            </div>
          </div>
        </div>
        <h3 class="lp-services__title">Run it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Contract modifications, new SINs, five-year renewals, TAA compliance, IFF and TDR reporting, catalog updates on GSA Advantage. When GSA writes, we answer.</p>
      </article>

      <article class="lp-services__card lp-services__card--oms">
        <div class="lp-svc-mock" aria-hidden="true">
        <div class="lp-oms">
          <div class="lp-oms__chrome">
            <span class="lp-oms__dot"></span><span class="lp-oms__dot"></span><span class="lp-oms__dot"></span>
            <span class="lp-oms__chrome-title">Order Management System</span>
          </div>
          <div class="lp-oms__row lp-oms__row--head">
            <span>Order</span><span>Agency</span><span>Status</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471820</span><span>GSA Advantage</span><span class="lp-oms__chip lp-oms__chip--ok">Shipped</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471819</span><span>DLA</span><span class="lp-oms__chip lp-oms__chip--proc">Processing</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471818</span><span>FedMall</span><span class="lp-oms__chip lp-oms__chip--ok">Invoiced</span>
          </div>
        </div>
        </div>
        <h3 class="lp-services__title">Grow it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Our own Order Management System — over 1,000,000 federal orders processed — plus competitive price positioning against named competitors, catalog expansion with the products GSA buys most, and support for DOD, DLA, FedMall, and BPA. With EDI, QuickBooks, and Amazon integrations.</p>
      </article>
    </div>
  </div>
</section>
`,q=`<section class="lp-quiz pr-inverse pr-section" id="quiz-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Would GSA buy what you sell? Find out in 60 seconds.</h2>
      <p class="pr-sectionhead__sub">GSA has real requirements — at least two years in business and a track record of revenue. Four quick questions, and a specialist gives you an honest read within one business day.</p>
    </div>

    <div class="lp-quiz__card reveal" data-quiz>
      <div class="lp-quiz__top">
        <div class="lp-quiz__progress" data-quiz-progress-wrap>
          <span class="lp-quiz__progress-label" data-quiz-progress-label>Question 1 of 4</span>
          <span class="lp-quiz__bar"><span class="lp-quiz__bar-fill" data-quiz-progress-fill style="width: 25%"></span></span>
        </div>
        <span class="lp-quiz__timer">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>
          60 seconds
        </span>
      </div>

      <div class="lp-quiz__step" data-quiz-step="0">
        <h3 class="lp-quiz__q">How long has your company been in business?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Under 2 years">Under 2 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="2–5 years">2–5 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="5+ years">5+ years</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="1" hidden>
        <h3 class="lp-quiz__q">Is your annual revenue above $100K?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Yes">Yes</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Not yet">Not yet</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Prefer to discuss">Prefer to discuss</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="2" hidden>
        <h3 class="lp-quiz__q">What do you sell?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Products">Products</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Services">Services</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Both">Both</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="3" hidden>
        <h3 class="lp-quiz__q">Are your products U.S.-made or TAA-compliant?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Yes">Yes</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="No">No</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Not sure">Not sure</button>
        </div>
      </div>

      <form class="lp-quiz__step lp-quiz__contact" data-quiz-step="4" data-quiz-contact hidden novalidate>
        <h3 class="lp-quiz__q">Where should we send your result?</h3>
        <label class="pr-field">
          <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" /></span>
        </label>
        <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Get My Result</button>
      </form>

      <div class="lp-quiz__step lp-quiz__result" data-quiz-step="result" hidden>
        <span class="lp-form__success-icon">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
        </span>
        <p class="lp-quiz__result-text">Thanks — a GSA specialist will review your answers and come back within one business day with a realistic read on your eligibility, including what to fix if you're not there yet. No pressure, no script.</p>
      </div>

      <button type="button" class="lp-quiz__back" data-quiz-back hidden>
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"></path></svg>
        Back
      </button>
    </div>
  </div>
</section>
`,x=`<section class="v2-team pr-section">
  <div class="pr-container v2-team__grid">
    <div class="v2-team__copy reveal">
      <h2 class="v2-team__title">Since 2006. Still picking up the phone.</h2>
      <span class="v2-team__rule" aria-hidden="true"></span>
      <p class="v2-team__body">Price Reporter is a dedicated team of GSA experts — not a directory of freelancers, not a side service. Winning Schedule contracts, managing them, and moving federal orders through the system is all we do. When your contracting officer has a question on a Friday afternoon, it lands on our desk, not yours.</p>
      <a class="pr-btn pr-btn--secondary v2-team__video" href="https://pricereporter.com/get-gsa-contract/" target="_blank" rel="noopener">
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polygon points="10 8 16 12 10 16 10 8"></polygon></svg>
        Watch: How To Get a GSA Contract
      </a>
    </div>
    <figure class="v2-team__photo reveal">
      <div class="v2-ph v2-team__ph">
        <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"></path><path d="m17 8-5-5-5 5"></path><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path></svg>
        <span class="v2-ph__label">Місце під фото</span>
        <p class="v2-ph__desc">Реальна робоча сцена команди — стіл, екрани з інтерфейсами, документи. Без постановки і стоку</p>
      </div>
      <span class="v2-team__badge">
        <img src="/assets/mark-color.png" alt="" width="18" height="18" aria-hidden="true" />
        Working with GSA since 2006
      </span>
    </figure>
  </div>
</section>
`,A=`<section class="lp-faq pr-band pr-section">
  <div class="lp-faq__container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">FAQ</h2>
    </div>
    <div class="pr-acc reveal" data-faq>
      <div class="pr-acc__item" data-faq-item data-open-desktop>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          How long does it take to get a GSA contract?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>When everything is done right, about 6 months from application to award. The timeline depends on how accurate the submitted package is, your product category, and your GSA Contracting Officer — reviewing a single offer takes them 30 days at minimum. That's exactly why the package has to be right the first time: every error adds a round trip. Preparing packages that don't bounce is our job.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What are the requirements?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>The basics: at least two years in business, annual revenue of $100,000+ for two consecutive years, stable financials, and for some categories — documented experience. The free assessment tells you where you stand in one conversation.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          How much does it cost?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>It depends on what you sell and the scope of work, so we quote after your free assessment — once we've actually looked at your business. You'll know the full picture before you commit to anything.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Can't I just apply myself?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>You can. You'll be registering on SAM.gov, obtaining a Past Performance Assessment, choosing your category, preparing pricing disclosures and a full proposal, and handling negotiation rounds with a contracting officer — a process you'll learn from scratch and use once. Simple mistakes get proposals rejected immediately. Most owners who call us either started down that road and stalled, or decided their time was worth more than the tuition.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What happens if GSA sends the offer back with questions?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Clarifications and negotiation rounds are a normal part of nearly every award — GSA always negotiates prices and terms before awarding. Handling that back-and-forth is included in our work, not billed as extras.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Do I have to offer the government my lowest price?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>No. GSA looks for pricing that's fair and reasonable for the market — and negotiating terms you can actually sustain and profit from is a core part of what we do in Step 3.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What happens after I get the contract?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>That's where most consultants leave and where we stay: your catalog on GSA Advantage, modifications, new SINs, renewals, TAA compliance, IFF/TDR reporting, competitor price monitoring, and order management — our system has processed over 1,000,000 federal orders.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Do you work beyond GSA — DOD, DLA, FedMall?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Yes: DOD orders, DLA, FedMall, and BPA contracts, with EDI, QuickBooks, and Amazon integrations on the order side.</p>
        </div>
      </div>
    </div>
  </div>
</section>
`,z={header:i,hero:m,"trust-bar":g,prize:b,"how-it-works":f,reassurance:w,"social-proof":y,"why-pr":k,quiz:q,timing:v,team:x,faq:A,"final-cta":_,footer:t,"sticky-bar":a,"exit-popup":h};Object.entries(z).forEach(([n,e])=>{const s=document.getElementById(n);s&&(s.innerHTML=e)});r();o();l();c();p();d();u();
