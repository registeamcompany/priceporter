import{S as e,F as t,H as l,i as r,a as i,b as o,c as p,d as c,e as d,f as u}from"./animations-Dz6X2--W.js";/* empty css             */import{E as h,F as _,T as v,R as w}from"./ExitPopupB-CQszzB2k.js";import{F as m}from"./Faq-B36MIU_r.js";const g=`<section class="lp-hero" id="top">
  <span class="lp-hero__photo" aria-hidden="true"></span>
  <div class="pr-container lp-hero__container">
    <div class="lp-hero__topbar">
      <img src="/assets/logo-horizontal-color.png" alt="Price Reporter" height="34" />
      <a class="lp-hero__topphone" href="tel:2015676646">
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
        201-567-6646
      </a>
    </div>
    <div class="lp-hero__grid">
      <div class="lp-hero__copy">
        <p class="lp-hero__eyebrow">GSA Schedule Consultants&nbsp;·&nbsp;Since 2006</p>
        <h1 class="lp-hero__title">Get Your GSA Contract. We Handle Everything&nbsp;Else.</h1>
        <span class="lp-hero__rule" aria-hidden="true"></span>
        <p class="lp-hero__sub">The federal government buys $52 billion a year through the GSA Schedule. Since 2006, we've won hundreds of these contracts for companies like yours — preparing the proposal, negotiating with GSA, and running the contract after award. You keep doing business. We get you your share.</p>
        <div class="lp-hero__mobile-cta">
          <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-scroll-form>Get My Free Eligibility Assessment</button>
          <p class="lp-hero__micro">Takes 2 minutes. A GSA specialist replies within one business day.</p>
        </div>
        <p class="lp-hero__call">Or just call: <a href="tel:2015676646">201-567-6646</a></p>
      </div>
      <div class="lp-hero__formwrap" id="lead-form-anchor">
        <form class="lp-form" data-lead-form novalidate>
          <div class="lp-form__fields">
            <div class="lp-form__head">
              <h3 class="lp-form__title">Find out if your company qualifies</h3>
              <p class="lp-form__sub">Takes 2 minutes. A GSA specialist replies within one business day.</p>
            </div>
            <label class="pr-field">
              <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
              <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
            </label>
            <label class="pr-field">
              <span class="pr-field__label">Company <span class="pr-field__req">*</span></span>
              <span class="pr-input"><input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company name" /></span>
            </label>
            <label class="pr-field">
              <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
              <span class="pr-input">
                <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
                <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" />
              </span>
            </label>
            <label class="pr-field">
              <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
              <span class="pr-input">
                <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
                <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" />
              </span>
            </label>
            <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Check My Eligibility — Free</button>
            <p class="lp-form__fine">
              <svg class="ic ic--xs" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
              Your details are used only to prepare your assessment. No lists, no resale.
            </p>
          </div>
          <div class="lp-form__success" hidden>
            <span class="lp-form__success-icon">
              <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
            </span>
            <h3>Request received</h3>
            <p>A GSA specialist will review your details and respond within one business day.</p>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
`,b=`<section class="lp-trust pr-inverse" aria-label="Track record">
  <div class="pr-container">
    <div class="lp-trust__grid stagger">
      <div class="lp-trust__item">
        <span class="lp-trust__big">Since 2006</span>
        <span class="lp-trust__label">in the GSA marketplace</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">Hundreds</span>
        <span class="lp-trust__label">of contracts awarded</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">1,000,000+</span>
        <span class="lp-trust__label">federal orders processed</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">One team</span>
        <span class="lp-trust__label">from proposal to renewal</span>
      </div>
    </div>
  </div>
</section>
`,f=`<section class="lp-prize pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">The most reliable customer your company will ever have</h2>
    </div>
    <div class="lp-prize__body lp-rail reveal">
      <p>The U.S. federal government buys everything — office supplies, medical equipment, software, services, hardware, furniture — and it never stops buying. A GSA Schedule contract puts your products in front of every federal agency through one channel, at pre-negotiated prices, for years at a time.</p>
    </div>
    <div class="lp-stats__grid stagger">
      <div class="lp-stats__card">
        <span class="lp-stats__value">$2.3M</span>
        <span class="lp-stats__label">what the average Schedule holder wins in business every year</span>
      </div>
      <div class="lp-stats__card">
        <span class="lp-stats__value">5 yrs</span>
        <span class="lp-stats__label">your contract term, extendable up to 20 years total</span>
      </div>
      <div class="lp-stats__card">
        <span class="lp-stats__value">$52B</span>
        <span class="lp-stats__label">what federal buyers spent through the Schedule last year</span>
      </div>
    </div>
    <aside class="lp-stats__myth reveal">
      <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="8" y2="12"></line><line x1="12" x2="12.01" y1="16" y2="16"></line></svg>
      <em>And no, you don't need to be the cheapest to win. GSA looks for pricing that's fair and reasonable — not the lowest number in the room.</em>
    </aside>
    <p class="lp-prize__cta reveal">
      <button type="button" class="lp-prize__link" data-scroll-form>
        See if you qualify
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
      </button>
    </p>
  </div>
</section>
`,y=`<section class="lp-how pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Four steps. Your part is mostly step one.</h2>
    </div>
    <ol class="lp-how__timeline stagger">
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">1</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"></path></svg>
        </span>
        <h3 class="lp-how__title">Tell us about your business</h3>
        <p class="lp-how__text">A free eligibility assessment: we review your company, products, and pricing and give you a straight answer on whether GSA is your market. Takes one conversation.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">2</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"></path><path d="M14 2v5a1 1 0 0 0 1 1h5"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>
        </span>
        <h3 class="lp-how__title">We build the offer</h3>
        <p class="lp-how__text">Credentials, competitor assessment, catalog, financials, pricing strategy — our team assembles the full proposal package. You supply documents; we do the rest.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">3</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.119 2.205a2 2 0 0 1 1.762 0l7.84 3.846A.5.5 0 0 1 20.5 7h-17a.5.5 0 0 1-.22-.949z"></path><path d="M10 18v-7"></path><path d="M14 18v-7"></path><path d="M18 18v-7"></path><path d="M3 22h18"></path><path d="M6 18v-7"></path></svg>
        </span>
        <h3 class="lp-how__title">We negotiate with GSA for you</h3>
        <p class="lp-how__text">Every clarification, resubmission, and pricing round with your contracting officer is handled by people who've done it hundreds of times.</p>
      </li>
      <li class="lp-how__step lp-how__step--featured">
        <div class="lp-how__marker">
          <span class="lp-how__num">4</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 7h6v6"></path><path d="m22 7-8.5 8.5-5-5L2 17"></path></svg>
        </span>
        <h3 class="lp-how__title">Your catalog goes live. Orders follow.</h3>
        <p class="lp-how__text">We publish you on GSA Advantage, keep your prices positioned against competitors, and manage the contract year after year — modifications, renewals, compliance, reporting.</p>
      </li>
    </ol>
    <div class="lp-how__cta reveal">
      <button type="button" class="pr-btn pr-btn--accent pr-btn--lg" data-scroll-form>Start With the Free Assessment</button>
    </div>
  </div>
</section>
`,k=`<section class="lp-proof pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Clients who stayed after the award</h2>
      <div class="lp-proof__chips">
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
          4.9 customer rating
        </span>
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
          BBB accredited, A+ rating
        </span>
      </div>
    </div>

    <div class="lp-proof__layout">
      <figure class="lp-proof__featured reveal">
        <svg class="lp-proof__mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
        <blockquote class="lp-proof__quote" data-readmore>
          <p>"For a number of years, they had been giving us a price algorithm where each of our items was priced a penny below the next competitor. A very unique position that gave us thousands of government orders. And for all the service given, their cost was far less than any other consulting firm we had contacted or worked with over the years. Thank you for supporting a veteran-owned small business."</p>
        </blockquote>
        <button type="button" class="lp-proof__readmore" data-readmore-btn hidden>Read more</button>
        <figcaption class="lp-proof__attr">
          <span class="pr-badge pr-badge--soft pr-badge--accent">Veteran-owned small business</span>
        </figcaption>
      </figure>

      <div class="lp-proof__rest reveal" data-carousel>
        <div class="lp-proof__track" data-carousel-track>
          <figure class="lp-proof__card">
            <svg class="lp-proof__card-mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
            <blockquote>
              <p>"The Price Reporter team has been efficient at managing our GSA contract catalogs for the past 5 years. They keep our catalogs well maintained and compliant, saving our resources and letting us focus on making sales."</p>
            </blockquote>
          </figure>
          <figure class="lp-proof__card">
            <svg class="lp-proof__card-mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
            <blockquote>
              <p>"We are a second-generation family-owned company and were uncertain what would be required. I fully recommend Price Reporter to any company looking for assistance with their government business endeavors."</p>
            </blockquote>
          </figure>
        </div>
        <div class="lp-proof__dots" data-carousel-dots hidden></div>
      </div>
    </div>
  </div>
</section>
`,q=`<section class="lp-services pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Consultants file paperwork. We run the whole machine.</h2>
      <p class="pr-sectionhead__sub">Most GSA consultants do one thing: submit your proposal. Our work starts there and keeps going for as long as you hold the contract — because winning the award and making money from it are two different jobs.</p>
    </div>
    <div class="lp-services__grid stagger">
      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-doc">
            <span class="lp-svc-doc__tag">GSA MAS proposal</span>
            <span class="lp-svc-doc__line" style="width: 86%"></span>
            <span class="lp-svc-doc__line" style="width: 68%"></span>
            <span class="lp-svc-doc__line" style="width: 92%"></span>
            <span class="lp-svc-doc__line" style="width: 55%"></span>
            <span class="lp-svc-doc__stamp">Awarded</span>
          </div>
        </div>
        <h3 class="lp-services__title">Win it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Proposal preparation, competitor assessment, federal market intelligence, and negotiation with GSA — clarifications and revisions included, not billed as extras.</p>
      </article>

      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-list">
            <div class="lp-svc-list__row">
              <span>Modification #2041</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Approved</span>
            </div>
            <div class="lp-svc-list__row">
              <span>Option renewal</span>
              <span class="lp-svc-chip lp-svc-chip--proc">2027</span>
            </div>
            <div class="lp-svc-list__row">
              <span>TAA compliance check</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Passed</span>
            </div>
          </div>
        </div>
        <h3 class="lp-services__title">Run it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Contract modifications, new SINs, five-year renewals, TAA compliance, IFF and TDR reporting. When GSA writes, we answer.</p>
      </article>

      <article class="lp-services__card lp-services__card--oms">
        <div class="lp-svc-mock" aria-hidden="true">
        <div class="lp-oms">
          <div class="lp-oms__chrome">
            <span class="lp-oms__dot"></span><span class="lp-oms__dot"></span><span class="lp-oms__dot"></span>
            <span class="lp-oms__chrome-title">Order Management System</span>
          </div>
          <div class="lp-oms__row lp-oms__row--head">
            <span>Order</span><span>Agency</span><span>Status</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471820</span><span>GSA Advantage</span><span class="lp-oms__chip lp-oms__chip--ok">Shipped</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471819</span><span>DLA</span><span class="lp-oms__chip lp-oms__chip--proc">Processing</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471818</span><span>FedMall</span><span class="lp-oms__chip lp-oms__chip--ok">Invoiced</span>
          </div>
        </div>
        </div>
        <h3 class="lp-services__title">Grow it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Our own Order Management System — over 1,000,000 federal orders processed — plus catalog management on GSA Advantage, competitive price positioning, and support for DOD, DLA, FedMall, and BPA. With EDI, QuickBooks, and Amazon integrations.</p>
      </article>
    </div>
  </div>
</section>
`,z=`<section class="lp-quiz pr-inverse pr-section" id="quiz-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Would GSA buy what you sell? Find out in 60 seconds.</h2>
      <p class="pr-sectionhead__sub">Four quick questions, an honest answer from a specialist within one business day.</p>
    </div>

    <div class="lp-quiz__card reveal" data-quiz>
      <div class="lp-quiz__top">
        <div class="lp-quiz__progress" data-quiz-progress-wrap>
          <span class="lp-quiz__progress-label" data-quiz-progress-label>Question 1 of 4</span>
          <span class="lp-quiz__bar"><span class="lp-quiz__bar-fill" data-quiz-progress-fill style="width: 25%"></span></span>
        </div>
        <span class="lp-quiz__timer">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>
          60 seconds
        </span>
      </div>

      <div class="lp-quiz__step" data-quiz-step="0">
        <h3 class="lp-quiz__q">How long has your company been in business?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Under 2 years">Under 2 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="2–5 years">2–5 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="5+ years">5+ years</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="1" hidden>
        <h3 class="lp-quiz__q">What do you sell?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Products">Products</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Services">Services</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Both">Both</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="2" hidden>
        <h3 class="lp-quiz__q">Are your products made in the U.S. or TAA-compliant countries?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Yes">Yes</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="No">No</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Not sure">Not sure</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="3" hidden>
        <h3 class="lp-quiz__q">Have you sold to any government buyer before?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Yes">Yes</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="No">No</button>
        </div>
      </div>

      <form class="lp-quiz__step lp-quiz__contact" data-quiz-step="4" data-quiz-contact hidden novalidate>
        <h3 class="lp-quiz__q">Where should we send your result?</h3>
        <label class="pr-field">
          <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" /></span>
        </label>
        <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Get My Result</button>
      </form>

      <div class="lp-quiz__step lp-quiz__result" data-quiz-step="result" hidden>
        <span class="lp-form__success-icon">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
        </span>
        <p class="lp-quiz__result-text">Thanks — a GSA specialist will review your answers and come back within one business day with a realistic read on your eligibility. No pressure, no script.</p>
      </div>

      <button type="button" class="lp-quiz__back" data-quiz-back hidden>
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"></path></svg>
        Back
      </button>
    </div>
  </div>
</section>
`,x=`<section class="lp-team pr-section">
  <div class="pr-container-narrow">
    <div class="lp-team__inner reveal">
      <img class="lp-team__watermark" src="/assets/mark-mono.png" alt="" aria-hidden="true" />
      <img class="lp-team__mark" src="/assets/mark-color.png" alt="" width="44" height="44" aria-hidden="true" />
      <h2 class="lp-team__title">Since 2006. Still picking up the phone.</h2>
      <span class="lp-team__rule" aria-hidden="true"></span>
      <p class="lp-team__body">Price Reporter is a dedicated team of GSA experts — not a directory of freelancers, not a side service. Winning Schedule contracts, managing them, and moving federal orders through the system is all we do. When your contracting officer has a question on a Friday afternoon, it lands on our desk, not yours.</p>
    </div>
  </div>
</section>
`,A={header:l,hero:g,"trust-bar":b,prize:f,"how-it-works":y,reassurance:w,"social-proof":k,"why-pr":q,quiz:z,timing:v,team:x,faq:m,"final-cta":_,footer:t,"sticky-bar":e,"exit-popup":h};Object.entries(A).forEach(([n,a])=>{const s=document.getElementById(n);s&&(s.innerHTML=a)});r();i();o();p();c();d();u();
