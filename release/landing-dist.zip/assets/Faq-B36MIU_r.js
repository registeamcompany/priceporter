const e=`<section class="lp-faq pr-band pr-section">
  <div class="lp-faq__container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">FAQ</h2>
    </div>
    <div class="pr-acc reveal" data-faq>
      <div class="pr-acc__item" data-faq-item data-open-desktop>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          How long does it take to get on the GSA Schedule?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Months, not weeks — the honest answer depends on your product category, how complete your documentation is, and GSA's current review queue. What we control, we compress: your proposal package is built by people who have done this hundreds of times, and every clarification from GSA gets answered fast. The free assessment will give you a realistic picture for your specific case.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          How much does it cost?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Pricing depends on what you sell and the scope of work, so we quote it after your free eligibility assessment — once we've actually looked at your business, not before. No surprises after the fact: you'll know the full picture before you commit to anything.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Can't I just apply myself? The government sites are free.
        </button>
        <div class="pr-acc__panel" hidden>
          <p>You can, and some companies do. You'll be registering on SAM.gov, preparing pricing disclosures, assembling a full proposal package, and handling negotiation rounds with a contracting officer — a process you'll learn from scratch and use once. Most owners who call us have either started down that road and stalled, or decided their time was worth more than the tuition.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What happens if GSA sends the offer back with questions?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>That's normal — clarifications, resubmissions, and price negotiations are part of nearly every award. Handling that back-and-forth is included in our work, not billed as extras.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Do I qualify for a GSA Schedule?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>The basics: an established business, products or services the government buys, TAA-compliant sourcing, and pricing you can document. The 60-second quiz above will give you a first read, and the free assessment gives you a definitive one.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          I've heard GSA is cancelling contracts now. Is it still worth it?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Yes — and that's precisely why preparation matters more than it used to. GSA is removing contracts that don't sell and vendors that don't comply. The program itself did roughly $52 billion in sales last year. The opportunity hasn't shrunk; the tolerance for sloppy contracts has.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What happens after I get the contract?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>That's where most consultants leave and where we stay: catalog uploads to GSA Advantage, contract modifications, adding SINs, five-year renewals, TAA compliance, IFF and TDR reporting, and competitive price positioning. Our Order Management System has processed over a million federal orders for clients.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Do you work with businesses outside GSA — DOD, DLA, FedMall?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Yes. Beyond the GSA Schedule we support DOD orders, DLA, FedMall, and BPA contracts, with EDI, QuickBooks, and Amazon integrations on the order side.</p>
        </div>
      </div>
    </div>
  </div>
</section>
`;export{e as F};
