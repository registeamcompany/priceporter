import{S as a,F as t,H as r,i as o,a as i,b as l,c,d as p,e as d,f as h}from"./animations-Dz6X2--W.js";import{E as v,F as u,W as _,S as m,Q as w,H as g,T as f}from"./ExitPopup-DiWYhf-x.js";/* empty css           */import{F as k}from"./Faq-B36MIU_r.js";const b=`<section class="v2-hero" id="top">
  <div class="v2-hero__stripes" aria-hidden="true">
    <span></span><span></span><span></span>
  </div>
  <div class="pr-container v2-hero__container">
    <div class="v2-hero__topbar">
      <img src="/assets/logo-horizontal-color.png" alt="Price Reporter" height="34" />
      <a class="v2-hero__topphone" href="tel:2015676646">
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
        201-567-6646
      </a>
    </div>
    <div class="v2-hero__grid">
      <div class="v2-hero__copy">
        <p class="v2-hero__eyebrow">GSA Schedule Consultants&nbsp;·&nbsp;Working with GSA since 2006</p>
        <h1 class="v2-hero__title">Get Your GSA Schedule Contract. Then Actually Sell With&nbsp;It.</h1>
        <span class="v2-hero__rule" aria-hidden="true"></span>
        <p class="v2-hero__sub">We've secured hundreds of GSA contracts and processed over 1,000,000 federal orders for our clients. Our team prepares your proposal, negotiates with GSA on your behalf, and stays on after award — because a contract that doesn't produce orders is just expensive paperwork.</p>
        <div class="v2-hero__mobile-cta">
          <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-scroll-form>Get My Free Eligibility Assessment</button>
          <p class="v2-hero__micro">No obligation. A GSA specialist responds within one business day.</p>
        </div>
        <p class="v2-hero__call">Prefer to talk it through? Call <a href="tel:2015676646">201-567-6646</a>.</p>
      </div>
      <div class="v2-hero__visual">
        <div class="v2-hero__photo" aria-hidden="true">
          <span class="v2-hero__photo-note">
            <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"></path><path d="m17 8-5-5-5 5"></path><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path></svg>
            Фото: федеральна архітектура, світле, синій дуотон
          </span>
        </div>
        <div class="v2-hero__formwrap" id="lead-form-anchor">
          <form class="lp-form" data-lead-form novalidate>
            <div class="lp-form__fields">
              <div class="lp-form__head">
                <h3 class="lp-form__title">Get My Free Eligibility Assessment</h3>
                <p class="lp-form__sub">No obligation. A GSA specialist responds within one business day.</p>
              </div>
              <label class="pr-field">
                <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
                <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Company <span class="pr-field__req">*</span></span>
                <span class="pr-input"><input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company name" /></span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
                <span class="pr-input">
                  <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
                  <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" />
                </span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
                <span class="pr-input">
                  <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
                  <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" />
                </span>
              </label>
              <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Check My Eligibility — Free</button>
              <p class="lp-form__fine">
                <svg class="ic ic--xs" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                Your details are used only to prepare your assessment. No lists, no resale.
              </p>
            </div>
            <div class="lp-form__success" hidden>
              <span class="lp-form__success-icon">
                <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
              </span>
              <h3>Request received</h3>
              <p>A GSA specialist will review your details and respond within one business day.</p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
`,y=`<section class="lp-problem pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Federal buyers spent $52 billion through the GSA Schedule last year. The paperwork is where most companies give&nbsp;up.</h2>
    </div>

    <div class="v2-problem__grid">
      <figure class="v2-problem__photo reveal" aria-hidden="true">
        <div class="v2-ph v2-problem__ph">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"></path><path d="m17 8-5-5-5 5"></path><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path></svg>
          <span class="v2-ph__label">Місце під фото</span>
          <p class="v2-ph__desc">Стос форм і документів процесу — SAM.gov, eOffer, цінові розкриття. Реальні артефакти, без стоку</p>
        </div>
        <span class="v2-problem__stamp">Clarification requested</span>
        <span class="v2-problem__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
          GSA clarification letter — respond within 5 business days
        </span>
      </figure>
      <div class="v2-problem__body reveal">
        <p>You've probably already looked at it. SAM.gov registration. eOffer. Pricing disclosures. A proposal package that runs dozens of pages before GSA even starts asking questions — and they will ask questions. Clarification letters, resubmissions, price negotiations with a contracting officer who reviews offers like yours all day.</p>
        <p>Do it yourself and you're signing up for months of back-and-forth in a system you'll use exactly once. Hand it to a one-man consultant and you risk something worse: a "paper mill" that files a template proposal, collects the fee, and disappears the day your contract is awarded — right when the real work starts.</p>
        <p>And the bar keeps rising. Since 2025, GSA has been actively cancelling Schedule contracts that don't meet sales minimums and tightening compliance reviews. Getting awarded is no longer the finish line. Keeping the contract alive and selling is.</p>
      </div>
    </div>

    <div class="lp-compare reveal">
      <div class="lp-compare__col">
        <h3 class="lp-compare__head">Do it yourself</h3>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
          <span>Your evenings and weekends, for months</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
          <span>One shot to learn a one-time process</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
          <span>Nobody to call when GSA writes back</span>
        </div>
      </div>
      <div class="lp-compare__col">
        <h3 class="lp-compare__head">Typical consultant</h3>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path></svg>
          <span>Files the proposal, then gone</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path></svg>
          <span>No skin in your post-award game</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path></svg>
          <span>Hourly fees for every follow-up</span>
        </div>
      </div>
      <div class="lp-compare__col lp-compare__col--featured">
        <h3 class="lp-compare__head">
          <img src="/assets/mark-color.png" alt="" width="20" height="20" aria-hidden="true" />
          Price Reporter
        </h3>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
          <span>Prepares, negotiates, and stays on after award</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
          <span>Modifications, renewals, compliance, catalogs, orders</span>
        </div>
        <div class="lp-compare__row">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
          <span>Clarifications and revisions handled by our team</span>
        </div>
      </div>
    </div>
  </div>
</section>
`,x=`<section class="lp-proof pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">What clients say after the award — not just after the sale</h2>
      <div class="lp-proof__chips">
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
          4.9 customer rating
        </span>
        <span class="lp-proof__chip">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
          BBB accredited, A+ rating
        </span>
      </div>
    </div>

    <div class="v2-cases stagger">
      <article class="v2-case v2-case--featured">
        <div class="v2-case__top">
          <span class="v2-case__logo">Лого клієнта</span>
          <span class="pr-badge pr-badge--soft pr-badge--accent">Veteran-owned small business</span>
        </div>
        <div class="v2-case__metrics">
          <div class="v2-case__metric">
            <span class="v2-case__num">1¢</span>
            <span class="v2-case__metric-label">below the next competitor — automated price positioning on every item</span>
          </div>
          <div class="v2-case__metric">
            <span class="v2-case__num">1000s</span>
            <span class="v2-case__metric-label">of government orders won on that position</span>
          </div>
        </div>
        <blockquote class="v2-case__quote">
          <p>"A very unique position that gave us thousands of government orders. And for all the service given, their cost was far less than any other consulting firm we had contacted or worked with over the years."</p>
        </blockquote>
      </article>

      <article class="v2-case">
        <div class="v2-case__top">
          <span class="v2-case__logo">Лого клієнта</span>
        </div>
        <div class="v2-case__metrics">
          <div class="v2-case__metric">
            <span class="v2-case__num">5 yrs</span>
            <span class="v2-case__metric-label">of GSA catalogs kept maintained and compliant</span>
          </div>
        </div>
        <blockquote class="v2-case__quote">
          <p>"They keep our catalogs well maintained and compliant, saving our resources and letting us focus on making sales."</p>
        </blockquote>
      </article>

      <article class="v2-case">
        <div class="v2-case__top">
          <span class="v2-case__logo">Лого клієнта</span>
          <span class="pr-badge pr-badge--soft pr-badge--brand">Family-owned, 2nd generation</span>
        </div>
        <div class="v2-case__metrics">
          <div class="v2-case__metric">
            <span class="v2-case__num">0 → GSA</span>
            <span class="v2-case__metric-label">from uncertain first steps to a running government business</span>
          </div>
        </div>
        <blockquote class="v2-case__quote">
          <p>"We were uncertain what would be required. I fully recommend Price Reporter to any company looking for assistance with their government business endeavors."</p>
        </blockquote>
      </article>
    </div>
    <p class="v2-cases__note">Кейси — приклад структури для макета. Реальні цифри, цитати й лого клієнтів — після погодження.</p>
  </div>
</section>
`,A=`<section class="v2-stats pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Why companies go through this at all</h2>
    </div>
    <div class="v2-stats__panel reveal">
      <div class="v2-stats__cols">
        <div class="v2-stats__col">
          <span class="v2-stats__num">$2.3M</span>
          <span class="v2-stats__label">won in business each year by the average GSA Schedule holder through the program</span>
        </div>
        <div class="v2-stats__col">
          <span class="v2-stats__num">5&nbsp;→&nbsp;20 yrs</span>
          <span class="v2-stats__label">one contract, extendable term after term — a sales channel you build once and keep</span>
        </div>
        <div class="v2-stats__col">
          <span class="v2-stats__num">U.S. Gov</span>
          <span class="v2-stats__label">your buyer. They purchase everything, and they pay</span>
        </div>
      </div>
      <p class="v2-stats__myth">
        <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="8" y2="12"></line><line x1="12" x2="12.01" y1="16" y2="16"></line></svg>
        <em>And no — you don't have to be the cheapest. GSA looks for pricing that's fair and reasonable for the market, not the lowest number on the page.</em>
      </p>
    </div>
  </div>
</section>
`,S=`<section class="v2-team pr-section">
  <div class="pr-container v2-team__grid">
    <div class="v2-team__copy reveal">
      <h2 class="v2-team__title">A team, not a middleman</h2>
      <span class="v2-team__rule" aria-hidden="true"></span>
      <p class="v2-team__body">Price Reporter has been doing business with GSA since 2006. Not as a side offering, not as one consultant with a template — a dedicated team of GSA experts whose entire work is winning contracts, managing them, and moving orders through the system. When GSA sends a clarification letter at 4&nbsp;PM on a Friday, it lands on our desk, not yours.</p>
    </div>
    <figure class="v2-team__photo reveal">
      <div class="v2-ph v2-team__ph">
        <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"></path><path d="m17 8-5-5-5 5"></path><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path></svg>
        <span class="v2-ph__label">Місце під фото</span>
        <p class="v2-ph__desc">Реальна робоча сцена команди — стіл, екрани з інтерфейсами, документи. Без постановки і стоку</p>
      </div>
      <span class="v2-team__badge">
        <img src="/assets/mark-color.png" alt="" width="18" height="18" aria-hidden="true" />
        Working with GSA since 2006
      </span>
    </figure>
  </div>
</section>
`,C={header:r,hero:b,"trust-bar":f,problem:y,"how-it-works":g,quiz:w,services:m,"social-proof":x,"why-2026":_,stats:A,team:S,faq:k,"final-cta":u,footer:t,"sticky-bar":a,"exit-popup":v};Object.entries(C).forEach(([e,n])=>{const s=document.getElementById(e);s&&(s.innerHTML=n)});o();i();l();c();p();d();h();
