import{S as n,i as t,a as i,b as r,c as l,d as o,e as c,f as p}from"./animations-tLKYnpyK.js";/* empty css                 *//* empty css           *//* empty css                   */const d=`<header class="lp-header" id="site-header" aria-label="Site header">
  <div class="pr-container lp-header__inner">
    <a class="lp-header__logo" href="#top" aria-label="Price Reporter — back to top">
      <img src="/assets/logo-horizontal-color.png" alt="Price Reporter" height="30" />
    </a>
    <span class="lp-header__spacer"></span>
    <a class="lp-header__phone" href="tel:2015676646">
      <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
      201-567-6646
    </a>
    <button type="button" class="pr-btn pr-btn--accent" data-scroll-form>Free VA Assessment</button>
  </div>
</header>
`,u=`<section class="v2-hero v2-hero--photo v2-hero--va" id="top">
  <span class="v2-hero__bg" aria-hidden="true"></span>
  <div class="pr-container v2-hero__container">
    <div class="v2-hero__topbar">
      <span class="v2-hero__brand">
        <img src="/assets/mark-color.png" alt="" width="30" height="30" aria-hidden="true" />
        <span class="v2-hero__wordmark"><b>PRICE</b>REPORTER</span>
      </span>
      <a class="v2-hero__topphone" href="tel:2015676646">
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
        201-567-6646
      </a>
    </div>
    <div class="v2-hero__grid">
      <div class="v2-hero__copy">
        <p class="v2-hero__eyebrow">VA Federal Supply Schedule Consultants&nbsp;·&nbsp;Since 2006</p>
        <h1 class="v2-hero__title">Become a VA Contractor. We'll Get You on the Federal Supply&nbsp;Schedule.</h1>
        <span class="v2-hero__rule" aria-hidden="true"></span>
        <p class="v2-hero__sub">VA hospitals and other federal agencies buy roughly $25 billion a year in medical supplies, equipment, pharmaceuticals, and healthcare services through the VA Schedule. We prepare your VA proposal, verify TAA and FDA requirements, work directly with your contracting officer — and after award, we get your catalog in front of VA buyers.</p>
        <p class="v2-hero__proof">One medical equipment client was supplying multiple VA hospitals within six months of award.</p>
        <div class="v2-hero__mobile-cta">
          <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-scroll-form>Get My Free VA Schedule Assessment</button>
          <p class="v2-hero__micro">A free one-hour review with a VA Schedule specialist. We reply within one business day.</p>
        </div>
        <p class="v2-hero__call">Rather talk? <a href="tel:2015676646">201-567-6646</a></p>
      </div>
      <div class="v2-hero__visual">
        <div class="v2-hero__formwrap" id="lead-form-anchor">
          <form class="lp-form" data-lead-form novalidate>
            <div class="lp-form__fields">
              <div class="lp-form__head">
                <h3 class="lp-form__title">Find out where you stand with VA</h3>
                <p class="lp-form__sub">A free one-hour review with a VA Schedule specialist. We reply within one business day.</p>
              </div>
              <label class="pr-field">
                <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
                <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Company <span class="pr-field__req">*</span></span>
                <span class="pr-input"><input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company name" /></span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
                <span class="pr-input">
                  <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
                  <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" />
                </span>
              </label>
              <label class="pr-field">
                <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
                <span class="pr-input">
                  <svg class="ic ic--sm pr-input__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
                  <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" />
                </span>
              </label>
              <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Get My Free Assessment</button>
              <p class="lp-form__fine">
                <svg class="ic ic--xs" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                Your details are used only to prepare your assessment. No lists, no resale.
              </p>
            </div>
            <div class="lp-form__success" hidden>
              <span class="lp-form__success-icon">
                <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
              </span>
              <h3>Request received</h3>
              <p>A VA Schedule specialist will review your details and respond within one business day.</p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
`,h=`<section class="lp-trust pr-inverse" aria-label="Our numbers">
  <div class="pr-container">
    <p class="lp-trust__caps">Our numbers tell the story</p>
    <div class="lp-trust__grid lp-trust__grid--five stagger">
      <div class="lp-trust__item">
        <span class="lp-trust__big">Since 2006</span>
        <span class="lp-trust__label">in federal contracting</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">1,000+</span>
        <span class="lp-trust__label">companies served</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">400+</span>
        <span class="lp-trust__label">contracts awarded</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">2.5M+</span>
        <span class="lp-trust__label">federal orders processed</span>
      </div>
      <div class="lp-trust__item">
        <span class="lp-trust__big">20,000+</span>
        <span class="lp-trust__label">contract modifications</span>
      </div>
    </div>
    <p class="lp-trust__sub">
      <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
      BBB Accredited Business
    </p>
  </div>
</section>
`,v=`<section class="v2-stats pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">A customer that never stops buying</h2>
    </div>
    <div class="va-prize__intro">
      <div class="lp-prize__body reveal">
        <p>VA runs one of the largest healthcare systems in the country — hospitals, clinics, and rehabilitation centers serving an aging veteran population with long-term care needs. Those facilities need gloves, wheelchairs, infusion pumps, test kits, dental chairs, nurses, and lab work every single week. A VA Schedule contract puts you on the list they order from.</p>
      </div>
      <figure class="va-prize__photo reveal" aria-hidden="true">
        <!-- Stock placeholder (Unsplash): swap for a real VA-type facility shot if available -->
        <img src="/assets/va/ward.jpg" alt="" loading="lazy" />
      </figure>
    </div>
    <div class="v2-stats__panel reveal">
      <div class="v2-stats__cols">
        <div class="v2-stats__col">
          <span class="v2-stats__num">~$25B</span>
          <span class="v2-stats__label">bought through the VA Federal Supply Schedule every year</span>
        </div>
        <div class="v2-stats__col">
          <span class="v2-stats__num">Multi-year</span>
          <span class="v2-stats__label">contracts with pre-negotiated pricing — you sell without re-bidding every order</span>
        </div>
        <div class="v2-stats__col">
          <span class="v2-stats__num">Every agency</span>
          <span class="v2-stats__label">open to VA and other eligible federal buyers — through GSA Advantage and DOD FedMall</span>
        </div>
      </div>
      <p class="v2-stats__myth">
        <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 7h6v6"></path><path d="m22 7-8.5 8.5-5-5L2 17"></path></svg>
        <em>Federal healthcare budgets don't follow the commercial cycle. When the private market slows down, VA keeps ordering.</em>
      </p>
    </div>
    <p class="lp-prize__cta reveal">
      <a class="lp-prize__link" href="#schedules">
        See which VA Schedule fits you
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
      </a>
    </p>
  </div>
</section>
`,_=`<section class="va-sched pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Nine VA Schedules. One of them is probably yours.</h2>
    </div>
    <div class="va-sched__grid stagger">
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/equip.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">65 II A</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">Medical Equipment &amp; Supplies</h3>
          <p class="va-sched__ex">infusion pumps, surgical instruments, diagnostic tools, consumables</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/pharma.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">65 I B</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">Pharmaceuticals</h3>
          <p class="va-sched__ex">prescription and OTC drugs, antiseptics, dispensers</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/dental.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">65 II C</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">Dental Equipment &amp; Supplies</h3>
          <p class="va-sched__ex">chairs, drills, sterilization, dental imaging</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <!-- Фото-заглушка: замінити на кадр з візком/ходунками, коли буде -->
          <img src="/assets/va/sched/mobility.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">65 II F</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">Patient Mobility Devices</h3>
          <p class="va-sched__ex">wheelchairs, scooters, walkers</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/xray.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">65 V A</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">X-Ray Equipment &amp; Supplies</h3>
          <p class="va-sched__ex">medical and dental imaging systems</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/ivd.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">65 VII</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">In Vitro Diagnostics</h3>
          <p class="va-sched__ex">reagents, test kits, test strips</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/analyzers.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">66 III</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">Clinical Analyzers, Cost-Per-Test</h3>
          <p class="va-sched__ex">lab analyzers on a cost-per-test basis</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/staffing.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">621 I</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">Healthcare Staffing</h3>
          <p class="va-sched__ex">nurses, physicians, technicians, allied health</p>
        </div>
      </div>
      <div class="va-sched__tile">
        <figure class="va-sched__pic" aria-hidden="true">
          <img src="/assets/va/sched/labtest.jpg" alt="" loading="lazy" />
          <span class="va-sched__code">621 II</span>
        </figure>
        <div class="va-sched__body">
          <h3 class="va-sched__name">Medical Lab Testing</h3>
          <p class="va-sched__ex">diagnostic testing and analysis services</p>
        </div>
      </div>
    </div>
    <aside class="va-sched__router reveal">
      <div class="va-sched__router-copy">
        <h3 class="va-sched__router-title">Selling VA something else?</h3>
        <p class="va-sched__router-body">IT, furniture, facility supplies, professional services — VA buys those through the GSA Schedule. We do that too.</p>
      </div>
      <a class="lp-prize__link" href="/" >
        See how we get companies on the GSA Schedule
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
      </a>
    </aside>
  </div>
</section>
`,m=`<section class="lp-how pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Four steps from "do we qualify?" to VA orders</h2>
    </div>
    <ol class="lp-how__timeline stagger">
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">1</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21 21-4.34-4.34"></path><circle cx="11" cy="11" r="8"></circle></svg>
        </span>
        <h3 class="lp-how__title">Product &amp; service review</h3>
        <p class="lp-how__text">We go through your catalog and tell you which items qualify for a VA Schedule — and which belong on GSA instead. That's your free one-hour assessment.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">2</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"></path><path d="M14 2v5a1 1 0 0 0 1 1h5"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>
        </span>
        <h3 class="lp-how__title">We prepare the proposal</h3>
        <p class="lp-how__text">Proof of origin, compliance certificates, TAA and FDA verification, commercial sales and pricing disclosures, a price list structured the way VA expects it. VA scrutinizes pricing harder than almost any federal buyer — so this is where we spend the most care.</p>
      </li>
      <li class="lp-how__step">
        <div class="lp-how__marker">
          <span class="lp-how__num">3</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"></path></svg>
        </span>
        <h3 class="lp-how__title">Submission &amp; negotiation</h3>
        <p class="lp-how__text">We submit your offer and work directly with your VA contracting officer — clarifications, pricing questions, final terms. Our preparation usually means fewer questions and a faster turnaround.</p>
      </li>
      <li class="lp-how__step lp-how__step--featured">
        <div class="lp-how__marker">
          <span class="lp-how__num">4</span>
        </div>
        <span class="lp-how__icon">
          <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"></path><path d="M15 18H9"></path><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"></path><circle cx="17" cy="18" r="2"></circle><circle cx="7" cy="18" r="2"></circle></svg>
        </span>
        <h3 class="lp-how__title">Launch &amp; first orders</h3>
        <p class="lp-how__text">Your catalog goes live, we train your team on finding and answering VA requests, and we monitor solicitations so you can move before your competitors do.</p>
      </li>
    </ol>
    <div class="lp-how__cta reveal">
      <button type="button" class="pr-btn pr-btn--accent pr-btn--lg" data-scroll-form>Start With the Free Assessment</button>
    </div>
  </div>
</section>
`,w=`<section class="lp-reassure pr-inverse" aria-label="Our promise">
  <div class="pr-container lp-reassure__inner reveal">
    <span class="lp-reassure__icon">
      <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>
    </span>
    <p class="lp-reassure__text">Since 2006 we've worked with over 1,000 companies entering the federal market. With Price Reporter by your side, your success is not just possible — it's&nbsp;expected.</p>
  </div>
</section>
`,g=`<section class="lp-proof pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Contracts that turned into orders</h2>
    </div>
    <div class="va-results stagger">
      <article class="v2-case v2-case--featured va-result">
        <figure class="va-result__photo" aria-hidden="true">
          <!-- Stock placeholder (Unsplash): swap for a client product shot when approved -->
          <img src="/assets/va/case-medical.jpg" alt="" loading="lazy" />
        </figure>
        <div class="va-result__inner">
          <div class="v2-case__top">
            <span class="pr-badge pr-badge--solid pr-badge--accent">Medical Equipment · VA</span>
          </div>
          <div class="v2-case__metrics">
            <div class="v2-case__metric">
              <span class="v2-case__num">6 mo</span>
              <span class="v2-case__metric-label">from award to supplying multiple VA hospitals</span>
            </div>
          </div>
          <p class="va-result__body">A medical equipment supplier came to us to enter the federal healthcare market. Six months after award, they were shipping to multiple VA hospitals and expanding their product line to keep up with demand.</p>
          <a class="va-result__link" href="https://pricereporter.com/industries/healthcare/" target="_blank" rel="noopener">
            See our healthcare work
            <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          </a>
        </div>
      </article>

      <article class="v2-case va-result">
        <figure class="va-result__photo" aria-hidden="true">
          <img src="/assets/va/case-construction.jpg" alt="" loading="lazy" />
        </figure>
        <div class="va-result__inner">
          <div class="v2-case__top">
            <span class="pr-badge pr-badge--soft pr-badge--brand">Construction &amp; Facility Products · GSA</span>
          </div>
          <div class="v2-case__metrics">
            <div class="v2-case__metric">
              <span class="v2-case__num">5 mo</span>
              <span class="v2-case__metric-label">to award</span>
            </div>
            <div class="v2-case__metric">
              <span class="v2-case__num">$400K+</span>
              <span class="v2-case__metric-label">in federal sales in year one</span>
            </div>
          </div>
          <p class="va-result__body">Eden General Construction diversified into government product sales with us — then added a Furniture SIN with products no other contractor was offering.</p>
          <a class="va-result__link" href="https://pricereporter.com/testimonials/" target="_blank" rel="noopener">
            Read Eden's story
            <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          </a>
        </div>
      </article>

      <article class="v2-case va-result">
        <figure class="va-result__photo" aria-hidden="true">
          <img src="/assets/va/case-signing.jpg" alt="" loading="lazy" />
        </figure>
        <div class="va-result__inner">
          <div class="v2-case__top">
            <span class="pr-badge pr-badge--soft pr-badge--brand">Repeat Client</span>
          </div>
          <div class="v2-case__metrics">
            <div class="v2-case__metric">
              <span class="v2-case__num">3rd</span>
              <span class="v2-case__metric-label">federal contract, back with our team</span>
            </div>
            <div class="v2-case__metric">
              <span class="v2-case__num">0</span>
              <span class="v2-case__metric-label">rejections across both contracts we handled</span>
            </div>
          </div>
          <p class="va-result__body">A long-standing client came back to us for their next contract. Both were accepted without rejection and with minimal negotiation.</p>
          <a class="va-result__link" href="https://pricereporter.com/testimonials/" target="_blank" rel="noopener">
            More client stories
            <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          </a>
        </div>
      </article>
    </div>
  </div>
</section>
`,b=`<section class="va-voices pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">From a veteran-owned client</h2>
    </div>
    <div class="va-voices__grid">
      <figure class="lp-proof__featured reveal">
        <svg class="lp-proof__mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
        <blockquote class="lp-proof__quote" data-readmore>
          <p>"For a number of years, they had been giving us a price algorithm where each of our items was priced a penny below the next competitor. A very unique position that gave us thousands of government orders. And for all the service given, their cost was far less than any other consulting firm we had contacted or worked with over the years. Thank you for supporting a veteran-owned small business."</p>
        </blockquote>
        <button type="button" class="lp-proof__readmore" data-readmore-btn hidden>Read more</button>
        <figcaption class="lp-proof__attr">
          <span class="pr-badge pr-badge--soft pr-badge--accent">Veteran-owned small business</span>
        </figcaption>
      </figure>

      <div class="va-voices__side">
        <aside class="va-voices__panel reveal">
          <span class="va-voices__panel-icon">
            <svg class="ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
          </span>
          <h3 class="va-voices__panel-title">Veteran-owned? Your status counts here.</h3>
          <p class="va-voices__panel-body">VA contracting gives service-disabled veteran-owned and veteran-owned small businesses (SDVOSB / VOSB) real advantages — VA is required to look to them first. A VA Schedule contract is how you turn that advantage into recurring orders. Bring your status to the assessment call; it changes where you should go first.</p>
        </aside>
        <figure class="lp-proof__card reveal">
          <svg class="lp-proof__card-mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path><path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"></path></svg>
          <blockquote>
            <p>"The Price Reporter team has been efficient at managing our GSA contract catalogs for the past 5 years. They keep our catalogs well maintained and compliant, saving our resources and letting us focus on making sales."</p>
          </blockquote>
        </figure>
      </div>
    </div>
  </div>
</section>
`,f=`<section class="lp-services pr-band pr-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Getting on the VA Schedule is one job. Staying profitable on it is another.</h2>
      <p class="pr-sectionhead__sub">VA reviews pricing closely before award and audits it after. Most consultants stop at submission. We're built for the whole contract life.</p>
    </div>
    <div class="lp-services__grid stagger">
      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-doc">
            <span class="lp-svc-doc__tag">VA FSS proposal</span>
            <span class="lp-svc-doc__line" style="width: 86%"></span>
            <span class="lp-svc-doc__line" style="width: 68%"></span>
            <span class="lp-svc-doc__line" style="width: 92%"></span>
            <span class="lp-svc-doc__line" style="width: 55%"></span>
            <span class="lp-svc-doc__stamp">Awarded</span>
          </div>
        </div>
        <h3 class="lp-services__title">Win it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Product review, TAA and FDA verification, compliance certificates, pricing disclosures, a price list structured for acceptance, and direct work with your contracting officer.</p>
      </article>

      <article class="lp-services__card">
        <div class="lp-svc-mock" aria-hidden="true">
          <div class="lp-svc-list">
            <div class="lp-svc-list__row">
              <span>Modification #2041</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Approved</span>
            </div>
            <div class="lp-svc-list__row">
              <span>Price update</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Filed</span>
            </div>
            <div class="lp-svc-list__row">
              <span>TAA compliance check</span>
              <span class="lp-svc-chip lp-svc-chip--ok">Passed</span>
            </div>
          </div>
        </div>
        <h3 class="lp-services__title">Run it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Contract modifications, price updates, new products, compliance with VA pricing rules — handled. 20,000+ modifications completed across our clients.</p>
      </article>

      <article class="lp-services__card lp-services__card--oms">
        <div class="lp-svc-mock" aria-hidden="true">
        <div class="lp-oms">
          <div class="lp-oms__chrome">
            <span class="lp-oms__dot"></span><span class="lp-oms__dot"></span><span class="lp-oms__dot"></span>
            <span class="lp-oms__chrome-title">Order Management System</span>
          </div>
          <div class="lp-oms__row lp-oms__row--head">
            <span>Order</span><span>Buyer</span><span>Status</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471820</span><span>VA Medical Center</span><span class="lp-oms__chip lp-oms__chip--ok">Shipped</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471819</span><span>GSA Advantage</span><span class="lp-oms__chip lp-oms__chip--proc">Processing</span>
          </div>
          <div class="lp-oms__row">
            <span>#4471818</span><span>DOD FedMall</span><span class="lp-oms__chip lp-oms__chip--ok">Invoiced</span>
          </div>
        </div>
        </div>
        <h3 class="lp-services__title">Grow it.</h3>
        <span class="pr-service__rule"></span>
        <p class="lp-services__desc">Our Order Management System tracks every order from inquiry to delivery — 2.5M+ federal orders processed. Plus solicitation monitoring, GSA eBuy training, and sales analytics that show which products sell and when.</p>
      </article>
    </div>
  </div>
</section>
`,y=`<section class="lp-quiz pr-inverse pr-section" id="quiz-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">VA Schedule or GSA Schedule? Find out in 60 seconds.</h2>
      <p class="pr-sectionhead__sub">Five quick questions. A specialist reviews your answers and comes back within one business day with an honest read — including which schedule fits you best.</p>
    </div>

    <div class="lp-quiz__card reveal" data-quiz>
      <div class="lp-quiz__top">
        <div class="lp-quiz__progress" data-quiz-progress-wrap>
          <span class="lp-quiz__progress-label" data-quiz-progress-label>Question 1 of 5</span>
          <span class="lp-quiz__bar"><span class="lp-quiz__bar-fill" data-quiz-progress-fill style="width: 20%"></span></span>
        </div>
        <span class="lp-quiz__timer">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>
          60 seconds
        </span>
      </div>

      <div class="lp-quiz__step" data-quiz-step="0">
        <h3 class="lp-quiz__q">What do you sell?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Medical equipment & supplies">Medical equipment &amp; supplies</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Pharmaceuticals">Pharmaceuticals</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Dental, X-ray or lab">Dental, X-ray or lab</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Healthcare staffing or lab services">Healthcare staffing or lab services</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Something else">Something else</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="1" hidden>
        <h3 class="lp-quiz__q">Do you manufacture it or distribute it?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Manufacturer">Manufacturer</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Distributor or reseller">Distributor or reseller</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Service provider">Service provider</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="2" hidden>
        <h3 class="lp-quiz__q">How long has your company been in business?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Under 2 years">Under 2 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="2–5 years">2–5 years</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="5+ years">5+ years</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="3" hidden>
        <h3 class="lp-quiz__q">Are your products TAA-compliant and, where needed, FDA-cleared?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Yes">Yes</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Some">Some</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Not sure">Not sure</button>
        </div>
      </div>

      <div class="lp-quiz__step" data-quiz-step="4" hidden>
        <h3 class="lp-quiz__q">Is your business veteran-owned?</h3>
        <div class="lp-quiz__answers">
          <button type="button" class="lp-quiz__answer" data-quiz-answer="SDVOSB">SDVOSB</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="VOSB">VOSB</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="No">No</button>
          <button type="button" class="lp-quiz__answer" data-quiz-answer="Applying">Applying</button>
        </div>
      </div>

      <form class="lp-quiz__step lp-quiz__contact" data-quiz-step="5" data-quiz-contact hidden novalidate>
        <h3 class="lp-quiz__q">Where should we send your result?</h3>
        <label class="pr-field">
          <span class="pr-field__label">Your name <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Work email <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="you@company.com" /></span>
        </label>
        <label class="pr-field">
          <span class="pr-field__label">Phone <span class="pr-field__req">*</span></span>
          <span class="pr-input"><input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="201-567-6646" /></span>
        </label>
        <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full">Get My Result</button>
      </form>

      <div class="lp-quiz__step lp-quiz__result" data-quiz-step="result" hidden>
        <span class="lp-form__success-icon">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
        </span>
        <p class="lp-quiz__result-text">Thanks — a VA Schedule specialist will review your answers and reach out within one business day: which schedule fits, what VA will ask of you, and what to fix first if you're not there yet.</p>
      </div>

      <button type="button" class="lp-quiz__back" data-quiz-back hidden>
        <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"></path></svg>
        Back
      </button>
    </div>
  </div>
</section>
`,k=`<section class="lp-why pr-section">
  <div class="pr-container">
    <div class="lp-why__grid">
      <div class="lp-why__copy reveal">
        <h2 class="lp-why__title">VA is getting stricter about pricing. That works in your&nbsp;favor.</h2>
        <p>VA's Inspector General has been reviewing Schedule proposals closely — and most of those reviewed needed corrections before VA could use them in negotiations. In 2026, VA also launched a new process for vendors to self-report pricing errors. Translation: VA wants vendors whose numbers are clean from day one.</p>
        <p>That's a higher bar for companies that wing it, and an opening for those who walk in prepared. Clean disclosures, defensible pricing, and a contract that stays compliant after award — that's the part we handle.</p>
      </div>

      <figure class="lp-why__viz reveal" aria-hidden="true">
        <div class="lp-why__viz-chrome">
          <span class="lp-why__viz-dot"></span><span class="lp-why__viz-dot"></span><span class="lp-why__viz-dot"></span>
          <span class="lp-why__viz-title">VA OIG — proposal reviews</span>
        </div>
        <div class="va-oig__row">
          <span class="va-oig__label">FY2024 · non-pharma</span>
          <span class="va-oig__bar"><span class="va-oig__fill" style="width: 82%"></span></span>
          <span class="va-oig__note">18 of 22 needed corrections</span>
        </div>
        <div class="va-oig__row">
          <span class="va-oig__label">FY2025 · pharma</span>
          <span class="va-oig__bar"><span class="va-oig__fill" style="width: 69%"></span></span>
          <span class="va-oig__note">11 of 16 needed corrections</span>
        </div>
        <p class="va-oig__source">Source: VA OIG</p>
      </figure>
    </div>
  </div>
</section>
`,A=`<section class="v2-team pr-section">
  <div class="pr-container v2-team__grid">
    <div class="v2-team__copy reveal">
      <h2 class="v2-team__title">Since 2006. Still picking up the phone.</h2>
      <span class="v2-team__rule" aria-hidden="true"></span>
      <p class="v2-team__body">Price Reporter is a dedicated team of federal contracting specialists — not a directory of freelancers. Healthcare is one of the markets we know best: the schedules, the compliance rules, and how VA buyers actually order. When your contracting officer has a question, it lands on our desk, not yours.</p>
    </div>
    <!-- Той самий ролик, що вбудований на pricereporter.com/get-va-contract/ -->
    <div class="va-video reveal" data-video="PyvEwIXqeP0" data-video-title="How to Get a New GSA Contract (by Price Reporter)">
      <button type="button" class="va-video__face" data-video-play aria-label="Play video: How to Get a New GSA Contract (by Price Reporter)">
        <img class="va-video__poster" src="/assets/va/video-poster.jpg" alt="" loading="lazy" />
        <span class="va-video__scrim" aria-hidden="true"></span>
        <span class="va-video__play">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="9 6 19 12 9 18 9 6"></polygon></svg>
        </span>
        <span class="va-video__caption">
          <span class="va-video__label">How to Get a New GSA Contract</span>
          <span class="va-video__meta">A short intro from the Price Reporter team · YouTube</span>
        </span>
      </button>
    </div>
  </div>
</section>
`,q=`<section class="lp-faq pr-band pr-section">
  <div class="lp-faq__container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">FAQ</h2>
    </div>
    <div class="pr-acc reveal" data-faq>
      <div class="pr-acc__item" data-faq-item data-open-desktop>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What's the difference between a VA Schedule and a GSA Schedule?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>They're parallel programs. VA runs its own Federal Supply Schedules for healthcare — medical and dental equipment, pharmaceuticals, lab products, healthcare staffing — through its National Acquisition Center. Everything else the government buys, VA included, goes through the GSA Schedule. Not sure which is yours? That's the first thing we answer on the assessment call.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          How long does it take to get a VA Schedule contract?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>It depends on the schedule, how complete your documentation is, and how many pricing questions VA raises. A well-prepared proposal moves faster because it draws fewer questions — and that preparation is our job. You'll get a realistic timeline for your specific case on the free assessment.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What does VA require?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>An established business with a commercial sales history, products that meet TAA requirements (and FDA requirements where they apply), clear pricing disclosures, and solid past performance. Distributors usually need supporting documentation from the manufacturers they represent. We'll tell you exactly what applies to you.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          I'm a distributor, not a manufacturer. Can I still get on the VA Schedule?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Often, yes — but the paperwork is different, and VA looks closely at how resellers price. Tell us what you carry and who makes it, and we'll map out what you need.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          I'm a veteran-owned business. Does that help?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Yes. VA gives SDVOSBs and VOSBs real priority in its purchasing. A VA Schedule contract is what lets you put that priority to work on recurring orders.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          How much does it cost?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>It depends on your schedule and scope, so we quote after the free assessment — once we've actually looked at your catalog. You'll know the full picture before you commit.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Can't I just apply myself?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>You can. Expect commercial sales disclosures, a price list that holds up to VA's review, compliance certificates, and negotiation rounds with a contracting officer. Most companies that call us either started and stalled, or decided the time was better spent running their business.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          What happens after award?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>We keep you live and compliant: catalog updates, modifications, price changes, order management, solicitation monitoring, and sales analytics.</p>
        </div>
      </div>
      <div class="pr-acc__item" data-faq-item>
        <button type="button" class="pr-acc__btn" aria-expanded="false">
          <svg class="ic pr-acc__chev" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg>
          Do you also handle GSA, FedMall, and DLA?
        </button>
        <div class="pr-acc__panel" hidden>
          <p>Yes. Many healthcare suppliers sell through more than one channel — we support GSA Schedule contracts, DOD FedMall, DLA, and BPAs as well.</p>
        </div>
      </div>
    </div>
  </div>
</section>
`,x=`<section class="lp-final pr-inverse pr-section" id="final-cta-section">
  <div class="pr-container">
    <div class="pr-sectionhead reveal">
      <h2 class="pr-sectionhead__title">Find out which VA Schedule is yours — free</h2>
      <p class="pr-sectionhead__sub">Tell us what you sell. In a free one-hour review, a VA Schedule specialist will tell you which schedule fits, what VA will ask for, and what it would cost to get there. If VA isn't the right channel, we'll point you to the one that is.</p>
    </div>

    <form class="lp-form lp-final__form reveal" data-lead-form novalidate>
      <div class="lp-form__fields lp-final__fields">
        <div class="lp-final__row">
          <label class="pr-input pr-input--on-dark" aria-label="Your name">
            <input class="pr-input__el" type="text" name="name" required autocomplete="name" placeholder="Your name" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Company">
            <input class="pr-input__el" type="text" name="company" required autocomplete="organization" placeholder="Company" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Work email">
            <input class="pr-input__el" type="email" name="email" required autocomplete="email" placeholder="Work email" />
          </label>
          <label class="pr-input pr-input--on-dark" aria-label="Phone">
            <input class="pr-input__el" type="tel" name="phone" required autocomplete="tel" placeholder="Phone" />
          </label>
        </div>
        <button type="submit" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full lp-final__submit">Get My Free VA Schedule Assessment</button>
        <p class="lp-final__contacts">
          <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2a9 9 0 0 1 9 9"></path><path d="M13 6a5 5 0 0 1 5 5"></path><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>
          Or call: <a href="tel:2015676646">201-567-6646</a>&nbsp;·&nbsp;<a href="mailto:salesteam@pricereporter.com">salesteam@pricereporter.com</a>
        </p>
      </div>
      <div class="lp-form__success" hidden>
        <span class="lp-form__success-icon">
          <svg class="ic ic--lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
        </span>
        <h3>Request received</h3>
        <p>A VA Schedule specialist will review your details and respond within one business day.</p>
      </div>
    </form>
  </div>
</section>
`,z=`<footer class="lp-footer">
  <div class="pr-container lp-footer__inner">
    <span class="lp-footer__brand">
      <img src="/assets/mark-mono.png" alt="" width="26" height="26" aria-hidden="true" />
      <span class="lp-footer__word"><b>PRICE</b>REPORTER</span>
    </span>
    <p class="lp-footer__trust">Price Reporter · In federal contracting since 2006 · BBB Accredited Business</p>
    <span class="lp-footer__meta">
      <a href="tel:2015676646">201-567-6646</a>
      <a href="mailto:salesteam@pricereporter.com">salesteam@pricereporter.com</a>
    </span>
  </div>
</footer>
`,V=`<div class="lp-exit" id="exit-popup-root" hidden>
  <div class="lp-exit__scrim" data-exit-dismiss></div>
  <div class="lp-exit__modal" role="dialog" aria-modal="true" aria-labelledby="exit-popup-title">
    <button type="button" class="lp-exit__close" data-exit-dismiss aria-label="Close">
      <svg class="ic ic--sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
    </button>
    <h3 class="lp-exit__title" id="exit-popup-title">Not ready yet?</h3>
    <p class="lp-exit__body">Find out which VA Schedule fits you — free, and the answer is yours to keep.</p>
    <button type="button" class="pr-btn pr-btn--accent pr-btn--lg pr-btn--full" data-exit-cta>Check Which Schedule Fits</button>
    <button type="button" class="lp-exit__dismiss" data-exit-dismiss>Maybe later</button>
  </div>
</div>
`;function S(){document.querySelectorAll("[data-video]").forEach(s=>{const a=s.querySelector("[data-video-play]");a&&a.addEventListener("click",()=>{const e=document.createElement("iframe");e.className="va-video__frame",e.src=`https://www.youtube.com/embed/${s.dataset.video}?autoplay=1&rel=0`,e.title=s.dataset.videoTitle||"Video",e.allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",e.allowFullscreen=!0,s.replaceChildren(e),s.classList.add("va-video--playing")},{once:!0})})}const C={header:d,hero:u,"trust-bar":h,prize:v,schedules:_,"how-it-works":m,reassurance:w,results:g,voices:b,"why-pr":f,quiz:y,"why-now":k,team:A,faq:q,"final-cta":x,footer:z,"sticky-bar":n,"exit-popup":V};Object.entries(C).forEach(([s,a])=>{const e=document.getElementById(s);e&&(e.innerHTML=a)});t();i();r();l();o();c();p();S();
