---
name: registeam-kp
description: Build, edit, translate and export RegisTeam client presentations — commercial proposals (КП / KP) and express-audit decks — using the house design system and proven slide templates. Use this skill whenever the user asks for a proposal, КП, коммерческое предложение, pitch deck, audit deck, or presentation for a client/project; asks to edit slides, prices, packages (OneSource / Performance+), forecasts or campaign structures in an existing deck; asks to translate a deck to English/Russian/Ukrainian; or asks to export a deck to PDF, PNG or Figma. Even a short request like "зроби КП для клієнта" or "make a proposal for this site" must go through this skill — never design new slide layouts from scratch when a template exists.
---

# RegisTeam KP & Audit deck builder

This repo contains a battle-tested system for producing client presentations:
a design system (`RegisTeam Design System/`), a 1920×1080 deck engine
(`slides/deck-stage.js` + `slides/deck.css`), and eight finished decks that
serve as copy-sources. Your job is never to invent a new deck from zero — it
is to pick the right donor deck, replace the content with *this client's*
data, verify the render, and export.

Read this file fully, then open the reference that matches your task:

| You are asked to… | Read next |
| --- | --- |
| Build a new KP / audit deck | `references/structures.md` (canonical slide orders + donor table) |
| Anything that renders or exports | `references/pitfalls.md` (every historical bug and its fix) |
| Work in EN / RU / UK, translate a deck | `references/localization.md` |

## Repo map

```
RegisTeam Design System/
├── colors_and_type.css        ← design tokens (.rt-v2 scope) — never fork, always link
├── slides/
│   ├── deck.css               ← 1920×1080 scaffold: .pad > .shead/.sbody/.sfoot, accents
│   ├── deck-stage.js          ← <deck-stage> engine (nav, scaling, print)
│   ├── tikkurila-google-ads/      ← 15-slide full KP, Ukrainian  (shared slides.css)
│   ├── tikkurila-google-ads-en/   ← same deck, English  (reuses ../tikkurila-google-ads/slides.css)
│   ├── tikkurila-google-ads-ru/   ← same deck, Russian for Kazakhstan
│   ├── korolyuk/              ← compact 10-slide Google Ads KP, Ukrainian (medical niche)
│   ├── mathematic/            ← 9-slide Meta-only KP, Ukrainian (creatives/funnels/VSL)
│   ├── taxi-superapp-kz/      ← 10-slide Google Ads "hypothesis test" KP, Russian (no forecasts)
│   ├── at7adak-en/            ← 11-slide Meta RMG KP, English (compliance, ladder, 2-price offer)
│   ├── audit-template/        ← 17-slide express-audit constructor, Ukrainian
│   ├── audit-template-en/     ← same, English (reuses ../audit-template/audit.css)
│   └── performance-plus-dark/ ← single-slide dark package card
└── SKILL.md                   ← design-system brand guide (voice, colors, type, accents)
.claude/skills/registeam-kp/scripts/   ← bundled export scripts (use these, do not rewrite)
```

Every deck folder is self-contained: `index.html` + a per-deck CSS file +
`logo.svg`. The deck HTML links three stylesheets in this exact order:
`../../colors_and_type.css` → `../deck.css` → the per-deck CSS.

## Standalone use (no registeam-deck repo present)

This skill also ships everything it needs in `assets/`, so it works in any
project. If the repo above is **not** in your working tree, recreate its
expected layout once, then follow the normal workflow with unchanged
relative links:

```bash
mkdir -p "RegisTeam Design System/slides"
cp <skill>/assets/design-system/colors_and_type.css "RegisTeam Design System/"
cp <skill>/assets/design-system/deck.css <skill>/assets/design-system/deck-stage.js "RegisTeam Design System/slides/"
cp -r <skill>/assets/templates/<donor>  "RegisTeam Design System/slides/<donor>"   # the donor deck you picked
```

`assets/templates/` holds all ten reference decks (HTML + CSS + logo, no
binaries); `assets/design-system/logo.svg` is the canonical logo to copy
into new deck folders. Language variants (`…-en`, `…-ru`, `audit-template-en`)
link their base deck's CSS by sibling path — copy the base folder alongside
them. The bundled scripts require Node.js with Playwright
and its Chromium available (`npm i -g playwright && npx playwright install
chromium` if missing).

## Golden rules

**1. Data discipline.** A deck contains *only* the data the user gave for
this client: budget, geo, prices, keywords, contacts. Never let numbers,
niches, currencies or phone numbers leak in from a donor deck — after
copying, grep the HTML for the donor's client name, domain, prices and
currency symbols. This has been an explicit client requirement.

**2. Forecast policy.** Three modes, chosen by the situation:
- Client supplied forecast numbers → use them verbatim (see korolyuk).
- No client numbers but an established market → build a 3-scenario forecast
  from *verified current benchmarks* (search the web; restricted verticals
  like real-money gaming cost 2–4× casual rates) and always add the
  disclaimer line that figures are estimates locked after the first cycles.
  Numbers that look too good get challenged by the user — be conservative.
- Brand-new untested direction → **no forecast at all**. Use the
  "hypothesis test" framing instead (see taxi-superapp-kz slide 6: "we don't
  give forecasts — we test demand", measure CPC/bundles/cost-per-lead, fix
  KPIs after month two).

**3. Logo.** Always `<img src="logo.svg">` from a local copy
(`cp <any-deck>/logo.svg <new-deck>/logo.svg`). Never hotlink
registeam.net — it fails in headless renders and PDFs. On dark slides the
CSS applies `filter: brightness(0) invert(1)`. Never rebuild the logo as
styled text spans — that shipped once and the client flagged it.

**4. Voice.** Confident performance-marketing tone. Sentence case, mono
uppercase eyebrows, numbers up front, zero emoji in deck copy, the `→` glyph
as the house accent. Match the language of the deck consistently — including
`<html lang>`, speaker notes and footer labels.

**5. Structure is fixed.** Slide order is canonical per deck type
(`references/structures.md`). Do not invent new orders or shuffle slides;
pick the structure, then fill it. When the user removes/adds a slide,
renumber every footer counter (`NN / TOTAL`) and the `→ 00N /` header labels,
and keep the speaker-notes array the same length as the slide count.

## Workflow: new KP

1. **Pick the donor** from the table in `references/structures.md`
   (channel + language + closeness of niche decide). Copy its CSS file and
   `logo.svg` into a new folder `RegisTeam Design System/slides/<client>/`,
   rename the CSS, update its header comment.
2. **Write `index.html`**: keep the three-stylesheet head, `deck-stage`
   wrapper, and the canonical slide order. Replace all content with the
   client's data. Set `<html lang>`, `<title>`, speaker notes.
3. **Adapt the CSS only where layout changes** (e.g. a 5-column campaign
   tree becoming 3 columns: adjust `.strat .cols` grid and `.bus` insets).
   New blocks get appended, never inlined as style attributes.
4. **Render-check** every slide:
   `node .claude/skills/registeam-kp/scripts/shoot-slides.js <deck-dir> /tmp/shots`
   The script removes nav chrome and reports per-slide overflow. Look at the
   screenshots — actually read them — for broken wraps, overlapping accents
   (`.gacc` rhombi must sit in empty corners), and donor-data leftovers.
5. **Export PDF**:
   `node .claude/skills/registeam-kp/scripts/export-pdf.js <deck-dir> [name.pdf]`
   This produces a *raster* PDF (one screenshot per page) — the only export
   mode that renders shadows and fonts identically everywhere.
6. **Figma export** (only when asked):
   `node .claude/skills/registeam-kp/scripts/build-figma-export.js <deck-dir>`
   Produces a self-contained `figma-export.html` where every slide is a
   visible named frame for the html.to.design plugin.
7. **Commit and push** to the designated branch; send the deliverable file
   to the user with SendUserFile when available.

## Workflow: edits and translations

- Small text/price edits: edit in place, re-render the affected slides,
  re-export the PDF. If wording length changed, re-check overflow.
- Subheadings that wrap badly: the shared `.det .goal` uses
  `text-wrap: balance` — keep it when copying CSS.
- Translation: create a sibling folder `<deck>-en` / `<deck>-ru`, reuse the
  donor's CSS by relative link (single styling source — see the tikkurila
  trio), translate only the HTML. Localize currency, geo examples and the ad
  "Sponsored/Реклама" tag per `references/localization.md`.
- Single-slide requests (a package card, a timeline) get a standalone file
  with a `.frame` section — see `performance-plus-dark/` and
  `korolyuk/stages-en.html` for the pattern; export via shoot-slides.

## Audits

Audit decks come from `audit-template/` (uk) or `audit-template-en/` (en):
a fixed spine (title → context → traffic-light dashboard → divider →
findings → summary+calculator → action plan → 3-month strategy → proposal →
next steps) plus six interchangeable "finding" layouts and a two-slide
auditor UI-kit. Managers duplicate finding layouts per finding; screenshot
spots are dashed `.ph` placeholders. Details in `references/structures.md`.

## Non-negotiables before delivering

- Zero overflow on every slide (the scripts assert this — heed warnings).
- No nav chrome (counter / Reset pill) visible in any exported artifact.
- Footer counters and header `→ 00N` labels match the real slide count.
- The PDF page count equals the slide count.
- grep confirms no donor-client strings remain.
- CRO, Google, Meta, packages, prices — only what was requested. When the
  user says "no CRO" or "Meta only", grep for the excluded terms to verify.
