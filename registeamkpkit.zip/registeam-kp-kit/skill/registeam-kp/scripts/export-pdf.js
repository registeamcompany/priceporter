#!/usr/bin/env node
/**
 * export-pdf.js — export a deck to a raster PDF, one slide per page.
 *
 * Usage:
 *   node export-pdf.js <deck-dir> [output.pdf]
 *     default output: <deck-dir>/<deck-dir-basename>.pdf
 *
 * Why raster (see references/pitfalls.md):
 *   - vector print mis-renders blurred box-shadows as grey rectangles (#2),
 *     so each slide is captured as a @2x screenshot and printed as an image;
 *   - the nav overlay (counter + Reset) is removed before capture (#3);
 *   - screenshots are embedded as base64 — file:// imgs silently fail (#5);
 *   - the script verifies PDF page count == slide count (#6) and reports
 *     per-slide overflow (#7).
 */
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');
const pw = require(path.join(execSync('npm root -g').toString().trim(), 'playwright'));

(async () => {
  const [deckDir, outArg] = process.argv.slice(2);
  if (!deckDir) { console.error('usage: export-pdf.js <deck-dir> [output.pdf]'); process.exit(1); }
  const dir = path.resolve(deckDir);
  const out = outArg ? path.resolve(outArg) : path.join(dir, path.basename(dir) + '.pdf');

  const browser = await pw.chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 2 });
  await page.goto('file://' + path.join(dir, 'index.html'), { waitUntil: 'networkidle' });
  await page.evaluate(() => {
    const ds = document.querySelector('deck-stage');
    ds.setAttribute('no-rail', '');
    ds.shadowRoot && ds.shadowRoot.querySelector('.overlay')?.remove();
  });
  await page.waitForTimeout(1000);

  const total = await page.evaluate(() => document.querySelectorAll('deck-stage > section').length);
  let pages = '', warnings = 0;
  for (let i = 1; i <= total; i++) {
    await page.waitForTimeout(350);
    const over = await page.evaluate(() => {
      const s = document.querySelector('deck-stage > section[data-deck-active] .sbody');
      return s ? s.scrollHeight - s.clientHeight : 0;
    });
    if (over > 12) { warnings++; console.log(`slide ${i}: OVERFLOW ${over}px`); }
    else if (over > 0) console.log(`slide ${i}: tight fit (${over}px, likely rounding)`);
    const buf = await page.screenshot();
    pages += `<div class="pg"><img src="data:image/png;base64,${buf.toString('base64')}"></div>`;
    await page.keyboard.press('ArrowRight');
  }
  await page.close();

  const doc = `<!doctype html><html><head><meta charset="utf-8"><style>
@page{size:1920px 1080px;margin:0}html,body{margin:0;padding:0}
.pg{width:1920px;height:1080px;overflow:hidden;page-break-after:always}
.pg:last-child{page-break-after:auto}.pg img{width:1920px;height:1080px;display:block}
</style></head><body>${pages}</body></html>`;
  const p2 = await browser.newPage();
  await p2.setContent(doc, { waitUntil: 'load' });
  await p2.waitForTimeout(600);
  await p2.emulateMedia({ media: 'print' });
  await p2.pdf({ path: out, width: '1920px', height: '1080px', printBackground: true });
  await browser.close();

  const bytes = fs.readFileSync(out);
  const pageCount = (bytes.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
  console.log(`slides: ${total}  PDF pages: ${pageCount}  size: ${(bytes.length / 1048576).toFixed(2)}MB  → ${out}`);
  if (pageCount !== total) { console.error('ERROR: page count mismatch'); process.exit(2); }
  if (warnings) { console.error(`WARNING: ${warnings} slide(s) overflow — fix before delivering`); process.exit(2); }
})();
