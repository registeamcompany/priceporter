#!/usr/bin/env node
/**
 * build-figma-export.js — build a self-contained figma-export.html for any deck.
 *
 * Usage:
 *   node build-figma-export.js <deck-dir>
 *     writes <deck-dir>/figma-export.html
 *
 * Why a separate artifact (see references/pitfalls.md #16–17):
 *   <deck-stage> hides every slide except the active one, so Figma importers
 *   (html.to.design) would capture a single slide. This builder lays ALL
 *   slides out as visible, named 1920×1080 frames:
 *   - inlines every <link rel="stylesheet"> from index.html in order,
 *     stripping ?v= query strings when resolving paths;
 *   - rewrites the deck-stage sizing rule onto a plain .frame class;
 *   - names frames "NN · <data-label>" (translated labels come for free);
 *   - embeds logo.svg as a data URI so the file needs no external assets.
 *   Regenerate after every HTML/CSS edit — never hand-edit the output.
 */
const path = require('path');
const fs = require('fs');

const deckDir = process.argv[2];
if (!deckDir) { console.error('usage: build-figma-export.js <deck-dir>'); process.exit(1); }
const dir = path.resolve(deckDir);
const html = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');

// 1 · inline all linked stylesheets, in document order
let css = '';
for (const m of html.matchAll(/<link\s+rel="stylesheet"\s+href="([^"]+)"/g)) {
  const href = m[1].split('?')[0];
  const p = path.resolve(dir, href);
  let sheet = fs.readFileSync(p, 'utf8');
  if (path.basename(p) === 'deck.css') {
    sheet = sheet
      .replace('deck-stage > section {', '.frame {')
      .replace('html, body { margin: 0; background: #05080f; }', '');
  }
  css += `\n/* ========== inlined: ${href} ========== */\n` + sheet;
}

// 2 · logo as data URI (if present)
let logoData = null;
const logoPath = path.join(dir, 'logo.svg');
if (fs.existsSync(logoPath)) {
  logoData = 'data:image/svg+xml;base64,' + fs.readFileSync(logoPath).toString('base64');
}

// 3 · sections → named visible frames
const sections = html.match(/<section\b[\s\S]*?<\/section>/g) || [];
const frames = sections.map((sec, i) => {
  const n = String(i + 1).padStart(2, '0');
  const label = (sec.match(/data-label="([^"]*)"/) || [, `Slide ${i + 1}`])[1];
  let s = sec.replace(/<section class="/, `<section id="slide-${n}" data-name="${n} · ${label}" class="frame `);
  if (logoData) s = s.replace(/src="logo\.svg"/g, `src="${logoData}"`);
  return s;
});
if (!frames.length) { console.error('no <section> slides found'); process.exit(1); }

const lang = (html.match(/<html\s+lang="([^"]+)"/) || [, 'uk'])[1];
const title = (html.match(/<title>([^<]*)<\/title>/) || [, 'Deck'])[1];

const out = `<!doctype html>
<html lang="${lang}">
<head>
<meta charset="utf-8" />
<title>${title} · Figma export</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Inter+Tight:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" />
<style>
${css}

/* ---- Figma export canvas (not part of any frame) ---- */
html, body { margin: 0; background: #1E1E1E; }
.page { display: flex; flex-direction: column; align-items: center; gap: 96px; padding: 96px 0 120px; }
.frame { flex: 0 0 auto; box-shadow: 0 24px 80px rgba(0,0,0,0.4); }
</style>
</head>
<body>
  <div class="page">

${frames.join('\n\n')}

  </div>
</body>
</html>
`;
fs.writeFileSync(path.join(dir, 'figma-export.html'), out);
console.log(`figma-export.html written — ${frames.length} frames${logoData ? ', logo embedded' : ''}.`);
