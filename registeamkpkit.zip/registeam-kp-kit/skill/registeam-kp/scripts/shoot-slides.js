#!/usr/bin/env node
/**
 * shoot-slides.js — render a deck's slides to PNG for visual review.
 *
 * Usage:
 *   node shoot-slides.js <deck-dir> <out-dir> [slides]
 *     deck-dir  folder containing index.html (a <deck-stage> deck)
 *     out-dir   where slide-NN.png files go (created if missing)
 *     slides    optional comma list, e.g. "1,3,7" (default: all)
 *
 * What it encodes (see references/pitfalls.md):
 *   - removes the nav overlay + rail from the shadow DOM before capture (#3)
 *   - steps slides with ArrowRight, not #hash (#4)
 *   - reports per-slide .sbody overflow in px — must be 0 (#7)
 */
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');
const pw = require(path.join(execSync('npm root -g').toString().trim(), 'playwright'));

(async () => {
  const [deckDir, outDir, slidesArg] = process.argv.slice(2);
  if (!deckDir || !outDir) { console.error('usage: shoot-slides.js <deck-dir> <out-dir> [1,2,3]'); process.exit(1); }
  fs.mkdirSync(outDir, { recursive: true });
  const url = 'file://' + path.resolve(deckDir, 'index.html');

  const browser = await pw.chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.evaluate(() => {
    const ds = document.querySelector('deck-stage');
    ds.setAttribute('no-rail', '');
    ds.shadowRoot && ds.shadowRoot.querySelector('.overlay')?.remove();
  });
  await page.waitForTimeout(1000);

  const total = await page.evaluate(() => document.querySelectorAll('deck-stage > section').length);
  const wanted = slidesArg ? slidesArg.split(',').map(Number) : Array.from({ length: total }, (_, i) => i + 1);
  let bad = 0;

  for (let i = 1; i <= total; i++) {
    await page.waitForTimeout(350);
    if (wanted.includes(i)) {
      const over = await page.evaluate(() => {
        const s = document.querySelector('deck-stage > section[data-deck-active] .sbody');
        return s ? s.scrollHeight - s.clientHeight : 0;
      });
      if (over > 12) { bad++; console.log(`slide ${i}: OVERFLOW ${over}px — fix the copy`); }
      else if (over > 0) console.log(`slide ${i}: tight fit (${over}px, likely rounding) — visually verify`);
      const file = path.join(outDir, `slide-${String(i).padStart(2, '0')}.png`);
      await page.screenshot({ path: file });
      console.log(`slide ${i}/${total} → ${file}${over > 12 ? '  ⚠ overflow' : ''}`);
    }
    await page.keyboard.press('ArrowRight');
  }
  await browser.close();
  console.log(bad ? `DONE with ${bad} overflow warning(s)` : 'DONE — no overflow');
  process.exit(bad ? 2 : 0);
})();
