# Localization — Ukrainian · English · Russian

Decks exist in three languages. The layout/styling is language-agnostic and
shared; only HTML text differs. The reference implementation is the
tikkurila trio: `tikkurila-google-ads/` owns `slides.css`, and the `-en` /
`-ru` siblings link it via `../tikkurila-google-ads/slides.css` — one styling
source, so design edits propagate to all languages by re-rendering.

## Making a translation

1. Create the sibling folder `<deck>-en` or `<deck>-ru`, copy `logo.svg`.
2. `index.html`: link the *donor's* per-deck CSS relatively; translate all
   copy including `<title>`, `<html lang>`, `data-label`s, speaker notes,
   footer labels. Numbers, prices and proper nouns stay unchanged unless the
   market changes (see below).
3. Re-render and overflow-check: RU/UK strings run ~10–20% longer than EN —
   two-line headings and pill labels are the usual casualties.
4. If a `build-figma-export.js` is needed, run the bundled generic one; frame
   names come from the translated `data-label`s automatically.

## Market localization ≠ translation

When the deck targets a different market (e.g. RU deck for Kazakhstan):
- Currency in product mockups: `₴` → `₸` (or the client's), with plausible
  local price levels.
- Geo keyword examples: use the market's cities (`київ` → `алматы, астана`).
- Region fact on the cover: the actual target geo.
- Phone numbers: only ones the user provided; +7 700… is the KZ office line
  used historically, +38 094 710 51 00 the UA/global one.

## Fixed label translations

| uk | en | ru |
| --- | --- | --- |
| Комерційна пропозиція | Commercial proposal | Коммерческое предложение |
| Пропозиція RegisTeam | The RegisTeam Proposal | Предложение RegisTeam |
| → Сайт / Бюджет / Регіон / Ціль | → Website / Budget / Region (Geo) / Goal | → Сайт / Бюджет / Регион / Цель |
| Мета (eyebrow label) | Goal | Цель |
| Що входить у пакет: | What's included: | Что входит в пакет: |
| Робоча ціль (forecast badge) | Working target | Рабочая цель |
| Песимістичний / Реалістичний / Оптимістичний | Conservative / Realistic / Optimistic | Пессимистичный / Реалистичный / Оптимистичный |
| Етапи реалізації | Implementation stages / Roadmap | Этапы реализации |
| Як ми працюємо | How we work | Как мы работаем |
| Наступні кроки · Готові почати? | Next steps · Ready to start? | Следующие шаги · Готовы начать? |
| Дякуємо · registeam.net | Thank you · registeam.net | Спасибо · registeam.net |
| Оголошення/Реклама (ad tag) | Sponsored | Реклама |
| Типи кампаній підбираємо під проєкт і цілі — не запускаємо всі за замовчуванням. | Campaign types are chosen per project and goals — we don't run all of them by default. | Типы кампаний подбираем под проект и цели — не запускаем все по умолчанию. |
| Прогноз орієнтовний… фіксуємо в медіаплані після аудиту. | The forecast is approximate… exact targets are locked in the media plan after the audit. | Прогноз ориентировочный… точные цели фиксируем в медиаплане после аудита. |
| * Рекламний бюджет оплачується окремо. | * Ad budget is paid separately. | * Рекламный бюджет оплачивается отдельно. |

Google's ad-badge wording differs by locale: use **Sponsored** in EN,
**Реклама** in RU, and either **Оголошення** or **Реклама** in UK (newer
decks use Реклама).

Typography notes: use the apostrophe `ʼ` in Ukrainian (звʼязок, обʼєкти),
`’` in English contractions, and `ё` sparingly-but-correctly in Russian
(отчёт, ещё). Keep `&nbsp;` between short prepositions and the next word in
display headings when a donor did.
