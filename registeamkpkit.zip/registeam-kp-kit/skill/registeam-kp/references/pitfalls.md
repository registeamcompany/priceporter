# Pitfalls — every bug this pipeline has already hit

Each of these cost a review round with the client or a broken deliverable.
The bundled scripts in `scripts/` encode most of the fixes — use them instead
of writing ad-hoc Playwright code, and read this list before doing anything
manual.

## Rendering & export

**1. Remote logo doesn't load (blank/alt-text logo).**
Cause: hotlinking `https://registeam.net/wp-content/uploads/2020/11/logo.svg`
— unreliable in headless Chromium and in PDFs.
Fix: local `logo.svg` in every deck folder (copy from any existing deck);
`figma-export` embeds it as a data URI. Related ban: never fake the logo
with styled `REGIS/team` text spans — a deck shipped that way and the client
sent it back ("логотип — це просто тексти").

**2. Grey rectangles behind pills/cards in PDF viewers.**
Cause: Chromium mis-renders *blurred* `box-shadow` when printing to vector
PDF (screen render is fine).
Fix: export raster PDFs — screenshot each slide, then print the screenshots
one-per-page (`scripts/export-pdf.js` does exactly this). If a deck will be
shared as HTML, additionally strip blur shadows from the offending plaques
(`box-shadow: none` on `.strat .node`, ad cards, product cards, featured
forecast card). Halo rings like `0 0 0 6px rgba(...)` are blur-free and safe.

**3. Slide counter + "Reset" pill visible in exports.**
Cause: `<deck-stage>` flashes a nav overlay on every navigation; short waits
capture it mid-fade.
Fix: before capturing, remove it from the shadow root and disable the rail:
```js
const ds = document.querySelector('deck-stage');
ds.setAttribute('no-rail', '');
ds.shadowRoot.querySelector('.overlay')?.remove();
```
Bundled scripts do this automatically.

**4. `#N` hash "navigation" doesn't switch slides.**
The engine reads the hash only on initial load. To step through slides in a
script, send `ArrowRight` key presses with a ~350 ms settle wait.

**5. Raster PDF came out ~7 KB / blank.**
Cause: `<img src="file:///tmp/…png">` blocked when assembling the print
document. Fix: embed screenshots as base64 data URIs (scripts do this).

**6. Verifying the PDF.**
`pdftoppm`/`pdfinfo` are usually absent. Count pages by regex on the bytes:
`/\/Type\s*\/Page[^s]/g` — must equal the slide count.

## Layout

**7. Text overflow off the 1080px canvas.**
Always assert, per slide: `sbody.scrollHeight − sbody.clientHeight === 0`.
`scripts/shoot-slides.js` prints this for every slide. Fix by tightening
copy, not by shrinking the canvas.

**8. Decorative rhombi (`.gacc`) overlapping headers/text.**
They are absolutely positioned; place them only in visually empty corners
(usually bottom-right/-left), and re-check after content edits. This was
flagged on slides 2/9 historically.

**9. Ragged two-line subheadings** (one long line + one dangling word).
Fix: `text-wrap: balance` on `.det .goal` (already in newer per-deck CSS —
keep it when copying) or add a manual `<br/>` in the display heading.

**10. Stale counters after adding/removing slides.**
Three things must stay in sync with the real slide count: footer `NN / TOTAL`
spans, header `→ 00N /` labels, and the speaker-notes JSON array length.
Renumber all of them in the same edit (grep `" / ` and `→ 0` to find them).

## Content

**11. Donor-data leakage.** After copying a donor deck, grep the new HTML for
the donor's domain, client name, prices, currency (`₴`, `₸`, `NZ$`), phone
numbers. The user explicitly requires decks to contain only the current
client's data.

**12. Overclaims get rejected.** "Remarketing returns ~96%" was rejected —
reframe as "~96% enter remarketing; repeat touchpoints bring back the most
interested". Forecast CPIs that look great get challenged too ("$0.85 CPI —
не вірю"): verify against current benchmarks (web search), remember that
restricted verticals (real-money gaming, medical, etc.) cost multiples of
casual rates, and prefer the conservative end.

**13. Near-duplicate steps read as padding.** Shopping "catalog upload" vs
"product feed" was flagged as the same thing twice; the fix was making step
2 about *segmentation in Ads*. When two bullets could be one, merge or
differentiate.

**14. Scope words the client excluded.** If the brief says "без CRO" or
"Meta only" — grep the finished HTML for `CRO`, `Google`, `прогноз`, etc.
An excluded concept appearing anywhere (even in a package list) is a defect.
The only allowed "прогноз" mention in a no-forecast deck is the "we don't
give forecasts" statement itself.

## Process

**15. Shell quoting eats your work.** Backticks inside `git commit -m "…"`
execute as command substitution; Cyrillic + `sed -i` multiline edits corrupt
arrays (a NAMES list once ended up duplicated). Commit with a heredoc
(`git commit -F - <<'MSG' … MSG`) and prefer the Edit tool over sed for
anything beyond a trivial global replace — and verify with grep after any
scripted edit.

**16. figma-export must not be hand-maintained.** The interactive deck hides
all slides except the active one, so importers see one slide. The builder
(`scripts/build-figma-export.js`) converts every `<section>` into a visible,
named `.frame`, inlines all linked CSS (query strings like `?v=2` stripped
when resolving paths) and the logo. Re-run it after any HTML/CSS edit —
never edit `figma-export.html` directly, it will drift.

**17. Figma import fidelity.** Frames import named from `data-label`
(`NN · Label`). Fonts must exist in Figma (Inter Tight, Inter, JetBrains
Mono — all on Google Fonts) or the layout shifts. `.ph` screenshot
placeholders import as frames that take an image fill.
