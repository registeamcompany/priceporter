# Canonical deck structures

Slide order is a product decision that has already been made. Pick the
structure that matches the engagement, then fill it with the client's data.
Reordering or inventing slide types is a bug, not creativity.

All paths below are relative to `RegisTeam Design System/slides/`.

## Donor table — what to copy for what

| Engagement | Donor deck | Lang | Why this one |
| --- | --- | --- | --- |
| Google Ads KP, standard | `korolyuk/` | uk | Compact 10 slides, greyed inactive campaign types, single price + bonuses |
| Google Ads KP, full/e-commerce | `tikkurila-google-ads/` (+`-en`, `-ru`) | uk/en/ru | 15 slides incl. per-campaign detail, packages, about-us; the 3-language pattern |
| Google Ads, new-direction test (no forecast) | `taxi-superapp-kz/` | ru | Audience slide, "hypothesis test" slide instead of forecast, discounted OneSource |
| Meta-only KP, creatives/funnels | `mathematic/` | uk | Deliverable cards (banners/videos/quiz funnels), two-price offer ($first month / then) |
| Meta-only KP, restricted vertical (RMG etc.) | `at7adak-en/` | en | Compliance/launch-readiness slide, optimization ladder, KPI+boundary, 2-price CRO offer |
| Express audit | `audit-template/` (+`-en`) | uk/en | Fixed spine + 6 finding layouts + auditor UI-kit |
| One-off slide (package card, timeline) | `performance-plus-dark/`, `korolyuk/stages-en.html` | uk/en | Standalone `.frame` section, PNG export |

## KP structure (the spine)

Ten roles, in this order. Compact decks merge or drop the optional ones;
never reorder. Bracketed = the CSS section class from the donor decks.

1. **Cover** `[.cover on-dark]` — dark. Logo, `Пропозиція RegisTeam` /
   `The RegisTeam Proposal`, facts bar with exactly the fields the client
   defined (site/channel, budget, geo/region, goal). Optional validity date
   in the footer.
2. **Strategy** `[.strat]` — account tree: dark pill node (`Акаунт Google
   Ads` / `Meta Ads account`) → campaign-type cards. Active cards get color
   strips (`.a1/.a2/.a3`), out-of-scope types stay visible but greyed
   (`.cmp.off` + "Неактивна/Inactive" tag) — showing what we deliberately
   *don't* run builds trust. `.snote` states the focus in one line.
3. **Channel detail slides** `[.det …]` — one per active mechanic, each with
   the shared head (`eyebrow + .dhead sm + .goal` with МЕТА/GOAL label):
   - Google Search `[.search]`: query categories with pill examples
     (cross-query principle or per-segment), plus 1–2 mocked SERP ads for the
     client's domain.
   - Performance Max `[.pmax]`: asset chips + Google AI bar + 6-network grid.
   - Shopping `[.shop]`, Remarketing `[.rmkt]` (funnel bars — mind the
     overclaim rule below), Video `[.video]` — from the tikkurila donors.
   - Meta decks instead use: audiences `[.aud3]`, creatives/deliverables
     `[.deliv-grid .dcard]`, funnels + flowline, launch-readiness `[.gwork]`,
     optimization ladder `[.funl]`, KPI groups `[.kpi]`.
4. **Forecast** `[.det .fc]` — *optional, see the forecast policy in
   SKILL.md*. Three cards: pessimistic / realistic (featured dark card,
   "Робоча ціль / Working target" badge) / optimistic. Rows use only metrics
   the client gave or benchmarks support. Disclaimer `.fc-note` is mandatory.
5. **Offer** `[.offer]` — the money slide. Variants:
   - single price + conditions + bonuses panel (korolyuk: `$540` + dark
     bonus list);
   - two-price first-month/ongoing (mathematic: `$1 190 → $990`);
   - two-option with/without module (at7adak: `$990 CRO / $760`), with a
     short "why this module matters, when to add it" note.
6. **Package** `[.pkg]` — OneSource or Performance+ card: name, description,
   price (strikethrough old price via `.was` when discounting), ✓ checklist.
   Always append `.pk-note`: campaign types are chosen per project, not all
   run by default (a real client complaint fixed this).
7. **Roadmap** `[.det .stages .steps3]` — three period cards with pill
   badges (`7 днів / 1 місяць / 2 місяць` or pre-launch/M1/M2), dashed
   connector line, bullet lists.
8. **How we work** `[.det .howwork]` — three cards (dedicated manager +
   channel chips, monthly reports, weekly Status Report) + team role pills.
9. **Contacts / CTA** `[.cta on-dark]` — dark. Three steps (approve → sign →
   launch), contacts row, coral CTA button.
10. **About RegisTeam** `[.about on-dark]` — optional, from tikkurila:
    stats grid (12 років / 30+ / 15+ / 2) + business-development contact.

Compact 9–11-slide decks = 1,2,3(×2–4),5,6,7,8,9. The full 15-slide deck
adds 4 and 10 plus extra detail and add-on-services slides.

## Audit structure (express audit, 17 slides)

Fixed spine — copy `audit-template/` wholesale and edit:

1 Title (client, date period, monthly budget — exactly three facts) ·
2 Context (facts grid + client-quote problem card) ·
3 Traffic-light dashboard (`.adash`, ok/warn/bad status tokens) ·
4 Divider "Account audit" (dark) ·
5–10 **Findings** — duplicate any mix of the six layouts per real finding:
L1 split/screenshot-left, L2 split/screenshot-right, L3 screen-map with
numbered pins, L4 small-bug tiles, L5 macro-focus (dark, spotlight metric),
L6 screenshot+metric ·
11 Summary + result calculator (fix list with impact chips → dark
calculator card, before→after on ONE key metric; estimate disclaimer
mandatory) ·
12 Action plan graded by time (tomorrow / 2 weeks / 1 month) ·
13 3-month strategy + growth-potential banner ·
14 Proposal (two package tiers) ·
15 Next steps (dark CTA) ·
16–17 Auditor UI-kit (never delete — managers copy overlay elements from
here onto screenshots).

Screenshot spots are dashed `.ph` placeholders ("Перетягніть скриншот /
Drop a screenshot") — keep them as placeholders in templates; they become
image fills after Figma import.

## HTML skeleton every deck follows

```html
<!doctype html>
<html lang="uk|en|ru">
<head>
  <style>deck-stage:not(:defined){visibility:hidden}</style>
  <link rel="stylesheet" href="../../colors_and_type.css?v=2" />
  <link rel="stylesheet" href="../deck.css?v=2" />
  <link rel="stylesheet" href="<deck>.css?v=1" />
  <script src="../deck-stage.js"></script>
  <script type="application/json" id="speaker-notes">[ …one string per slide… ]</script>
</head>
<body>
<deck-stage width="1920" height="1080">
  <section class="rt-v2 <type> [on-dark]" data-label="…">
    <div class="glow"></div>                      <!-- dark slides only -->
    <span class="gacc rh-c" style="…"></span>     <!-- accents in EMPTY corners -->
    <div class="pad">
      <div class="shead"><span class="kl">→ 00N / Розділ</span><span class="kr">Підзаголовок</span></div>
      <div class="sbody"> …content… </div>
      <div class="sfoot"><img src="logo.svg" alt="RegisTeam" /><span>0N / NN</span></div>
    </div>
  </section>
  …
</deck-stage>
</body>
</html>
```

## Copy patterns that already survived client review

- Remarketing reach: say the ~96% *enter remarketing* ("У ремаркетинг
  потрапляють ~96%") — never "remarketing brings back 96%", that's an
  overclaim the client rejected.
- Shopping flow steps must be distinct: Merchant Center (validate the feed)
  → Segmentation in Ads (groups by category/brand/margin for separate bids)
  → Shopping ads. "Catalog" and "feed" as two steps reads as duplication.
- Package note: "Типи кампаній підбираємо під проєкт і цілі — не запускаємо
  всі за замовчуванням." (translations in localization.md).
- Budget framing: if the money is for a hypothesis test, label it "на тест
  гіпотези / for the hypothesis test", not "/ міс".
- Overage pricing when limits exist: "Понад ліміт — додатково $X за …".
