/**
 * build-figma-export.js  (RU deck — Kazakhstan market)
 * --------------------------------------------------------------------------
 * Generates a single self-contained `figma-export.html` from the Russian
 * deck: all 15 slides as static, fully-visible 1920×1080 frames so a Figma
 * importer (e.g. the html.to.design plugin) captures each <section> as its
 * own editable frame.
 *
 * Per-slide styling is shared with the Ukrainian/English decks (one source
 * of truth): we inline `../tikkurila-google-ads/slides.css`.
 *
 * Run:  node build-figma-export.js
 * --------------------------------------------------------------------------
 */
const fs = require('fs');
const path = require('path');

const here = __dirname;
const read = (p) => fs.readFileSync(p, 'utf8');

const tokensCss = read(path.join(here, '..', '..', 'colors_and_type.css'));
let deckCss = read(path.join(here, '..', 'deck.css'));
const slidesCss = read(path.join(here, '..', 'tikkurila-google-ads', 'slides.css'));

deckCss = deckCss.replace('deck-stage > section {', '.frame {');
deckCss = deckCss.replace('html, body { margin: 0; background: #05080f; }', '');

const indexHtml = read(path.join(here, 'index.html'));
const sections = indexHtml.match(/<section\b[\s\S]*?<\/section>/g) || [];

const NAMES = [
  '01 · Обложка',
  '02 · Стратегия',
  '03 · Google Search',
  '04 · Performance Max',
  '05 · Standard Shopping',
  '06 · Remarketing',
  '07 · Video Campaign',
  '08 · Прогноз',
  '09 · Гарантия',
  '10 · Пакет OneSource',
  '11 · Пакет Performance+',
  '12 · Этапы реализации',
  '13 · Как мы работаем',
  '14 · Дополнительные услуги',
  '15 · О RegisTeam',
];

const frames = sections.map((sec, i) => {
  const id = NAMES[i] ? NAMES[i].replace(/^(\d+).*$/, 'slide-$1') : `slide-${i + 1}`;
  const name = NAMES[i] || `Slide ${i + 1}`;
  return sec.replace(
    /<section class="/,
    `<section id="${id}" data-name="${name}" class="frame `
  );
});

const pageCss = `
/* ---- Figma export canvas (not part of any frame) ---- */
html, body { margin: 0; background: #1E1E1E; }
.page { display: flex; flex-direction: column; align-items: center; gap: 96px; padding: 96px 0 120px; }
.frame { flex: 0 0 auto; box-shadow: 0 24px 80px rgba(0,0,0,0.4); }
`;

const html = `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8" />
<title>RegisTeam — Tikkurila Google Ads · Figma export (RU)</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Inter+Tight:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" />
<style>
${tokensCss}

/* ====================== deck scaffold (deck.css) ====================== */
${deckCss}

/* ====================== per-slide styles (shared slides.css) ====================== */
${slidesCss}

/* ====================== export page layout ====================== */
${pageCss}
</style>
</head>
<body>
  <div class="page">

${frames.join('\n\n')}

  </div>
</body>
</html>
`;

fs.writeFileSync(path.join(here, 'figma-export.html'), html);
console.log(`figma-export.html (RU) written — ${frames.length} frames.`);
