/**
 * build-figma-export.js  (Audit template — EN)
 * --------------------------------------------------------------------------
 * Self-contained `figma-export.html` from the English audit deck: every
 * slide laid out as a static, fully-visible 1920×1080 frame so a Figma
 * importer (e.g. html.to.design) captures each <section> as its own editable
 * frame. Screenshot `.ph` placeholders import as frames the auditor turns
 * into image fills.
 *
 * Shares the language-agnostic styles with the UA audit deck
 * (../audit-template/audit.css) and embeds the logo inline as a data URI so
 * the exported single file needs no external assets.
 *
 * Run:  node build-figma-export.js
 * --------------------------------------------------------------------------
 */
const fs = require('fs');
const path = require('path');

const here = __dirname;
const read = (p) => fs.readFileSync(p, 'utf8');

const tokensCss = read(path.join(here, '..', '..', 'colors_and_type.css'));
let deckCss = read(path.join(here, '..', 'deck.css'));
const auditCss = read(path.join(here, '..', 'audit-template', 'audit.css'));

deckCss = deckCss.replace('deck-stage > section {', '.frame {');
deckCss = deckCss.replace('html, body { margin: 0; background: #05080f; }', '');

// Inline the logo as a data URI so the export is fully self-contained.
const logoB64 = fs.readFileSync(path.join(here, 'logo.svg')).toString('base64');
const logoData = 'data:image/svg+xml;base64,' + logoB64;

let indexHtml = read(path.join(here, 'index.html'));
const sections = (indexHtml.match(/<section\b[\s\S]*?<\/section>/g) || [])
  .map((s) => s.replace(/src="logo\.svg"/g, `src="${logoData}"`));

const NAMES = [
  '01 · Title',
  '02 · Context',
  '03 · Global assessment',
  '04 · Audit divider',
  '05 · L1 Split left',
  '06 · L2 Split right',
  '07 · L3 Screen map',
  '08 · L4 Tiles',
  '09 · L5 Macro focus',
  '10 · L6 Screenshot + metric',
  '11 · Summary + calculator',
  '12 · Action plan',
  '13 · Strategy 3 mo',
  '14 · Proposal',
  '15 · Next Steps',
  '16 · UI-kit · 1',
  '17 · UI-kit · 2',
];

const frames = sections.map((sec, i) => {
  const id = NAMES[i] ? NAMES[i].replace(/^(\d+).*$/, 'slide-$1') : `slide-${i + 1}`;
  const name = NAMES[i] || `Slide ${i + 1}`;
  return sec.replace(/<section class="/, `<section id="${id}" data-name="${name}" class="frame `);
});

const pageCss = `
/* ---- Figma export canvas (not part of any frame) ---- */
html, body { margin: 0; background: #1E1E1E; }
.page { display: flex; flex-direction: column; align-items: center; gap: 96px; padding: 96px 0 120px; }
.frame { flex: 0 0 auto; box-shadow: 0 24px 80px rgba(0,0,0,0.4); }
`;

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>RegisTeam — Audit template · Figma export (EN)</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Inter+Tight:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" />
<style>
${tokensCss}

/* ====================== deck scaffold (deck.css) ====================== */
${deckCss}

/* ====================== audit template styles (audit.css) ====================== */
${auditCss}

/* ====================== export page layout ====================== */
${pageCss}
</style>
</head>
<body>
  <div class="page">

${frames.join('\n\n')}

  </div>
</body>
</html>
`;

fs.writeFileSync(path.join(here, 'figma-export.html'), html);
console.log(`figma-export.html (audit EN) written — ${frames.length} frames.`);
