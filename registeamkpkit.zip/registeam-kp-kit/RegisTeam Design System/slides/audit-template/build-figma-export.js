/**
 * build-figma-export.js  (Audit template — constructor)
 * --------------------------------------------------------------------------
 * Generates a single self-contained `figma-export.html` from the audit deck:
 * all slides laid out as static, fully-visible 1920×1080 frames so a Figma
 * importer (e.g. html.to.design) captures each <section> as its own editable
 * frame. Screenshot `.ph` placeholders import as frames the auditor turns
 * into image fills.
 *
 * Run:  node build-figma-export.js
 * --------------------------------------------------------------------------
 */
const fs = require('fs');
const path = require('path');

const here = __dirname;
const read = (p) => fs.readFileSync(p, 'utf8');

const tokensCss = read(path.join(here, '..', '..', 'colors_and_type.css'));
let deckCss = read(path.join(here, '..', 'deck.css'));
const auditCss = read(path.join(here, 'audit.css'));

deckCss = deckCss.replace('deck-stage > section {', '.frame {');
deckCss = deckCss.replace('html, body { margin: 0; background: #05080f; }', '');

const indexHtml = read(path.join(here, 'index.html'));
const sections = indexHtml.match(/<section\b[\s\S]*?<\/section>/g) || [];

const NAMES = [
  '01 · Титул',
  '02 · Ввідні дані',
  '03 · Загальна оцінка',
  '04 · Блок аудиту',
  '05 · L1 Спліт зліва',
  '06 · L2 Спліт справа',
  '07 · L3 Карта екрана',
  '08 · L4 Плитка',
  '09 · L5 Макро-фокус',
  '10 · L6 Скрін + метрика',
  '11 · Підсумок + калькулятор',
  '12 · План дій',
  '13 · Стратегія 3 міс',
  '14 · Пропозиція',
  '15 · Next Steps',
  '16 · UI-кіт · 1',
  '17 · UI-кіт · 2',
];

const frames = sections.map((sec, i) => {
  const id = NAMES[i] ? NAMES[i].replace(/^(\d+).*$/, 'slide-$1') : `slide-${i + 1}`;
  const name = NAMES[i] || `Slide ${i + 1}`;
  return sec.replace(/<section class="/, `<section id="${id}" data-name="${name}" class="frame `);
});

const pageCss = `
/* ---- Figma export canvas (not part of any frame) ---- */
html, body { margin: 0; background: #1E1E1E; }
.page { display: flex; flex-direction: column; align-items: center; gap: 96px; padding: 96px 0 120px; }
.frame { flex: 0 0 auto; box-shadow: 0 24px 80px rgba(0,0,0,0.4); }
`;

const html = `<!doctype html>
<html lang="uk">
<head>
<meta charset="utf-8" />
<title>RegisTeam — Audit template · Figma export</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Inter+Tight:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" />
<style>
${tokensCss}

/* ====================== deck scaffold (deck.css) ====================== */
${deckCss}

/* ====================== audit template styles (audit.css) ====================== */
${auditCss}

/* ====================== export page layout ====================== */
${pageCss}
</style>
</head>
<body>
  <div class="page">

${frames.join('\n\n')}

  </div>
</body>
</html>
`;

fs.writeFileSync(path.join(here, 'figma-export.html'), html);
console.log(`figma-export.html (audit) written — ${frames.length} frames.`);
