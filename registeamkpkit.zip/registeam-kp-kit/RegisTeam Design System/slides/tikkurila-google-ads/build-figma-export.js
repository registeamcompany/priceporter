/**
 * build-figma-export.js
 * --------------------------------------------------------------------------
 * Generates a single self-contained `figma-export.html` from this deck.
 *
 * The interactive deck (index.html) hides every slide except the active one
 * via the <deck-stage> web component — great for presenting, but a Figma
 * importer (e.g. the html.to.design plugin) only "sees" the one visible
 * slide. This build does the opposite: it lays ALL slides out as static,
 * fully-visible 1920×1080 frames stacked in a column, and inlines every
 * stylesheet + the webfont link, so the output is one portable file where
 * each <section> imports as its own Figma frame (with nested layers / text).
 *
 * Run:  node build-figma-export.js
 * --------------------------------------------------------------------------
 */
const fs = require('fs');
const path = require('path');

const here = __dirname;
const read = (p) => fs.readFileSync(p, 'utf8');

// 1 · Collect the design-system CSS (tokens) + deck scaffold + per-slide CSS.
//     colors_and_type.css MUST come first: it begins with the Google Fonts
//     @import, which is only valid before any other CSS rule.
const tokensCss = read(path.join(here, '..', '..', 'colors_and_type.css'));
let deckCss = read(path.join(here, '..', 'deck.css'));
const slidesCss = read(path.join(here, 'slides.css'));

// The only deck-stage-specific selector in deck.css sizes each slide. Re-point
// it at a plain `.frame` class so the slides size themselves without the
// custom element. Everything else in deck.css is plain classes (.pad, .shead…).
deckCss = deckCss.replace('deck-stage > section {', '.frame {');
// deck.css paints the page chrome black for the presenter; the export page
// wants a neutral canvas instead — drop that one rule (page CSS sets its own).
deckCss = deckCss.replace('html, body { margin: 0; background: #05080f; }', '');

// 2 · Pull the 7 <section> slides straight out of index.html so the two files
//     never drift. Tag each as a `.frame` and give it a stable id/name.
const indexHtml = read(path.join(here, 'index.html'));
const sections = indexHtml.match(/<section\b[\s\S]*?<\/section>/g) || [];

const NAMES = [
  '01 · Обкладинка',
  '02 · Стратегія',
  '03 · Google Search',
  '04 · Performance Max',
  '05 · Standard Shopping',
  '06 · Remarketing',
  '07 · Video Campaign',
];

const frames = sections.map((sec, i) => {
  const id = NAMES[i] ? NAMES[i].replace(/^(\d+).*$/, 'slide-$1') : `slide-${i + 1}`;
  const name = NAMES[i] || `Slide ${i + 1}`;
  // Add the `frame` class (first, so it's easy to spot) + id + data-name.
  return sec.replace(
    /<section class="/,
    `<section id="${id}" data-name="${name}" class="frame `
  );
});

// 3 · Page-layout CSS — stacks the frames on a Figma-like grey canvas. Goes
//     AFTER the imported sheets so its html/body background wins.
const pageCss = `
/* ---- Figma export canvas (not part of any frame) ---- */
html, body { margin: 0; background: #1E1E1E; }
.page { display: flex; flex-direction: column; align-items: center; gap: 96px; padding: 96px 0 120px; }
.frame { flex: 0 0 auto; box-shadow: 0 24px 80px rgba(0,0,0,0.4); }
`;

const html = `<!doctype html>
<html lang="uk">
<head>
<meta charset="utf-8" />
<title>RegisTeam — Tikkurila Google Ads · Figma export</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<!-- Webfonts: linked here so importers fetch the real type. Also @import'ed
     inside the inlined CSS below for self-contained rendering. -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Inter+Tight:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" />
<style>
${tokensCss}

/* ====================== deck scaffold (deck.css) ====================== */
${deckCss}

/* ====================== per-slide styles (slides.css) ====================== */
${slidesCss}

/* ====================== export page layout ====================== */
${pageCss}
</style>
</head>
<body>
  <div class="page">

${frames.join('\n\n')}

  </div>
</body>
</html>
`;

fs.writeFileSync(path.join(here, 'figma-export.html'), html);
console.log(`figma-export.html written — ${frames.length} frames.`);
