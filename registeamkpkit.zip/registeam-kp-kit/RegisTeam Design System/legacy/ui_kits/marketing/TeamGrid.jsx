/* global React */

const TEAM = [
  { img: "https://registeam.net/wp-content/uploads/2021/01/gromadskiy.jpg", name: "MAXYM HROMADSKY", role: "Head of Marketing Department" },
  { img: "https://registeam.net/wp-content/uploads/2021/01/makarskiy.jpg",  name: "OLEKSIY MAKARSKY",  role: "Head of Content Projects" },
  { img: "https://registeam.net/wp-content/uploads/2024/11/yulya-bukreeva.jpg", name: "YULIA BUKREEVA", role: "Head of SEO Department" },
  { img: "https://registeam.net/wp-content/uploads/2026/04/img_20251119_152504_375_1_.jpg-1-1.png", name: "KATERYNA SHMYHELSKA", role: "Head of Project Management" },
  { img: "https://registeam.net/wp-content/uploads/2026/04/img_6501-2-1-1.jpg", name: "ANDRII VERKEIENKO", role: "Head of PPC Department" },
];

function TeamGrid() {
  return (
    <section style={{ padding: "80px 32px", background: "var(--rt-white)" }}>
      <div style={{ maxWidth: 1240, margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 24, flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--fg-2)" }}>Our team</div>
            <h2 style={{ margin: "8px 0 0", fontSize: 36, fontWeight: 700, letterSpacing: "-0.01em" }}>Own person in the agency</h2>
            <p style={{ margin: "12px 0 0", color: "var(--fg-2)", fontSize: 16, maxWidth: 540 }}>
              A personal project manager works with you directly and owns the strategy, weekly tasks and monthly results.
            </p>
          </div>
          <div style={{ display: "flex", gap: 40 }}>
            <div>
              <div style={{ fontSize: 56, fontWeight: 700, color: "var(--rt-red-500)", lineHeight: 1 }}>35</div>
              <div style={{ fontSize: 13, color: "var(--fg-2)" }}>advertising specialists</div>
            </div>
            <div>
              <div style={{ fontSize: 56, fontWeight: 700, color: "var(--rt-blue-500)", lineHeight: 1 }}>15</div>
              <div style={{ fontSize: 13, color: "var(--fg-2)" }}>years of experience</div>
            </div>
          </div>
        </div>
        <div style={{ marginTop: 40, display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 18 }}>
          {TEAM.map((p) => (
            <figure key={p.name} style={{ margin: 0 }}>
              <div style={{
                aspectRatio: "1 / 1",
                backgroundImage: `url(${p.img})`,
                backgroundSize: "cover", backgroundPosition: "center top",
                borderRadius: 12,
                border: "1px solid var(--border-default)",
              }} />
              <figcaption style={{ marginTop: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "var(--fg-1)", letterSpacing: "0.02em" }}>{p.name}</div>
                <div style={{ fontSize: 12, color: "var(--fg-2)", marginTop: 2 }}>{p.role}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

window.TeamGrid = TeamGrid;
