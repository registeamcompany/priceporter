/* global React, Figure, FIG */

function StatRow() {
  const STATS = [
    { v: "32+", l: "certificated specialists" },
    { v: "1326+", l: "big-time projects" },
    { v: "25+", l: "countries we work with" },
    { v: "15", l: "years of experience" },
  ];
  return (
    <section style={{ padding: "60px 32px", background: "var(--bg-2)", position: "relative", overflow: "hidden" }}>
      <Figure src={`${FIG}/rocket.png`} style={{ right: "4%", top: "50%", transform: "translateY(-50%) rotate(-12deg)", width: 140, opacity: 0.9 }} />
      <Figure src={`${FIG}/rhombus_blue.svg`} style={{ left: "8%", top: 28, width: 18 }} />
      <Figure src={`${FIG}/rhombus_red_bordered.svg`} style={{ left: "16%", bottom: 24, width: 22 }} />
      <div style={{ maxWidth: 1240, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 40, position: "relative", zIndex: 2 }}>
        {STATS.map((s, i) => (
          <div key={i}>
            <div style={{ fontSize: 72, fontWeight: 700, color: "var(--rt-red-500)", lineHeight: 0.95, letterSpacing: "-0.01em", fontVariantNumeric: "tabular-nums" }}>{s.v}</div>
            <div style={{ marginTop: 8, fontSize: 14, color: "var(--fg-2)" }}>{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

window.StatRow = StatRow;
