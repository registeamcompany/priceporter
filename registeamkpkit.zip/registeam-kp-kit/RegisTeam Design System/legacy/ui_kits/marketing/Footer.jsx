/* global React */

function Footer() {
  return (
    <footer style={{
      background: "var(--rt-navy-900)", color: "#cfd6e6",
      padding: "60px 32px 28px",
    }}>
      <div style={{ maxWidth: 1240, margin: "0 auto", display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr", gap: 40 }}>
        <div>
          <img src="https://registeam.net/wp-content/uploads/2020/12/logo_light_2_1-e1602245353151.png" alt="RegisTeam" style={{ height: 32 }} />
          <p style={{ marginTop: 18, fontSize: 13, lineHeight: 1.6, color: "#aab4c7", maxWidth: 280 }}>
            Performance digital marketing — SEO, PPC, social and ZohoCRM. Premier Google Partner since 2010.
          </p>
          <div style={{ marginTop: 18, fontSize: 14 }}>+38 (094) 710-51-00</div>
          <a href="mailto:hello@registeam.com" style={{ fontSize: 14, color: "#9ec4f8", textDecoration: "none" }}>hello@registeam.com</a>
        </div>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "#7b8ba6" }}>Services</div>
          {["SEO", "Paid Advertising", "ZohoCRM", "Social Media", "YouTube Promotion"].map((x) => (
            <a key={x} href="#" style={{ display: "block", marginTop: 10, fontSize: 14, color: "#dbe2ee", textDecoration: "none" }}>{x}</a>
          ))}
        </div>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "#7b8ba6" }}>Information</div>
          {["About Us", "Reviews", "CEO RegisTeam", "Blog", "Vacancies", "Contact Us"].map((x) => (
            <a key={x} href="#" style={{ display: "block", marginTop: 10, fontSize: 14, color: "#dbe2ee", textDecoration: "none" }}>{x}</a>
          ))}
        </div>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "#7b8ba6" }}>Partners</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14, marginTop: 14 }}>
            <img src="https://registeam.net/wp-content/uploads/2022/04/google-partner.png" alt="Google Partner" style={{ height: 46, filter: "brightness(0.95)" }} />
            <img src="https://registeam.net/wp-content/uploads/2022/04/zoho-partner.png" alt="Zoho" style={{ height: 40, filter: "brightness(0.95)" }} />
          </div>
        </div>
      </div>
      <div style={{ maxWidth: 1240, margin: "40px auto 0", paddingTop: 22, borderTop: "1px solid rgba(255,255,255,0.08)", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 14, fontSize: 12, color: "#7b8ba6" }}>
        <div>© 2010 — 2026 Regis Team™</div>
        <div style={{ display: "flex", gap: 20 }}>
          <a href="#" style={{ color: "#7b8ba6" }}>Facebook</a>
          <a href="#" style={{ color: "#7b8ba6" }}>YouTube</a>
          <a href="#" style={{ color: "#7b8ba6" }}>Instagram</a>
          <a href="#" style={{ color: "#7b8ba6" }}>LinkedIn</a>
        </div>
      </div>
    </footer>
  );
}

window.Footer = Footer;
