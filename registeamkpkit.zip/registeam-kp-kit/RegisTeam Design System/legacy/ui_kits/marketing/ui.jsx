/* global React */
const { useState } = React;

/* =================== Primitives =================== */

function Button({ variant = "primary", size = "md", children, onClick, ...rest }) {
  const base = {
    fontFamily: "var(--font-sans)",
    fontWeight: variant === "cta" ? 700 : 600,
    borderRadius: 6,
    border: "1px solid transparent",
    cursor: "pointer",
    lineHeight: 1,
    transition: "background 150ms ease, color 150ms ease, transform 150ms ease, box-shadow 150ms ease, border-color 150ms ease",
    letterSpacing: variant === "cta" ? "0.08em" : "0.01em",
    textTransform: variant === "cta" ? "uppercase" : "none",
  };
  const sizes = {
    sm: { padding: "8px 12px", fontSize: 12 },
    md: { padding: "12px 18px", fontSize: 14 },
    lg: { padding: "14px 22px", fontSize: 15 },
  };
  const variants = {
    primary: { background: "var(--rt-blue-500)", color: "#fff" },
    secondary: { background: "transparent", color: "var(--rt-blue-500)", borderColor: "var(--rt-blue-500)" },
    ghost: { background: "transparent", color: "var(--fg-1)", borderColor: "var(--border-default)" },
    cta: { background: "var(--rt-red-500)", color: "#fff" },
    onDark: { background: "#fff", color: "var(--rt-navy-900)" },
  };
  const [hover, setHover] = useState(false);
  const hoverFx = {
    primary: { background: "var(--rt-blue-600)", transform: "translateY(-1px)", boxShadow: "var(--shadow-md)" },
    secondary: { background: "var(--rt-blue-500)", color: "#fff" },
    ghost: { background: "var(--bg-2)", borderColor: "var(--border-strong)" },
    cta: { background: "var(--rt-red-600)", transform: "translateY(-1px)", boxShadow: "var(--shadow-md)" },
    onDark: { background: "#f0f1f6", transform: "translateY(-1px)" },
  };
  return (
    <button
      style={{ ...base, ...sizes[size], ...variants[variant], ...(hover ? hoverFx[variant] : {}) }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onClick={onClick}
      {...rest}
    >
      {children}
    </button>
  );
}

function Eyebrow({ children, color = "var(--fg-2)" }) {
  return (
    <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color }}>
      {children}
    </div>
  );
}

function Pill({ children, tone = "blue" }) {
  const tones = {
    blue: { background: "var(--rt-blue-50)", color: "var(--rt-blue-700)" },
    red: { background: "var(--rt-red-50)", color: "var(--rt-red-700)" },
    grey: { background: "var(--rt-grey-100)", color: "var(--rt-grey-700)" },
  };
  return (
    <span style={{ ...tones[tone], fontSize: 12, fontWeight: 600, padding: "6px 12px", borderRadius: 9999, lineHeight: 1 }}>
      {children}
    </span>
  );
}

function Field({ label, required, error, help, type = "text", as = "input", ...rest }) {
  const [focus, setFocus] = useState(false);
  const Tag = as;
  const inpStyle = {
    fontFamily: "var(--font-sans)",
    fontSize: 14,
    padding: "12px 14px",
    borderRadius: 6,
    border: "1px solid " + (error ? "var(--rt-red-500)" : focus ? "var(--rt-blue-500)" : "var(--border-default)"),
    background: "#fff",
    color: "var(--fg-1)",
    outline: 0,
    boxShadow: error
      ? "0 0 0 3px rgba(230,57,70,0.15)"
      : focus
      ? "0 0 0 3px rgba(26,115,232,0.18)"
      : "none",
    width: "100%",
    boxSizing: "border-box",
    resize: as === "textarea" ? "vertical" : "none",
  };
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: "var(--fg-2)" }}>
        {label}{required && <span style={{ color: "var(--rt-red-500)" }}>*</span>}
      </span>
      <Tag
        type={as === "input" ? type : undefined}
        style={inpStyle}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        {...rest}
      />
      {(error || help) && (
        <span style={{ fontSize: 11, color: error ? "var(--rt-red-600)" : "var(--fg-3)" }}>{error || help}</span>
      )}
    </label>
  );
}

/* A floating decorative figure: positioned absolutely by parent. */
function Figure({ src, alt = "", style }) {
  return <img src={src} alt={alt} style={{ position: "absolute", pointerEvents: "none", ...style }} />;
}

const FIG = "https://registeam.net/wp-content/themes/registeam/images/figures";

Object.assign(window, { Button, Eyebrow, Pill, Field, Figure, FIG });
