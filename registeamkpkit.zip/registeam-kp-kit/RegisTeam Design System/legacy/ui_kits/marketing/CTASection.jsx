/* global React, Field, Button, Figure, FIG */
const { useState: useStateC, useRef: useRefC } = React;

function CTASection({ idRef }) {
  const [sent, setSent] = useStateC(false);
  const [check, setCheck] = useStateC(true);
  return (
    <section id="contact" ref={idRef} style={{
      padding: "80px 32px", background: "var(--bg-2)",
      position: "relative", overflow: "hidden",
    }}>
      <Figure src={`${FIG}/rhombus_blue.svg`} style={{ left: "6%", top: 32, width: 22 }} />
      <Figure src={`${FIG}/rhombus_red_bordered.svg`} style={{ right: "8%", bottom: 50, width: 28 }} />
      <Figure src={`${FIG}/dollar.svg`} style={{ right: "12%", top: 60, width: 32, opacity: 0.85 }} />
      <Figure src={`${FIG}/euro.svg`} style={{ left: "12%", bottom: 60, width: 28, opacity: 0.85 }} />

      <div style={{ maxWidth: 980, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center", position: "relative", zIndex: 2 }}>
        <div>
          <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--rt-blue-500)" }}>Free media plan</div>
          <h2 style={{ margin: "10px 0 14px", fontSize: 40, fontWeight: 800, letterSpacing: "-0.02em", lineHeight: 1.1 }}>Do you want to scale<br/>your business?</h2>
          <p style={{ color: "var(--fg-2)", fontSize: 16, lineHeight: 1.65, maxWidth: 380 }}>
            Leave a request — we'll prepare a customized media plan with budget and projected KPIs within two business days.
          </p>
          <div style={{ marginTop: 28, display: "flex", flexDirection: "column", gap: 8 }}>
            <a href="tel:+380947105100" style={{ fontSize: 18, fontWeight: 700, color: "var(--fg-1)", textDecoration: "none" }}>+38 (094) 710-51-00</a>
            <a href="mailto:hello@registeam.com" style={{ fontSize: 15, color: "var(--rt-blue-500)" }}>hello@registeam.com</a>
          </div>
        </div>

        <div style={{
          background: "#fff",
          borderRadius: 16,
          padding: "28px 28px 24px",
          boxShadow: "var(--shadow-lg)",
          border: "1px solid var(--border-default)",
        }}>
          {!sent ? (
            <>
              <h3 style={{ margin: "0 0 18px", fontSize: 20, fontWeight: 700 }}>Contact us</h3>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <Field label="What is your name?" required placeholder="Maria K." />
                <Field label="Phone number" required placeholder="+38" />
                <div style={{ gridColumn: "span 2" }}>
                  <Field label="E-mail" required placeholder="hello@company.com" type="email" />
                </div>
                <div style={{ gridColumn: "span 2" }}>
                  <Field label="Comment" as="textarea" rows={3} placeholder="Tell us about your project — current ads, monthly budget, geo…" />
                </div>
              </div>
              <label style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 12, color: "var(--fg-2)", marginTop: 14 }}>
                <input type="checkbox" checked={check} onChange={(e) => setCheck(e.target.checked)} style={{ marginTop: 2, accentColor: "var(--rt-blue-500)" }} />
                <span>I accept the terms of the <a style={{ color: "var(--rt-blue-500)", textDecoration: "underline" }}>privacy policy</a></span>
              </label>
              <div style={{ marginTop: 18 }}>
                <Button variant="cta" size="lg" onClick={() => setSent(true)} disabled={!check}>Get a free media plan</Button>
              </div>
            </>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, padding: "30px 0" }}>
              <img src={`${FIG}/rocket.png`} style={{ width: 96, transform: "rotate(-15deg)" }} alt="" />
              <h3 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Thanks — we're on it.</h3>
              <p style={{ margin: 0, color: "var(--fg-2)", textAlign: "center", maxWidth: 320 }}>
                A project manager will email you within two business days with a media plan and projected KPIs.
              </p>
              <button onClick={() => setSent(false)} style={{ background: "none", border: 0, color: "var(--rt-blue-500)", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>← Send another</button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

window.CTASection = CTASection;
