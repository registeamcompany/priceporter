# RegisTeam Marketing — UI Kit

A high-fidelity recreation of **registeam.net** as composable React components, built from the public site. No production logic — these are cosmetic, click-through scaffolds intended for design work.

## Files

| File | Purpose |
| --- | --- |
| `index.html` | Click-through home page (loads all the components, fakes navigation between sections). |
| `ui.jsx` | Primitives: `Button`, `Field`, `Pill`, `Eyebrow`, `Figure`. |
| `Header.jsx` | Sticky top bar (logo, nav, phone, CTA). |
| `Hero.jsx` | The first fold — tagline, sub-copy, primary CTA, decorative figure cluster. |
| `ServicesGrid.jsx` | Three- (or four-) up service grid; each card carries a decorative figure. |
| `CaseStudyCard.jsx` | Photo + stats + label, used in the case-study band. |
| `StatRow.jsx` | Big-red-numeral KPI row ("1326+ big-time projects"). |
| `TeamGrid.jsx` | Avatars + names + role under "OUR TEAM". |
| `CTASection.jsx` | Wide section with the contact form & rhombus accents. |
| `Footer.jsx` | Three-column footer (services / info / partners). |

## Recreation notes

- **Source.** Public marketing site only — `https://registeam.net/`. No theme source, no Figma. Layout, type ramp and figure choices are inferred from the rendered DOM.
- **Decorative figures** are hot-linked from `registeam.net/wp-content/themes/registeam/images/figures/*`. Swap to local paths once those files are attached to the project.
- **Photography** (team portraits, case-study photos) is hot-linked from the production media library.
- **Interactivity** is fake. Clicking "Get a quote" scrolls to the contact form; submitting the form just shows a thank-you state.
