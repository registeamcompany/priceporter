/* global React, Button, Figure, FIG */
const { useState: useStateS } = React;

const SERVICES = [
  {
    n: "01",
    title: "SEO promotion",
    what: "We examine the website, address technical issues, and promote it using a verified list of benchmark requests.",
    result: "The site arises in TOP of searchers, the organic traffic is growing.",
    priceA: { l: "Price from", v: "$900" },
    fig: "gear-blue.svg",
    accent: "var(--rt-blue-50)",
  },
  {
    n: "02",
    title: "Search Engine Advertising",
    what: "Keywords, analytics, fine-tuned campaigns. We thoroughly verify the entire system works correctly.",
    result: "Target visitors, who make purchases and order your services.",
    priceA: { l: "Ad budget from", v: "$1,000" },
    priceB: { l: "Agency from", v: "$500" },
    fig: "dollar.svg",
    accent: "var(--rt-red-50)",
  },
  {
    n: "03",
    title: "Social Media Advertising",
    what: "We choose the appropriate audiences, set up analytics, configure and launch campaigns, then refine.",
    result: "New clients, fresh orders, you increase income.",
    priceA: { l: "Ad budget from", v: "$1,000" },
    priceB: { l: "Agency from", v: "$500" },
    fig: "like-hand.svg",
    accent: "var(--rt-blue-50)",
  },
  {
    n: "04",
    title: "YouTube promotion",
    what: "We develop content and marketing strategies, then create, publish and optimize the channel.",
    result: "Interested audience that becomes channel followers and company customers.",
    priceA: { l: "Ad budget from", v: "$1,000" },
    priceB: { l: "Agency from", v: "$500" },
    fig: "youtube.svg",
    accent: "var(--rt-red-50)",
  },
];

function ServiceCard({ svc, onCta }) {
  const [hover, setHover] = useStateS(false);
  return (
    <div
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        position: "relative", overflow: "hidden",
        background: "#fff",
        border: "1px solid " + (hover ? "var(--rt-blue-200)" : "var(--border-default)"),
        borderRadius: 16,
        padding: "28px 28px 26px",
        boxShadow: hover ? "var(--shadow-lg)" : "var(--shadow-md)",
        transform: hover ? "translateY(-4px)" : "translateY(0)",
        transition: "all 200ms ease",
        display: "flex", flexDirection: "column", gap: 12,
        minHeight: 280,
      }}
    >
      <div style={{ position: "absolute", right: -30, top: -30, width: 120, height: 120, background: svc.accent, borderRadius: "50%" }} />
      <Figure src={`${FIG}/${svc.fig}`} style={{ right: 22, top: 22, width: 64, height: 64, objectFit: "contain", zIndex: 2 }} />

      <div style={{ position: "relative", zIndex: 2 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "var(--rt-blue-500)", letterSpacing: "0.08em" }}>{svc.n}</div>
        <h3 style={{ margin: "6px 0 0", fontSize: 22, fontWeight: 700, color: "var(--fg-1)", lineHeight: 1.2 }}>{svc.title}</h3>
      </div>

      <div style={{ position: "relative", zIndex: 2, marginTop: 4 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--fg-3)" }}>What we do</div>
        <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--fg-2)", lineHeight: 1.55 }}>{svc.what}</p>
      </div>

      <div style={{ position: "relative", zIndex: 2 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--fg-3)" }}>Result</div>
        <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--fg-2)", lineHeight: 1.55 }}>{svc.result}</p>
      </div>

      <div style={{
        position: "relative", zIndex: 2, marginTop: "auto",
        display: "flex", alignItems: "flex-end", justifyContent: "space-between",
        paddingTop: 16, borderTop: "1px dashed var(--border-default)",
      }}>
        <div style={{ display: "flex", gap: 18 }}>
          <div>
            <div style={{ fontSize: 11, color: "var(--fg-3)" }}>{svc.priceA.l}</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "var(--fg-1)" }}>{svc.priceA.v}</div>
          </div>
          {svc.priceB && (
            <div>
              <div style={{ fontSize: 11, color: "var(--fg-3)" }}>{svc.priceB.l}</div>
              <div style={{ fontSize: 18, fontWeight: 700, color: "var(--fg-1)" }}>{svc.priceB.v}</div>
            </div>
          )}
        </div>
        <Button size="sm" onClick={onCta}>Get a quote</Button>
      </div>
    </div>
  );
}

function ServicesGrid({ onCta }) {
  return (
    <section style={{ padding: "80px 32px", background: "var(--bg-2)" }}>
      <div style={{ maxWidth: 1240, margin: "0 auto" }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--fg-2)" }}>Digital services</div>
        <h2 style={{ margin: "8px 0 8px", fontSize: 36, fontWeight: 700, letterSpacing: "-0.01em" }}>What we do for you</h2>
        <p style={{ margin: "0 0 32px", color: "var(--fg-2)", fontSize: 16, maxWidth: 640 }}>
          Pick a service or combine a few. We'll prepare a customized media plan and confirm projected KPIs before we start.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 18 }}>
          {SERVICES.map((s) => <ServiceCard key={s.n} svc={s} onCta={onCta} />)}
        </div>
      </div>
    </section>
  );
}

window.ServicesGrid = ServicesGrid;
