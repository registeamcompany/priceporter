/* global React, Button, Eyebrow, Figure, FIG */

function Hero({ onCta }) {
  return (
    <section style={{
      position: "relative", overflow: "hidden",
      padding: "80px 32px 100px",
      background: "var(--rt-white)",
    }}>
      {/* radial backdrop */}
      <div style={{
        position: "absolute", inset: 0,
        background:
          "radial-gradient(60% 70% at 65% 30%, rgba(26,115,232,0.10), transparent 60%), radial-gradient(40% 50% at 95% 80%, rgba(230,57,70,0.06), transparent 60%)",
        pointerEvents: "none",
      }} />
      {/* decorative figures */}
      <Figure src={`${FIG}/spaceman.webp`} style={{ right: "6%", top: 40, width: 220, opacity: 0.95 }} />
      <Figure src={`${FIG}/rhombus_blue.svg`} style={{ right: "30%", top: 80, width: 22, transform: "rotate(15deg)" }} />
      <Figure src={`${FIG}/rhombus_red_bordered.svg`} style={{ right: "10%", bottom: 60, width: 28 }} />
      <Figure src={`${FIG}/dollar.svg`} style={{ left: "8%", bottom: 60, width: 34 }} />
      <Figure src={`${FIG}/euro.svg`} style={{ left: "12%", top: 80, width: 26 }} />
      <Figure src={`${FIG}/gear-bordered.svg`} style={{ left: "30%", bottom: 30, width: 36 }} />

      <div style={{ maxWidth: 1240, margin: "0 auto", position: "relative", zIndex: 2 }}>
        <Eyebrow color="var(--rt-blue-500)">Marketing Digital Agency</Eyebrow>
        <h1 style={{
          margin: "14px 0 18px",
          fontSize: 64, lineHeight: 1.05, letterSpacing: "-0.02em",
          fontWeight: 800, color: "var(--fg-1)", maxWidth: 760,
        }}>
          We help the business to grow <br/>and find new customers
        </h1>
        <p style={{ maxWidth: 560, color: "var(--fg-2)", fontSize: 18, lineHeight: 1.65, margin: 0 }}>
          Digital marketing services tailored to small and medium-sized businesses, provided by a team with over a decade of expertise in PPC and SEO strategies.
        </p>
        <div style={{ marginTop: 32, display: "flex", gap: 14, alignItems: "center" }}>
          <Button variant="cta" size="lg" onClick={onCta}>Get a toll-free audit</Button>
          <Button variant="secondary" size="lg">Digital agency services</Button>
        </div>

        <div style={{ marginTop: 56, display: "flex", gap: 28, alignItems: "center", flexWrap: "wrap" }}>
          <img src="https://registeam.net/wp-content/uploads/2022/04/google-partner.png" alt="Google Partner" style={{ height: 54 }} />
          <img src="https://registeam.net/wp-content/uploads/2022/04/google.png" alt="Google" style={{ height: 40 }} />
          <img src="https://registeam.net/wp-content/uploads/2022/04/zoho-partner.png" alt="Zoho" style={{ height: 50 }} />
          <span style={{ fontSize: 13, color: "var(--fg-3)", letterSpacing: "0.04em" }}>
            Premier Google Partner · since 2010 · 3,500+ campaigns
          </span>
        </div>
      </div>
    </section>
  );
}

window.Hero = Hero;
