/* global React, Pill, Button */

const CASES = [
  {
    img: "https://registeam.net/wp-content/uploads/2020/12/office_image1_1.jpg",
    title: "Outsourcing call center · Connectic",
    challenge: "Initiate a Facebook campaign producing 100+ leads/month at a max $33 / lead.",
    stats: [
      { v: "167", l: "applications / 2nd month" },
      { v: "x67%", l: "over the plan" },
      { v: "$9", l: "cost per application" },
    ],
    tag: "Facebook",
    tagTone: "blue",
  },
  {
    img: "https://registeam.net/wp-content/uploads/2021/05/lep-35.png",
    title: "Engineering equipment, energy industry",
    challenge: "Grow keywords in Google TOP-10 and lift organic traffic.",
    stats: [
      { v: "x12", l: "keywords in TOP-10" },
      { v: "671 → 1,523", l: "monthly traffic" },
    ],
    tag: "SEO",
    tagTone: "red",
  },
  {
    img: "https://registeam.net/wp-content/uploads/2020/12/canon-eos-r-mockup.jpg",
    title: "Online shop, pro photo & video gear",
    challenge: "Raise keyword count in TOP-10 and organic search-driven sessions.",
    stats: [
      { v: "x3", l: "monthly traffic" },
      { v: "4% → 73%", l: "organic visibility" },
      { v: "76", l: "keywords in TOP-3" },
    ],
    tag: "SEO",
    tagTone: "red",
  },
  {
    img: "https://registeam.net/wp-content/uploads/2020/12/UMSH0987-Edit.jpg",
    title: "Food delivery company",
    challenge: "Reach 325 paid orders. Held the cost down month-over-month.",
    stats: [
      { v: "337", l: "orders / 1st month" },
      { v: "$4.9", l: "cost per order" },
    ],
    tag: "Google Ads",
    tagTone: "blue",
  },
];

function CaseStudyCard({ c, onCta }) {
  return (
    <article style={{
      background: "#fff", border: "1px solid var(--border-default)",
      borderRadius: 16, overflow: "hidden",
      display: "grid", gridTemplateColumns: "260px 1fr",
      boxShadow: "var(--shadow-md)",
    }}>
      <div style={{
        backgroundImage: `url(${c.img})`,
        backgroundSize: "cover", backgroundPosition: "center",
        minHeight: 200,
      }} />
      <div style={{ padding: "22px 24px", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
          <h3 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "var(--fg-1)", lineHeight: 1.3 }}>{c.title}</h3>
          <Pill tone={c.tagTone}>{c.tag}</Pill>
        </div>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--fg-3)" }}>Challenge</div>
          <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--fg-2)", lineHeight: 1.5 }}>{c.challenge}</p>
        </div>
        <div style={{ display: "flex", gap: 22, marginTop: 4 }}>
          {c.stats.map((s, i) => (
            <div key={i}>
              <div style={{ fontSize: 28, fontWeight: 700, color: "var(--rt-red-500)", lineHeight: 1 }}>{s.v}</div>
              <div style={{ fontSize: 11, color: "var(--fg-2)", marginTop: 4 }}>{s.l}</div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: "auto", display: "flex", justifyContent: "flex-end" }}>
          <Button variant="secondary" size="sm" onClick={onCta}>Get a consultation</Button>
        </div>
      </div>
    </article>
  );
}

function CaseStudies({ onCta }) {
  return (
    <section style={{ padding: "80px 32px", background: "var(--rt-white)" }}>
      <div style={{ maxWidth: 1240, margin: "0 auto" }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--fg-2)" }}>Case studies</div>
        <h2 style={{ margin: "8px 0 32px", fontSize: 36, fontWeight: 700, letterSpacing: "-0.01em" }}>Case studies driving sales</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
          {CASES.map((c, i) => <CaseStudyCard key={i} c={c} onCta={onCta} />)}
        </div>
      </div>
    </section>
  );
}

window.CaseStudies = CaseStudies;
window.CaseStudyCard = CaseStudyCard;
