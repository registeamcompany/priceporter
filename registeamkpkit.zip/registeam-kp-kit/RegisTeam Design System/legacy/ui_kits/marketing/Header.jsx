/* global React, Button */
const { useState: useStateH } = React;

function Header({ active = "About Us", onCta }) {
  const items = ["About Us", "SEO", "Paid Advertising", "ZohoCRM", "Services", "Blog", "Contact Us"];
  const [hover, setHover] = useStateH(null);
  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 100,
      background: "rgba(255,255,255,0.96)",
      backdropFilter: "saturate(140%) blur(8px)",
      WebkitBackdropFilter: "saturate(140%) blur(8px)",
      borderBottom: "1px solid var(--border-default)",
    }}>
      <div style={{
        maxWidth: 1240, margin: "0 auto",
        display: "flex", alignItems: "center", gap: 28,
        padding: "16px 32px",
      }}>
        <a href="#" style={{ display: "flex", alignItems: "center" }}>
          <img src="https://registeam.net/wp-content/uploads/2020/11/logo.svg" alt="RegisTeam" style={{ height: 30 }} />
        </a>
        <nav style={{ display: "flex", gap: 22, flex: 1 }}>
          {items.map((it) => (
            <a key={it}
              href="#"
              onMouseEnter={() => setHover(it)}
              onMouseLeave={() => setHover(null)}
              style={{
                fontSize: 14, fontWeight: 500,
                color: it === active || hover === it ? "var(--rt-blue-500)" : "var(--fg-1)",
                textDecoration: "none",
                transition: "color 150ms ease",
              }}
            >{it}</a>
          ))}
        </nav>
        <a href="tel:+380947105100" style={{ fontSize: 13, fontWeight: 600, color: "var(--fg-1)", textDecoration: "none" }}>
          +38 (094) 710-51-00
        </a>
        <Button onClick={onCta}>Discuss the project</Button>
      </div>
    </header>
  );
}

window.Header = Header;
