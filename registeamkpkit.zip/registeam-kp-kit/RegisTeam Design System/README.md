# RegisTeam Design System

A working design system for **RegisTeam** — a performance digital marketing agency established in Kharkiv, Ukraine in 2010, specializing in SEO, PPC (Google Ads / Bing / Meta), social media, ZohoCRM integration and web development. Premier Google Partner, 3,500+ campaigns, primarily serving e‑commerce, B2B and technology verticals.

> The current canonical system is **v2 — Modern**. The original v1 (which closely tracked the live `registeam.net` WordPress site) has been archived under [`legacy/`](./legacy/) for reference.

> ⚠️ **Source caveat.** No codebase, Figma file, brand book or asset zip was attached to this project. This system was inferred from RegisTeam's public marketing properties — primarily **<https://registeam.net>**. Tokens, type ramps and the iconographic system are best-guess interpretations and should be replaced once we have the real source.

## Sources

| What | Where |
| --- | --- |
| Marketing site | <https://registeam.net/> |
| Tech vertical | <https://tech.registeam.net/> |
| Services page | <https://registeam.net/services/> |
| Theme asset CDN | `https://registeam.net/wp-content/themes/registeam/images/` |
| Media library | `https://registeam.net/wp-content/uploads/` |
| Clutch profile | <https://clutch.co/profile/registeam> |

## At a glance

- **Industry** Performance marketing / digital advertising agency
- **Founded** 2010 · **HQ** Kharkiv, Ukraine
- **Headcount** 35 ad specialists, 200+ across all functions
- **Services** SEO, PPC (Google/Bing/Meta), SMM, YouTube promotion, web design, ZohoCRM
- **Verticals** B2B, e‑commerce, tech/SaaS, medical
- **Positioning** Data-driven, transparent, measurable — *"we predict your ROI before you sign"*
- **Tagline (English)** *Grow. Convert. Measurably.*

## Index

```
.
├── README.md
├── SKILL.md                        ← Agent Skill manifest (works as a Claude Code skill)
├── colors_and_type.css             ← canonical (v2) tokens scoped under `.rt-v2`
├── fonts/                          ← font notes (Inter Tight + JetBrains Mono via Google Fonts)
├── preview/                        ← one HTML card per design-system concept
│   ├── colors.html                       (Colors)
│   ├── type.html                         (Type)
│   ├── spacing-scale.html  radii.html  shadows.html   (Spacing)
│   ├── buttons.html  form-fields.html  header-nav.html
│   ├── service-cards.html  stat-block.html  hero.html  dark-section.html  (Components)
│   ├── logo.html  accents.html  partner-badges.html   (Brand)
├── slides/                         ← 16:9 deck template (uses deck-stage component)
│   ├── index.html
│   └── deck-stage.js
├── ui_kits/marketing/              ← click-through recreation of registeam.net
│   └── index.html
└── legacy/                         ← v1 archive (do not extend; reference only)
    ├── preview/
    └── ui_kits/marketing/
```

---

## CONTENT FUNDAMENTALS

### Voice

**Confident performance-marketing voice.** RegisTeam sells certainty to founders and marketing leads who have been burned by other agencies. Copy leans on proof, numbers, transparency and the decade-plus track record. Sits between "consultant" and "expert friend"; never hip-startup, never corporate jargon.

### Pronouns

- **"We"** for RegisTeam (always — the brand is a team).
- **"You" / "your business"** for the reader. Direct, second-person.
- **Never "I"** outside CEO quotes (Alex Benedychuk is the only first-person voice on the site).

### Casing

- **Sentence case** in body and most headings (*"Performance marketing for SMB and B2B"*).
- **ALL CAPS** only as an accent on monospaced eyebrows in v2 (was used more broadly in v1).
- **Title Case** for proper nouns and service names ("Search Engine Advertising", "Google Partner").

### Tone & vibe

- **Numbers up front.** Stats lead — *"3,500+ campaigns", "40% arrive by referral", "$9 cost per lead"*.
- **Proof, not promises.** Almost every claim is paired with a metric, testimonial or partner badge.
- **Plain English with restraint.** No emoji on web. Light editorial flourish (italics, an em-dash, a strikethrough block).
- **Friendly but not jokey.** Zero memes. The arrow `→` is the closest thing to emoji and is used as a punctuation accent throughout the v2 system.

### Microcopy patterns

- CTAs: *Get a free audit · Discuss the project · Book a call · Get a quote · Talk to a strategist · Send*
- Eyebrows (mono): *→ 01 / SEO*, *→ Performance marketing*, *→ Case study*
- Form labels (mono uppercase): *YOUR NAME · PHONE · E-MAIL · COMMENT*

### Examples to mimic

> *Grow. Convert. Measurably.*

> *Performance marketing for SMB and B2B brands — strategy, budget and projected KPIs locked in before we ever launch.*

> *We predict your ROI in writing before you sign — budget, KPIs, timeline. Then we beat it. That's the whole differentiator.* — Alex Benedychuk, CEO

---

## VISUAL FOUNDATIONS (v2)

### Color

A **four-token system**: deep **ink** as the new primary (replacing pure black), **electric blue** for actions, **coral red** as the signal accent, and **warm sand** as the alt surface.

- **Ink** `#0E1428` (token: `--ink-800`) — body text and primary buttons. Used everywhere v1 used navy or black.
- **Electric blue** `#2A4BF0` (`--elec-500`) — accent fills, focused inputs, charts.
- **Coral** `#FF3D4E` (`--coral-500`) — stat numbers, italics, signal/error.
- **Warm sand** `#F4EFE5` (`--sand-100`) — alternating section background, replaces v1's cool grey.
- **Dark band** `#070B1A` (`--ink-900`) — premium CTA / quote sections.

### Type

- **Display** Inter Tight 700–800, tracking −0.035 to −0.055em, oversized (up to 280px in deck slides).
- **Body** Inter 400/500 at 16–18px, line-height 1.5–1.55.
- **Numerals / eyebrows** JetBrains Mono — 11–18px ALL CAPS for labels; tabular-nums for big stats.
- Headlines mix weights and styles: heavy + *italic accent* + a black "stroke" block (white text on ink rectangle with rounded corners) as a signature device.

### Spacing

8-point grid. Common rhythms:

- Inline gaps: 8 / 12 / 16
- Card padding: 22 / 24 / 32
- Section vertical padding: 60 / 70 / 80 / 90
- Slide padding (1920×1080): 96
- Page max width: 1240px

### Backgrounds

- **Mostly white** with **alternating warm sand** sections.
- **A premium "ink" band** (CTA, quote slide, footer accents) with subtle radial glows in electric blue + coral.
- **Sparse dot-grid pattern** as a backdrop accent on hero and stat sections — replaces the legacy scattered cartoon figures.
- **No textures, no noise, no gradients on chrome itself.** Only radial glows on the ink band.

### Animation

- **Light and crisp.** Hover transitions ~180–220ms with `cubic-bezier(.2,.7,.3,1)`.
- Card hover → 3–4px lift + softer-deeper shadow + arrow translate +3px,-3px.
- No bounce, no spring, no flash.

### Hover states

- **Primary pill** → fill darkens to `--ink-900`, lift 1px, shadow grows.
- **Accent pill** → fill to `--coral-600`, shadow tinted coral.
- **Ghost pill** → fill flips to ink, text to white.
- **Cards** → 3–4px lift, softer-deeper shadow, arrow icon translates and changes color.
- **Links** → underline on hover only, color stays.

### Borders

- **1px `rgba(14,20,40,0.10)`** is the workhorse — used on cards, dividers, inputs at rest.
- **2px `--elec-500`** for focus rings on inputs.
- **1.5px solid `rgba(14,20,40,0.12)`** for section dividers inside cards.

### Shadows

Two-tier system with cool ink tint:

- **`--shadow-sm`** `0 1px 2px rgba(14,20,40,0.05)` — tight, almost invisible
- **`--shadow-md`** `0 2px 4px rgba(14,20,40,0.04), 0 8px 24px rgba(14,20,40,0.06)` — resting cards
- **`--shadow-lg`** `0 12px 36px rgba(14,20,40,0.12)` — hover lift
- **`--shadow-xl`** `0 32px 60px rgba(14,20,40,0.20)` — modals

Buttons get colored shadow on hover: `rgba(255,61,78,0.30)` for accent, `rgba(42,75,240,0.30)` for electric.

### Corner radii

Sharper than v1, but pills everywhere for controls.

- Inputs: `10px`
- Cards: `14–18px`
- Sections: `20–28px`
- Buttons + chips: `9999px` (pill)
- Photos: `12–16px`

### Cards

Cleaner, more confident than v1. No decorative corner circle. Mono-spaced eyebrow at top, a small colored dot indicator, big display title, single-line description, and a 38–64px circular arrow CTA at the bottom-right. Hover lifts and rotates the arrow to coral.

### Use of transparency & blur

- Header uses `backdrop-filter: blur(10px)` over `rgba(255,255,255,0.92)` — modern frosted strip.
- Dark band uses radial glows (`radial-gradient`) for ambient color, no real blur.
- No glassmorphism on cards.

### Layout rules

- Sticky frosted header with logo, nav, phone, primary pill CTA.
- 12-col grid; collapses to 2/3 col on tablet, single col on mobile (~900px breakpoint).
- Generous vertical rhythm; sections breathe.
- Three-up or four-up grids for services / stats / team.
- No left rails / no sidebars on marketing surfaces.

### Anti-patterns

- Don't use bluish-purple gradients.
- Don't add dark mode beyond the intentional ink CTA band.
- Don't use emoji.
- Don't roll square-cornered buttons (always pill in v2).
- Don't use glassmorphism on cards.
- Don't bring back the v1 cartoon figures (gear, spaceman, currency coin). Use the geometric accent system instead.

---

## ICONOGRAPHY

### Arrow as a brand glyph

The right-arrow `→` is **the signature icon of v2**. It appears:

- Before mono-spaced eyebrows (*→ 01 / SEO*, *→ Performance marketing*)
- Inside pill buttons (right edge, in a circular badge)
- As the corner CTA on every card (circular ink button)
- As a punctuation accent in section titles

Reproduce as a literal `→` character with proper font, never as an SVG when possible.

### Geometric accent system

Replaces v1's decorative figures. Documented in [`preview/accents.html`](./preview/accents.html):

| Shape | Use |
| --- | --- |
| Coral rhombus (small, rotated 45°) | Hero corner accents, slide title decoration |
| Electric blue outlined rhombus | Pair with coral for two-tone hero |
| Ink dot | Tertiary accent |
| Dot-grid pattern (radial-gradient background) | Sparse backdrop in hero + stat sections |
| Outlined ring | Sec-head bullets |

Scatter sparingly in section corners or behind sec-heads.

### Utility icons

A small set of stroke-style glyphs for UI utility (menu, close, chevron, phone, mail). When something isn't already in this repo, **fall back to [Lucide](https://lucide.dev)** via CDN — Lucide's stroke weight and rounded caps match the v2 house style.

### Emoji

**No.** The brand never uses emoji.

### Partner / award badges

Pixel-perfect bitmaps of third-party credentials — Google Partner, Premier Google Partner, Zoho Authorized Partner, GoodFirms, Clutch. Treated as logos, not icons. Never recolor. On dark sections, apply `filter: brightness(0) invert(1)` to knock out to white.

### Logo

The real RegisTeam SVG mark (red R + RegisTeam wordmark) lives at the public CDN: `https://registeam.net/wp-content/uploads/2020/11/logo.svg`. It is referenced directly in v2 — replace with a local copy once we have the source file.

---

## How to use this system

In Claude / Claude Code:

1. Open the **Design System** tab — every card under `preview/` shows up there grouped by Type / Colors / Spacing / Components / Brand.
2. Open `ui_kits/marketing/index.html` to see the click-through recreation.
3. Open `slides/index.html` to see the 8-slide deck template.
4. Read `SKILL.md` to load this as an Agent Skill in a separate Claude Code project.

When designing new artifacts for RegisTeam:

- **Always link `colors_and_type.css`** and add `class="rt-v2"` to the body (or any wrapping container) to opt in to the v2 token set.
- Use the `.m-btn` / `.m-btn--primary | --accent | --electric | --ghost | --inverted` button classes.
- Pull tokens (`--ink-800`, `--elec-500`, `--coral-500`, `--sand-100`, `--font-display`, `--font-mono`, etc.) rather than hand-typing hex values.
- Reuse component patterns from `preview/*.html` and `ui_kits/marketing/index.html`.
- For motion, prefer subtle 180–220ms `cubic-bezier(.2,.7,.3,1)` transitions.
- For decoration, use the geometric accent system (rhombi + dots) over the legacy cartoon figures.

---

## Open questions / asks for the user

1. **Real brand assets.** Please share the Figma file, brand book or any zip of source assets so we can replace inferred tokens with exact values.
2. **Real fonts.** Confirm the live font. We're using **Inter Tight + Inter + JetBrains Mono** via Google Fonts. Swap if we should be using a licensed Roboto/Proxima/etc.
3. **Logo file.** We reference the public CDN SVG directly. A local SVG (preferably with light + dark variants) would let us self-host.
4. **Sub-brand.** `tech.registeam.net` and `blog.registeam.com` are not modeled yet. Want them?
5. **Real photography.** Team portraits and case-study imagery are hot-linked from registeam.net. We should have proper licensed alternatives.
