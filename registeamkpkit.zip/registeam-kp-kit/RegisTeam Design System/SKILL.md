---
name: registeam-design
description: Use this skill to generate well-branded interfaces and assets for RegisTeam, the digital marketing agency (SEO, PPC, social, ZohoCRM) — either for production or throwaway prototypes/mocks/decks. Contains essential design guidelines, colors, type, fonts, decorative accent system, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files:

- `colors_and_type.css` — canonical (v2) tokens. Scoped under `.rt-v2`. **Always link this stylesheet AND add `class="rt-v2"` to the body** in any new artifact.
- `fonts/` — font notes (Inter Tight + Inter + JetBrains Mono via Google Fonts).
- `preview/` — reference cards for every design-system concept (one HTML file per concept).
- `ui_kits/marketing/index.html` — full click-through recreation of `registeam.net` in v2 styling. Lift sections from this rather than rolling new layouts.
- `slides/index.html` — 8-slide 16:9 deck template (title · agenda · big stat · services · case study · results · quote · CTA) using `deck-stage.js` for nav + scaling.
- `legacy/` — the v1 system (close to live `registeam.net`). Reference only — don't extend it.

### How to use

If creating **visual artifacts** (slides, mocks, throwaway prototypes, landing pages, decks):

- Link `colors_and_type.css` and add `class="rt-v2"` to the body.
- Use the v2 component patterns from `preview/*.html` and the marketing kit.
- For a slide deck, copy `slides/index.html` as a starting point and edit slide sections in place — `deck-stage.js` handles scaling, keyboard nav, slide rail, and PDF export.
- For decoration, use the geometric accent system (small rhombi, dots, dot-grid backgrounds) over any cartoon-style figures.
- The arrow glyph `→` is the brand's signature icon — use it before mono eyebrows, inside pill buttons, and as card CTA badges.

If working on **production code**, copy assets and read the tokens to become an expert in designing with this brand. Token names follow common practice (`--ink-800`, `--elec-500`, `--coral-500`, `--sand-100`, `--font-display`, `--font-mono`, `--shadow-md`, `--radius-lg`, etc.).

### Brand cheat sheet (v2)

- **Voice** confident performance-marketing voice. Sentence case in body; mono eyebrows for labels. Numbers up front. Zero emoji.
- **Colors** ink `#0E1428` (primary text + buttons), electric `#2A4BF0` (accents), coral `#FF3D4E` (stat numerals + signal), warm sand `#F4EFE5` (alt surface). Premium ink band `#070B1A` for CTA sections.
- **Type** Inter Tight 700–800 for display (tracking −0.035 to −0.055em), Inter 400/500 for body, JetBrains Mono 11–18px for eyebrows and tabular stat numerals.
- **Iconography** the `→` glyph + a small geometric accent set (rhombi, dots, rings, dot-grid). Lucide as fallback for utility icons.
- **Radii** 10 for inputs, 14–18 for cards, pill (9999) for buttons and chips.
- **Shadows** cool ink-tinted, two-tier (resting → hover lift). Buttons get colored shadows on hover (coral / electric tint).
- **Motion** crisp, 180–220ms `cubic-bezier(.2,.7,.3,1)`. No bounce.

### When invoked with no other guidance

Greet the user and ask what they want to build or design. Then ask 3–5 focused questions (audience, surface, tone, variations, visuals vs. interactions). Then act as an expert designer who outputs HTML artifacts *or* production code, depending on the need.
