# Fonts

The live RegisTeam site uses a Roboto/Open Sans-family humanist sans-serif. The exact face was not provided.

**Current substitution:** **Inter** (Google Fonts), loaded via `@import` in `colors_and_type.css`.

To swap in the real face:

1. Drop the `.ttf` / `.woff2` files into this folder.
2. Replace the `@import` line at the top of `colors_and_type.css` with a `@font-face` declaration set.
3. Update `--font-sans` if the family name changes.
